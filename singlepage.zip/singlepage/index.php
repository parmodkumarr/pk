<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <form  id="form">
    <div class="form-group">
      <label for="url">Url:</label>
      <input type="text" class="form-control" id="url" placeholder="http://" name="url">
      <div class="form-group">
      	<div class="form-check-inline">
		  <label class="form-check-label">
		    <input type="radio" class="form-check-input" id="webcheck2" value="2" name="webcheck">whole website
		  </label>
		</div>
		<div class="form-check-inline">
		  <label class="form-check-label">
		    <input type="radio" class="form-check-input" id="webcheck1" value="1" name="webcheck" checked>single webpage
		  </label>
		</div>
      </div>
    </div>
    <button type="button" name="button" id="submitBtn" class="btn btn-default">Submit</button>
  </form>

  <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">links</th>
      <th scope="col">Status</th>
      <th scope="col">Count</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>
<script type="text/javascript">
  var baseurl ='';
  var proccessedLink = [];
  let number =1;
  let loops =0;

  function getbaseurl(url){
    if(url){
      var arrurl = url.split("/");
      var getbaseurl = arrurl[0] + "//" + arrurl[2];
      return getbaseurl;
    }else{
      return '#';
    }
    
  }

  function filterurl(url){
    var checkul ='';
    if(url){
      var arrurl = url.split("//");
      if(arrurl[0] == ""){
        var arrbaseurl = baseurl.split("/");
        checkul =arrbaseurl[0] + url;
      }else{
        checkul =url;
      }
    }
    return checkul;
  }

  function checkurlstatus(url,index,count=0){
    var requesturl = filterurl(url);
    console.log('url',url);
    console.log('requesturl',requesturl);
    //var requesturl = url;
      $.ajax({
          url:'test.php',
          type:'POST',
          data:{
            status:2,
            url:requesturl,
            baseurl:baseurl
          },
          complete: function(status){
            //proccessedLink.push(url);
            if(status.responseText != 200){
              const y = number++;
              $('.table tbody').append('<tr class="child"><td>'+y+'</td><td>'+requesturl+'</td><td>'+status.responseText+'</td><td>'+count+'</td></tr>');
            }else{
            	if($('#webcheck2').is(':checked')){
	            	if(baseurl == getbaseurl(requesturl)){
		            	getlinks(requesturl);
		            }
            	}
            }
          }
      });
  }
//let number2 =1;
  function getlinks(url){
   // const y = number2++;
    $.ajax({   
        type: "POST",
        url: "test.php",
        data:{
          status:1,
          url:url,
          baseurl:baseurl
        },         
        //dataType: "html",                  
        complete: function(data){
          var result = JSON.parse(data.responseText);
          var urls   = result.link;
          var countlink = result.countlink;
          // console.log(countlink);
          // console.log('final link',urls);
          if(urls.length > 0){
            urls.forEach(
              function myFunction(url2, index) {
                if(!proccessedLink.includes(url2)){
                  proccessedLink.push(url2);
                  //console.log('push in array' + proccessedLink);
                  checkurlstatus(url2,index,countlink[url2]);
                }
              }
            )
          } 
        }
    });
  }

  $(document).on('click','#submitBtn',function(e){
    var formurl =$('#url').val();
    baseurl = getbaseurl(formurl);
    proccessedLink.push(formurl);
      getlinks(formurl);
  });
</script>
</body>
</html>
