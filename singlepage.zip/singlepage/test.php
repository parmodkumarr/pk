<?php
require 'sql.php';
function get_url_with_domain($url, $domain=null) {
    $result = parse_url($url);
    if(isset($result['host'])){
        return $url;
    } else{ 
        if (strpos($url, 'mailto:') !== false || strpos($url, 'tel:') !== false || strpos($url, 'void(0)') !== false) {
             return $url;
        } else{ 
            if($url == '#'){
                return $domain;
            } else{ 
                $link = $domain.'/'.$url;
                $exploded_url = explode( "#", $link ); 
                if(isset($exploded_url[1])){
                    if(substr($domain , -1)!='/'){
                        $domain = $domain.'/';
                    }
                    return $domain.'#'.$exploded_url[1];
                }else{
                    $link1 = parse_url($link); 
                    $finalUrl = $link1['scheme'].'://'. $link1['host'];
                    if(isset($link1['path'])){
                    	$path =$link1['path'];
                    }else{
                    	$path ='';
                    }
                    $finalUrl = $finalUrl.str_replace('//', '/', $path);
            		return $finalUrl;
                }
            }
        }
    }
}



$result = array();



	if($_POST['status'] == 1){
		$formurl = $_POST['url'];
		$baseurl = $_POST['baseurl'];
		echo getLinks($formurl,$baseurl);
		exit();
	}

	if($_POST['status'] == 2){
		$url = $_POST['url'];
		$baseurl = $_POST['baseurl'];
		echo check_url($url,$baseurl);
		exit();
	}
	
	function baseurl($url) {
	  $result = parse_url($url);
	  return $result['scheme']."://".$result['host'];
	}

	function check_url($url,$baseurl) {
		$domain= get_url_with_domain($url,$baseurl);
	    $ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $domain);
	    curl_setopt($ch, CURLOPT_HEADER, 0);
	    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
	    curl_setopt($ch , CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch , CURLOPT_BINARYTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_TIMEOUT, 400);
		curl_setopt($ch, CURLINFO_REDIRECT_URL, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Your application name');
	    $data = curl_exec($ch);
	    $headers = curl_getinfo($ch);
	    curl_close($ch);

	    return $headers['http_code'];
	}

	function getBrokenlink(){

	}

	function isJSON($string){
	   return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
	}

	function getLinks($url,$baseurl)
	{
		//$domain= get_url_with_domain($url);
		//$baseurl =  baseurl($url);
		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL, $url);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 0);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_TIMEOUT, 400);
		curl_setopt($curl_handle, CURLINFO_REDIRECT_URL, true);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$html = curl_exec($curl_handle);
		curl_close($curl_handle);
		$dom = new DOMDocument;
		@$dom->loadHTML($html);
		$linkList = $dom->getElementsByTagName('*');
		$srcarr = array();
		$hrefarr = array();
		$notproccess= array();
		$totallink = array();
		$links = array();
		$imgLinks =[];

		if(isJSON($html)){
			return json_encode($hrefarr);
		}
		foreach ($linkList as $node){
			if(in_array( $node->tagName, ['a', 'img', 'link', 'iframe', 'script'])){
				if($node->tagName == 'img' and $node->getAttribute('src') != ""){
	               $links[] = $node->getAttribute('src');
	             //  $imgLinks[] = $node->getAttribute('src');
	            } else if($node->tagName == 'link' and  $node->getAttribute('href') != ""){
	              	$links[] = get_url_with_domain($node->getAttribute('href'),$baseurl);
	            }else if($node->tagName == 'a' and $node->getAttribute('href') != ""){
	                $links[] =  get_url_with_domain($node->getAttribute('href'),$baseurl);
	            }else if($node->tagName == 'iframe' and  $node->getAttribute('src') != ""){
	                $links[] = get_url_with_domain($node->getAttribute('src'),$baseurl);
	            }else if($node->tagName == 'script' and  $node->getAttribute('src') != ""){
	                $links[] = get_url_with_domain($node->getAttribute('src'),$baseurl);
	            }
			}
		}

		$linkscount  =array_count_values($links);
		$weblink    = array();
		$for_status = array();
		foreach($links as $link){
			//$gethref = $link->getAttribute('href');
			$gethref = $link;
				//$gethref = get_url_with_domain($link, $baseurl);
				if(!in_array($gethref, $hrefarr)){
					if(($gethref != $baseurl) && ($gethref != $baseurl.'/')){
			    		array_push($hrefarr, $gethref);
			    		// if($baseurl == baseurl($gethref)){
			    		// 	array_push($weblink, $gethref);
			    		// }else{
			    		// 	array_push($for_status, $gethref);
			    		// }
			   //  		$test =  find('temp_url'," url ='".$gethref."' ");
						// if(!$test){
						// 	insert('temp_url',["url "=>$gethref,"status_code"=>""]);	
						// }
					}
			    }
		}
		// $final['weblink'] =$weblink;
		// $final['for_status'] =$for_status;
		return json_encode(array('link'=>$hrefarr,'countlink'=>$linkscount));
	}
?>
