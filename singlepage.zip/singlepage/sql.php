<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="test";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

	function insert($table,$data)
	{	
		global $conn;
		$key = array_keys($data);
	    $val = array_values($data);
	    $sql = "INSERT INTO $table (" . implode(', ', $key) . ") "
	         . "VALUES ('" . implode("', '", $val) . "')";
	    $result = mysqli_query($conn, $sql); 
	    //$last_id = mysqli_insert_id($conn);       
		if ($result) {
		  return $result;
		} else {
		  return "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}

	function update($table, $data, $where=null)
	{
		global $conn;
	    $cols = array();
	    foreach($data as $key=>$val) {
	        $cols[] = "$key = '$val'";
	    }
	    $sql = "UPDATE $table SET " . implode(', ', $cols) . " WHERE $where";
	 	$result = mysqli_query($conn, $sql);        
		if ($result) {
		  return $result;
		} else {
		  return "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}

	function delete($table, $where=null)
	{
		global $conn;
	    $sql = "DELETE FROM $table WHERE $where";

	 	$result = mysqli_query($conn, $sql);        
		if ($result) {
		  return $result;
		} else {
		  return "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}

	function find ($table, $where=null)
	{
		global $conn;
		$sql = "SELECT * FROM $table WHERE $where LIMIT 1";
		$result = $conn->query($sql);
		$row    = $result->fetch_row();
		return $row[0] ?? false;
	}

	function finddata ($table, $where=null)
	{
		global $conn;
		$sql = "SELECT * FROM $table WHERE $where LIMIT 1";
		$result = $conn->query($sql);
		$row    = $result->fetch_assoc();
		return $row ?? false;
	}

	function selectAll ($table, $where=null)
	{
		global $conn;
		$sql = "SELECT * FROM $table";
		$result = $conn->query($sql);
		$rows   =  $result->fetch_all();
		return $rows ?? false;
	}
?>