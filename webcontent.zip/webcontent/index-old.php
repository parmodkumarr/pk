<?php
 //$html2TextConverter = new \Html2Text\Html2Text($html);
 require 'vendor/autoload.php';
use Html2Text\Html2Text;

function getPageContent($pageUrl){  
     $ch = curl_init();
     curl_setopt($ch,CURLOPT_URL,$pageUrl);
     curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.12) Gecko/20080201 Firefox/2.0.0.12');
     curl_setopt($ch,CURLOPT_HEADER,0);
     curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
     curl_setopt($ch,CURLOPT_FOLLOWLOCATION,0);
     curl_setopt($ch,CURLOPT_TIMEOUT,120);
     $html = curl_exec($ch);
     curl_close($ch);
     return $html;
}
$urll ='https://technodeviser.com/';
$html = getPageContent($urll);
function linkExtractor($html){
     $linkArray = array();
     if(preg_match_all('/<a\s+.*?href=[\"\']?([^\"\' >]*)[\"\']?[^>]*>(.*?)<\/a>/i', $html, $matches, PREG_SET_ORDER)){
          foreach ($matches as $match) {
               $text = $match[2];
               $linkArray[$text]=$match[1];
          }
     }
     return $linkArray;
}

//echo '<pre>' . print_r(linkExtractor(getPageContent('https://www.indeedhost.seller2seller.com/')), true) . '<pre>';
//echo getTitle($html);

function getTitle($data) {
     //$data = file_get_contents($url);
     $title = preg_match('/<title[^>]*>(.*?)<\/title>/ims', $data, $matches) ? $matches[1] : null;
     return $title;
}

// getMetaTages($html);
function getMetaTages($url){
     $tags = get_meta_tags($url);
     return $tags;
     // return @($tags['description'] ? $tags['description'] : "NULL");
}


function getImgAlts($url) {
     $alts=array();
     $dom = new DOMDocument('1.0');    
     @$dom->loadHTMLFile($url);

     $anchors = $dom -> getElementsByTagName('img');

     foreach ($anchors as $element) {
          $src = $element -> getAttribute('src');
          $alt = $element -> getAttribute('alt');
          if($alt){
               array_push($alts,$alt);
          }
     }
      return $alts;
} 


function fnextractHeadins($headingtag, $html)
{
     $headingText = '';
     preg_match_all( '|<'.$headingtag.'>(.*)</'.$headingtag.'>|iU', $html, $headings );
     foreach($headings[0] as $headh2val)
     {
          $headingText.=$headh2val;
     }
     return $headingText;
}

function countTotalTwoWord($html){
     $mystr = strip_tags(strtolower($html));
    $text = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $mystr)));
    $testarr =explode(' ', $text);
     //echo"<pre>";print_r($testarr);die;
     //$test = array_count_values(str_word_count(strip_tags(strtolower($html)), 1));
    // $testarr = array_keys($test);
     $i=0;
     $dataarr=array();
     foreach($testarr as $key=>$value){
          if($key < count($testarr)-1){
               array_push($dataarr,$testarr[$key].' '.$testarr[$key+1]);
          }
          
     }
     
     $countarr = array_count_values($dataarr);
     foreach($countarr as $key=>$value2){
          if($value2 == 1 || $value2 == 0){
               unset($countarr[$key]);
          }
     }
     return $countarr;
    // return array_count_values(str_word_count(strip_tags(strtolower($html)), 1));
}


function countTotalThreeWord($html){
     $mystr = strip_tags(strtolower($html));
    $text = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $mystr)));
    $testarr =explode(' ', $text);
     $i=0;
     $dataarr=array();
     foreach($testarr as $key=>$value){
          if($key < count($testarr)-2){
               array_push($dataarr,$testarr[$key].' '.$testarr[$key+1].' '.$testarr[$key+2]);
          }
          
     }
     $countarr = array_count_values($dataarr);
     foreach($countarr as $key=>$value2){
          if($value2 == 1 || $value2 == 0){
               unset($countarr[$key]);
          }
     }
     return $countarr;
}
 
function getContent($html){ 
 echo strip_tags($html,'<div>');
}

function test($str){
     //Parse the html data
     $dom = new DOMDocument('1.0', 'UTF-8');
     @$dom->loadHTML($str);

     $xpath = new DOMXpath($dom);

     //Get only those divs which have class=item
     $div_list = $xpath->query('//div');

     $content_arr = []; 
     foreach($div_list as $d){
          $c = explode(": ", $d->nodeValue);
          $content_arr[$c[0]] = $c[1];
     }

     return $content_arr;
}

     function getTagContent($tag, $html)
  {
    preg_match_all("/$tag(.*?)<\/$tag>/s", $html, $matches);
   return $matches[1];
  }
  //getContent($html);  

    function removeScript($html)
  {
    return preg_replace('#<script(.*?)>(.*?)</script>#is', '', $html);
  }

  function removeStyle($html)
  {
    return preg_replace('#<style(.*?)>(.*?)</style>#is', '', $html);
  }

    function removeTag($tag, $html)
  {
    return preg_replace("#<$tag(.*?)>(.*?)</$tag>#is", '', $html);
  }

    function countTotalTwoWord2($html)
  {
    $html = removeScript($html);
    $html = removeStyle($html);
    $html = removeTag('head', $html);
    $mystr = strip_tags(strtolower($html),'<div>');
    echo'dddddddddd'. $html;die('dddddddddd');
    $text = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $mystr)));
    $testarr =explode(' ', $text);
    $i=0;
    $dataarr=array();
    foreach($testarr as $key=>$value)
    {
      if($key < count($testarr)-1)
      {
        array_push($dataarr,$testarr[$key].' '.$testarr[$key+1]);
      }    
    }
    $countarr = array_count_values($dataarr);
    foreach($countarr as $key=>$value2)
    {
      if($value2 == 1 || $value2 == 0)
      {
        unset($countarr[$key]);
      }
    }
    return $countarr;
  }

  function clean($text){
     // $dom = new DOMDocument();    
     // @$dom->loadHTML($text);
     // $plainText = strip_tags($dom->textContent);
     // $sr = new Html2Text();
     // echo $sr->convert($text);

     echo preg_replace( "/\n\s+/", "\n", rtrim(html_entity_decode(strip_tags($text))) );

}

 clean($html);
//echo"<pre>";print_r($alt);die('ss');