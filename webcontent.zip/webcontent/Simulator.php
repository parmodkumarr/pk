<?php
require 'vendor/autoload.php';
use Html2Text\Html2Text;

class Simulator {

  public $variable;

  function getPageContent($pageUrl)
  {
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$pageUrl);
    curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.12) Gecko/20080201 Firefox/2.0.0.12');
    curl_setopt($ch,CURLOPT_HEADER,0);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_FOLLOWLOCATION,0);
    curl_setopt($ch,CURLOPT_TIMEOUT,120);
    $html = curl_exec($ch);
    curl_close($ch);
    return $html;
  }

  function linkExtractor($html)
  {
    $linkArray = array();
    if(preg_match_all('/<a\s+.*?href=[\"\']?([^\"\' >]*)[\"\']?[^>]*>(.*?)<\/a>/i', $html, $matches, PREG_SET_ORDER))
    {
      foreach ($matches as $match)
      { 
        $text = strip_tags($match[2]);
        $linkArray[$text]=$match[1];
      }
    }
    return $linkArray;
  }

  function getTitle($data)
  {
    $title = preg_match('/<title[^>]*>(.*?)<\/title>/ims', $data, $matches) ? $matches[1] : null;
    return $title;
  }

  function getMetaTages($url='')
  {
    if($url !=''){
      $tags = get_meta_tags($url);
      //return $tags;
      return @($tags['description'] ? $tags['description'] : "No Meta Description Defined");
    }else{
      return "No Meta Description Defined";
    }  
  }

  function getImgAlts($url)
  {
    $alts=array();
    $dom = new DOMDocument('1.0');
    @$dom->loadHTMLFile($url);
    $anchors = $dom->getElementsByTagName('img');

    foreach ($anchors as $element)
    {
      $src = $element->getAttribute('src');
      $alt = $element->getAttribute('alt');
      if($alt)
      {
        array_push($alts,$alt);
      }
    }
    return $alts;
  }

  function fnextractHeadins($headingtag, $html)
  {
    $headingText = '';
    preg_match_all( '|<'.$headingtag.'>(.*)</'.$headingtag.'>|iU', $html, $headings );
    foreach($headings[0] as $headh2val)
    {
      $headingText.=strip_tags($headh2val).'<br>';
    }
    return $headingText;
  }

  function countTotalTwoWord($html)
  {
    $html = $this->removeScript($html);
    $html = $this->removeStyle($html);
    $html = $this->RemoveSpecialChar($html);
    $mystr = strip_tags(strtolower($html));
    $text = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $mystr)));
    $testarr =explode(' ', $text);
    $i=0;
    $dataarr=array();
    foreach($testarr as $key=>$value)
    {
      if($key < count($testarr)-1)
      {
        array_push($dataarr,$testarr[$key].' '.$testarr[$key+1]);
      }    
    }
    $countarr = array_count_values($dataarr);
    foreach($countarr as $key=>$value2)
    {
      if($value2 == 1 || $value2 == 0)
      {
        unset($countarr[$key]);
      }
    }
    return $countarr;
  }

  function countTotalThreeWord($html)
  {
    $html = $this->removeScript($html);
    $html = $this->removeStyle($html);
    $html = $this->removeAttribute($html);
    $html = $this->RemoveSpecialChar($html);
    $mystr = strip_tags(strtolower($html));
    $text = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $mystr)));
    $testarr =explode(' ', $text);
    $i=0;
    $dataarr=array();
    foreach($testarr as $key=>$value){
      if($key < count($testarr)-2){
        array_push($dataarr,$testarr[$key].' '.$testarr[$key+1].' '.$testarr[$key+2]);
      }
    }
    $countarr = array_count_values($dataarr);
    foreach($countarr as $key=>$value2){
      if($value2 == 1 || $value2 == 0){
        unset($countarr[$key]);
      }
    }
    return $countarr;
  }

  function getContent($html,$tags='')
  {
    $html = $this->removeScript($html);
    $html = $this->removeStyle($html);
    $html = $this->removeAttribute($html);
    $text = strip_tags($html,$tags);
    $text = $this->replaceTag('div','br',$text);
    return preg_replace("/<([a-z][a-z0-9]*)[^>]*?(\/?)>/si",'<$1$2>', $text);
  }

  function allWord($html,$unique=false)
  {
    $html = $this->RemoveSpecialChar($html);
    $mystr = strip_tags(strtolower($html));
    $text = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $mystr)));
    if($unique){
      return count(array_unique(str_word_count($text, 1)));
    }
    return str_word_count($text);
  }

  function removeHead($html)
  {
    return preg_replace('#<head(.*?)>(.*?)</head>#is', '', $html);
  }

  function removeScript($html)
  {
    return preg_replace('#<script(.*?)>(.*?)</script>#is', '', $html);
  }

  function removeStyle($html)
  {
    return preg_replace('#<style(.*?)>(.*?)</style>#is', '', $html);
  }

  function removeTag($tag, $html)
  {
    return preg_replace("#<$tag(.*?)>(.*?)</$tag>#is", '', $html);
  }

  function replaceTag($tag, $to, $html)
  {
    return preg_replace("/<$tag\s(.+?)>(.+?)<\/$tag>/is", "<$to>$2</$to>", $html);
  }

  function removeAttribute($html)
  {
    return preg_replace("/<([a-z][a-z0-9]*)[^>]*?(\/?)>/si",'<$1$2>', $html);
  }


  function getTagContent($tag, $html)
  {
    preg_match_all("/$tag(.*?)<\/$tag>/s", $html, $matches);
    print_r($matches[1]);
  }

  function getstring($html)
  {
    return preg_replace('/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s', ' ', $html);
  }

  function RemoveSpecialChar($html) {

    $res = preg_replace('/\[\[(\w+)\[\]/' , '$1' , $html);
      
    return $res;
    }

}


?>