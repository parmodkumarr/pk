<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="google-site-verification" content="<meta name=" google-site-verification" content="vt71JMwdrRR-RyEV3I3XiXrOLUKqpzknvxPmoRAlZ-0" />
      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="602628bac18f9de0e8cae51b-text/javascript"></script> <script type="602628bac18f9de0e8cae51b-text/javascript">(adsbygoogle = window.adsbygoogle || []).push({
         google_ad_client: "ca-pub-1956607837909229",
         enable_page_level_ads: true
         });
      </script>
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-98282554-1" type="602628bac18f9de0e8cae51b-text/javascript"></script> <script type="602628bac18f9de0e8cae51b-text/javascript">window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         gtag('config', 'UA-98282554-1');
      </script>
      <script type="602628bac18f9de0e8cae51b-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
         new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
         j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
         'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
         })(window,document,'script','dataLayer','GTM-WRVW445');
      </script> 
      <title>Website Development &amp; Digital Marketing Agency in Panchkula</title>
      <style id="rocket-critical-css">#portfoliolist .portfolio{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;-o-box-sizing:border-box;width:23%;margin:1%;display:none;float:left;overflow:hidden}.portfolio-wrapper{overflow:hidden;position:relative!important;background:#666}.portfolio img{max-width:100%;position:relative;top:0}.portfolio .label{position:absolute;width:100%;height:40px;bottom:-40px;display:block}.portfolio .label-bg{background:#217fbb;width:100%;height:100%;position:absolute;top:0;left:0}.portfolio .label-text{color:#fff;position:relative;z-index:500;padding:5px 8px;font-size:14px}.text-title{color:#fff}.portfolio .text-category{color:#000;display:block;font-size:11px;line-height:18px}@media only screen and (max-width:767px){#portfoliolist .portfolio{width:48%;margin:1%}}.container:after{content:"\0020";display:block;height:0;clear:both;visibility:hidden}.row:before,.row:after{content:'\0020';display:block;overflow:hidden;visibility:hidden;width:0;height:0}.row:after{clear:both}.row{zoom:1}[data-aos^=fade][data-aos^=fade]{opacity:0}[data-aos=fade-up]{transform:translateY(100px)}html{font-family:sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}body{margin:0}header,hgroup,nav{display:block}a{background-color:transparent}h1{margin:.67em 0;font-size:2em}small{font-size:80%}img{border:0}button,input{margin:0;font:inherit;color:inherit}button{overflow:visible}button{text-transform:none}button{-webkit-appearance:button}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}input{line-height:normal}@font-face{font-family:'Glyphicons Halflings';src:url(https://technodeviser.com/wp-content/themes/avail/assets/fonts/glyphicons-halflings-regular.eot);src:url(https://technodeviser.com/wp-content/themes/avail/assets/fonts/glyphicons-halflings-regular.eot?#iefix) format('embedded-opentype'),url(https://technodeviser.com/wp-content/themes/avail/assets/fonts/glyphicons-halflings-regular.woff2) format('woff2'),url(https://technodeviser.com/wp-content/themes/avail/assets/fonts/glyphicons-halflings-regular.woff) format('woff'),url(https://technodeviser.com/wp-content/themes/avail/assets/fonts/glyphicons-halflings-regular.ttf) format('truetype'),url(https://technodeviser.com/wp-content/themes/avail/assets/fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular) format('svg')}.glyphicon{position:relative;top:1px;display:inline-block;font-family:'Glyphicons Halflings';font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.glyphicon-chevron-up:before{content:"\e113"}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}:after,:before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}html{font-size:10px}body{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}button,input{font-family:inherit;font-size:inherit;line-height:inherit}a{color:#337ab7;text-decoration:none}img{vertical-align:middle}.carousel-inner>.item>img,.img-responsive{display:block;max-width:100%;height:auto}h1,h3,h4{font-family:inherit;font-weight:500;line-height:1.1;color:inherit}h1,h3{margin-top:20px;margin-bottom:10px}h4{margin-top:10px;margin-bottom:10px}h1{font-size:36px}h3{font-size:24px}h4{font-size:18px}p{margin:0 0 10px}small{font-size:85%}ul{margin-top:0;margin-bottom:10px}ul ul{margin-bottom:0}blockquote{padding:10px 20px;margin:0 0 20px;font-size:17.5px;border-left:5px solid #eee}blockquote small{display:block;font-size:80%;line-height:1.42857143;color:#777}blockquote small:before{content:'\2014 \00A0'}.container{padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}@media (min-width:768px){.container{width:750px}}@media (min-width:992px){.container{width:970px}}@media (min-width:1200px){.container{width:1170px}}.row{margin-right:-15px;margin-left:-15px}.col-md-5,.col-md-7,.col-md-8,.col-sm-12,.col-sm-6{position:relative;min-height:1px;padding-right:15px;padding-left:15px}@media (min-width:768px){.col-sm-12,.col-sm-6{float:left}.col-sm-12{width:100%}.col-sm-6{width:50%}}@media (min-width:992px){.col-md-5,.col-md-7,.col-md-8{float:left}.col-md-8{width:66.66666667%}.col-md-7{width:58.33333333%}.col-md-5{width:41.66666667%}.col-md-offset-2{margin-left:16.66666667%}}.btn{display:inline-block;padding:6px 12px;margin-bottom:0;font-size:14px;font-weight:400;line-height:1.42857143;text-align:center;white-space:nowrap;vertical-align:middle;-ms-touch-action:manipulation;touch-action:manipulation;background-image:none;border:1px solid transparent;border-radius:4px}.btn-primary{color:#fff;background-color:#337ab7;border-color:#2e6da4}.btn-lg{padding:10px 16px;font-size:18px;line-height:1.3333333;border-radius:6px}.fade{opacity:0}.fade.in{opacity:1}.navbar{position:relative;min-height:50px;margin-bottom:20px;border:1px solid transparent}@media (min-width:768px){.navbar{border-radius:4px}}@media (min-width:768px){.navbar-header{float:left}}.navbar-brand{float:left;height:50px;padding:15px 15px;font-size:18px;line-height:20px}.navbar-brand>img{display:block}.navbar-default{background-color:#f8f8f8;border-color:#e7e7e7}.navbar-default .navbar-brand{color:#777}.label{display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em}.close{float:right;font-size:21px;font-weight:700;line-height:1;color:#000;text-shadow:0 1px 0 #fff;filter:alpha(opacity=20);opacity:.2}button.close{-webkit-appearance:none;padding:0;background:0 0;border:0}.modal{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1050;display:none;overflow:hidden;-webkit-overflow-scrolling:touch;outline:0}.modal.fade .modal-dialog{-webkit-transform:translate(0,-25%);-ms-transform:translate(0,-25%);-o-transform:translate(0,-25%);transform:translate(0,-25%)}.modal.in .modal-dialog{-webkit-transform:translate(0,0);-ms-transform:translate(0,0);-o-transform:translate(0,0);transform:translate(0,0)}.modal-dialog{position:relative;width:auto;margin:10px}.modal-content{position:relative;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #999;border:1px solid rgba(0,0,0,.2);border-radius:6px;outline:0;-webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);box-shadow:0 3px 9px rgba(0,0,0,.5)}.modal-header{padding:15px;border-bottom:1px solid #e5e5e5}.modal-header .close{margin-top:-2px}.modal-title{margin:0;line-height:1.42857143}.modal-body{position:relative;padding:15px}@media (min-width:768px){.modal-dialog{width:600px;margin:30px auto}.modal-content{-webkit-box-shadow:0 5px 15px rgba(0,0,0,.5);box-shadow:0 5px 15px rgba(0,0,0,.5)}}.carousel{position:relative}.carousel-inner{position:relative;width:100%;overflow:hidden}.carousel-inner>.item{position:relative;display:none}.carousel-inner>.item>img{line-height:1}@media all and (transform-3d),(-webkit-transform-3d){.carousel-inner>.item{-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-perspective:1000px;perspective:1000px}.carousel-inner>.item.active{left:0;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}}.carousel-inner>.active{display:block}.carousel-inner>.active{left:0}.container:after,.container:before,.modal-header:after,.modal-header:before,.navbar-header:after,.navbar-header:before,.navbar:after,.navbar:before,.row:after,.row:before{display:table;content:" "}.container:after,.modal-header:after,.navbar-header:after,.navbar:after,.row:after{clear:both}@-ms-viewport{width:device-width}.wp-block-media-text .wp-block-media-text__media{grid-area:media-text-media;margin:0}.wp-block-media-text .wp-block-media-text__content{word-break:break-word;grid-area:media-text-content;padding:0 8%}div.wpcf7-response-output{margin:2em .5em 1em;padding:.2em 1em;border:2px solid red}.wpcf7-display-none{display:none}#mega-menu-wrap-top,#mega-menu-wrap-top #mega-menu-top,#mega-menu-wrap-top #mega-menu-top ul.mega-sub-menu,#mega-menu-wrap-top #mega-menu-top li.mega-menu-item,#mega-menu-wrap-top #mega-menu-top a.mega-menu-link{-webkit-border-radius:0 0 0 0;-moz-border-radius:0 0 0 0;-ms-border-radius:0 0 0 0;-o-border-radius:0 0 0 0;border-radius:0 0 0 0;-webkit-box-shadow:none;-moz-box-shadow:none;-ms-box-shadow:none;-o-box-shadow:none;box-shadow:none;background:none;border:0;bottom:auto;box-sizing:border-box;clip:auto;color:#777;display:block;float:none;font-family:inherit;font-size:13px;height:auto;left:auto;line-height:1.7;list-style-type:none;margin:0;min-height:0;opacity:1;outline:none;overflow:visible;padding:0;position:relative;right:auto;text-align:left;text-decoration:none;text-transform:none;top:auto;vertical-align:baseline;visibility:inherit;width:auto}#mega-menu-wrap-top:before,#mega-menu-wrap-top #mega-menu-top:before,#mega-menu-wrap-top #mega-menu-top ul.mega-sub-menu:before,#mega-menu-wrap-top #mega-menu-top li.mega-menu-item:before,#mega-menu-wrap-top #mega-menu-top a.mega-menu-link:before,#mega-menu-wrap-top:after,#mega-menu-wrap-top #mega-menu-top:after,#mega-menu-wrap-top #mega-menu-top ul.mega-sub-menu:after,#mega-menu-wrap-top #mega-menu-top li.mega-menu-item:after,#mega-menu-wrap-top #mega-menu-top a.mega-menu-link:after{display:none}#mega-menu-wrap-top{background:rgba(255,255,255,0);-webkit-border-radius:0 0 0 0;-moz-border-radius:0 0 0 0;-ms-border-radius:0 0 0 0;-o-border-radius:0 0 0 0;border-radius:0 0 0 0}#mega-menu-wrap-top #mega-menu-top{visibility:visible;text-align:right;padding:0 0 0 0}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top{background:rgba(241,241,241,0)}}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top{padding:0}}#mega-menu-wrap-top #mega-menu-top a.mega-menu-link{display:inline}#mega-menu-wrap-top #mega-menu-top li.mega-menu-item>ul.mega-sub-menu{display:block;visibility:hidden;opacity:1}@media only screen and (min-width:768px){#mega-menu-wrap-top #mega-menu-top[data-effect="fade_up"] li.mega-menu-item.mega-menu-megamenu>ul.mega-sub-menu{opacity:0;margin-top:10px}}#mega-menu-wrap-top #mega-menu-top li.mega-menu-item a.mega-menu-link:before{display:inline-block;font:inherit;font-family:dashicons;position:static;margin:0 6px 0 0;vertical-align:top;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;color:inherit}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu.mega-menu-item{position:static}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-item{margin:0 0 0 0;display:inline-block;height:auto;vertical-align:middle}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-item.mega-current-menu-item>a.mega-menu-link{background:rgba(255,255,255,0);color:#217fbb;font-weight:700;text-decoration:none;border-color:#fff}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-item>a.mega-menu-link{border-top:0 solid rgba(241,241,241,0);border-left:0 solid rgba(241,241,241,0);border-right:0 solid rgba(241,241,241,0);border-bottom:0 solid rgba(241,241,241,0);outline:none;text-decoration:none;padding:0 10px 0 10px;line-height:40px;font-weight:700;height:40px;vertical-align:baseline;text-align:center;width:auto;display:block;color:#fff;text-transform:uppercase;text-decoration:none;background:rgba(0,0,0,0);-webkit-border-radius:0 0 0 0;-moz-border-radius:0 0 0 0;-ms-border-radius:0 0 0 0;-o-border-radius:0 0 0 0;border-radius:0 0 0 0;font-family:inherit;font-size:14px}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top>li.mega-menu-item>a.mega-menu-link{text-align:left;color:#217fbb;font-size:14px}}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top>li.mega-menu-item{display:list-item;margin:0;clear:both;border:0}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-item>a.mega-menu-link{-webkit-border-radius:0 0 0 0 0 0 0;-moz-border-radius:0 0 0 0 0 0 0;-ms-border-radius:0 0 0 0 0 0 0;-o-border-radius:0 0 0 0 0 0 0;border-radius:0 0 0 0 0 0 0;border:0;margin:0;line-height:40px;height:40px;padding:0 10px}}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu{z-index:999;-webkit-border-radius:0 0 0 0;-moz-border-radius:0 0 0 0;-ms-border-radius:0 0 0 0;-o-border-radius:0 0 0 0;border-radius:0 0 0 0;background:#f1f1f1;padding:0 0 0 0;position:absolute;width:100%;border-top:0 solid rgba(241,241,241,0);border-left:0 solid rgba(241,241,241,0);border-right:1px solid rgba(241,241,241,0);border-bottom:0 solid rgba(241,241,241,0);max-width:none;left:0}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu{float:left;position:static;width:100%}}@media only screen and (min-width:768px){#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu li.mega-menu-columns-1-of-4{width:25%}}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu>li.mega-menu-item{color:#777;font-family:inherit;font-size:13px;display:block;float:left;clear:none;padding:15px 15px 15px 15px;vertical-align:top}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu>li.mega-menu-item h4.mega-block-title{color:#222;font-family:inherit;font-size:16px;text-transform:capitalize;text-decoration:none;font-weight:700;margin:0 0 0 0;padding:0 0 15px 0;vertical-align:top;display:block;border-top:0 solid #555;border-left:0 solid #555;border-right:0 solid #555;border-bottom:0 solid #555}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu{border:0;padding:10px;-webkit-border-radius:0 0 0 0;-moz-border-radius:0 0 0 0;-ms-border-radius:0 0 0 0;-o-border-radius:0 0 0 0;border-radius:0 0 0 0}#mega-menu-wrap-top #mega-menu-top>li.mega-menu-megamenu>ul.mega-sub-menu>li.mega-menu-item{width:100%;clear:both}}#mega-menu-wrap-top #mega-menu-top li.mega-menu-item-has-children>a.mega-menu-link:after{content:'\f140';display:inline-block;font-family:dashicons;margin:0 0 0 6px;vertical-align:top;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;transform:rotate(0);color:inherit}@media only screen and (max-width:767px){#mega-menu-wrap-top #mega-menu-top li.mega-menu-item-has-children a.mega-menu-link:after{float:right}}#mega-menu-wrap-top .mega-menu-toggle{display:none;z-index:1;background:rgba(241,241,241,0);-webkit-border-radius:2px 2px 2px 2px;-moz-border-radius:2px 2px 2px 2px;-ms-border-radius:2px 2px 2px 2px;-o-border-radius:2px 2px 2px 2px;border-radius:2px 2px 2px 2px;line-height:40px;height:40px;text-align:left;-webkit-touch-callout:none;outline:none;white-space:nowrap}@media only screen and (max-width:767px){#mega-menu-wrap-top .mega-menu-toggle{display:flex}}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-left,#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-center,#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-right{display:flex;flex-basis:33.33%}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-left{flex:1;justify-content:flex-start}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-center{justify-content:center}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-right{flex:1;justify-content:flex-end}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-blocks-right .mega-toggle-block{margin-right:6px}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block{display:flex;height:100%;flex-shrink:0}@media only screen and (max-width:767px){#mega-menu-wrap-top .mega-menu-toggle+#mega-menu-top{display:none}#mega-menu-wrap-top .mega-menu-toggle+#mega-menu-top li.mega-menu-item>ul.mega-sub-menu{display:none;visibility:visible;opacity:1}}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-1:after{content:'\f333';font-family:'dashicons';font-size:24px;color:#217fbb;margin:0 0 0 5px}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-label{color:#217fbb;font-size:14px}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-label .mega-toggle-label-open{display:none}#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-label .mega-toggle-label-closed{display:inline}#mega-menu-wrap-top{clear:both}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTa-j2U0lmluP9RWlSytm3ho.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTZX5f-9o1vgP2EXwfjgl7AY.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTRWV49_lSm1NYrwo-zkhivY.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTaaRobkAwv3vxw3jMhVENGA.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTf8zf_FOSsgRmwsS7Aa9k2w.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTT0LW-43aMEzIO6XUTLjad8.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:300;src:local('Open Sans Light'),local('OpenSans-Light'),url(https://fonts.gstatic.com/s/opensans/v14/DXI1ORHCpsQm3Vp6mXoaTegdm0LZdjqr5-oayXSOefg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/K88pR3goAWT7BTt32Z01mxJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/RjgO7rYTmqiVp7vzi-Q5URJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/LWCjsQkB6EMdfHrEVqA1KRJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/xozscpT2726on7jbcb_pAhJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/59ZRklaO5bWGqF5A9baEERJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/u-WUoqrET9fUeobQW7jkRRJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v14/cJZKeOuBrn4kERxqtaUH3VtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNSq-j2U0lmluP9RWlSytm3ho.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNSpX5f-9o1vgP2EXwfjgl7AY.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNShWV49_lSm1NYrwo-zkhivY.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNSqaRobkAwv3vxw3jMhVENGA.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNSv8zf_FOSsgRmwsS7Aa9k2w.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNSj0LW-43aMEzIO6XUTLjad8.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:600;src:local('Open Sans SemiBold'),local('OpenSans-SemiBold'),url(https://fonts.gstatic.com/s/opensans/v14/MTP_ySUJH_bn48VBG8sNSugdm0LZdjqr5-oayXSOefg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzK-j2U0lmluP9RWlSytm3ho.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzJX5f-9o1vgP2EXwfjgl7AY.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzBWV49_lSm1NYrwo-zkhivY.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzKaRobkAwv3vxw3jMhVENGA.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzP8zf_FOSsgRmwsS7Aa9k2w.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzD0LW-43aMEzIO6XUTLjad8.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:700;src:local('Open Sans Bold'),local('OpenSans-Bold'),url(https://fonts.gstatic.com/s/opensans/v14/k3k702ZOKiLJc3WVjuplzOgdm0LZdjqr5-oayXSOefg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hq-j2U0lmluP9RWlSytm3ho.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hpX5f-9o1vgP2EXwfjgl7AY.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hhWV49_lSm1NYrwo-zkhivY.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hqaRobkAwv3vxw3jMhVENGA.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hv8zf_FOSsgRmwsS7Aa9k2w.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hj0LW-43aMEzIO6XUTLjad8.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:normal;font-weight:800;src:local('Open Sans ExtraBold'),local('OpenSans-ExtraBold'),url(https://fonts.gstatic.com/s/opensans/v14/EInbV5DfGHOiMmvb1Xr-hugdm0LZdjqr5-oayXSOefg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxhgVThLs8Y7ETJzDCYFCSLE.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxpiMaisvaUVUsYyVzOmndek.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxrBAWGjcah5Ky0jbCgIwDB8.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxv14vlcfyPYlAcQy2UfDRm4.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxqfJul7RR1X4poJgi27uS4w.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxqvyPXdneeGd26m9EmFSSWg.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:300;src:local('Open Sans Light Italic'),local('OpenSans-LightItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxko2lTMeWA_kmIyWrkNCwPc.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBjTOQ_MqJVwkKsUn0wKzc2I.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBjUj_cnvWIuuBMVgbX098Mw.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBkbcKLIaa1LC45dFaAfauRA.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBmo_sUJ8uO4YLWRInS22T3Y.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBr6up8jxqWt8HVA3mDhkV_0.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBiYE0-AqJ3nfInTTiDXDjU4.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:400;src:local('Open Sans Italic'),local('OpenSans-Italic'),url(https://fonts.gstatic.com/s/opensans/v14/xjAJXh38I15wypJXxuGMBo4P5ICox8Kq3LLUNMylGO4.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxmgpAmOCqD37_tyH_8Ri5MM.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxsPNMTLbnS9uQzHQlYieHUU.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxgyhumQnPMBCoGYhRaNxyyY.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxhUVAXEdVvYDDqrz3aeR0Yc.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxlf4y_3s5bcYyyLIFUSWYUU.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxnywqdtBbUHn3VPgzuFrCy8.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:600;src:local('Open Sans SemiBold Italic'),local('OpenSans-SemiBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxl2umOyRU7PgRiv8DXcgJjk.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxp6iIh_FvlUHQwED9Yt5Kbw.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxi_vZmeiCMnoWNN9rHBYaTc.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxiFaMxiho_5XQnyRZzQsrZs.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxgalQocB-__pDVGhF3uS2Ks.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxmhQUTDJGru-0vvUpABgH8I.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxujkDdvhIIFj_YMdgqpnSB0.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:700;src:local('Open Sans Bold Italic'),local('OpenSans-BoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxolIZu-HDpmDIZMigmsroc4.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxiU8QAtQT9M0M1_mbVWrUPc.woff2) format('woff2');unicode-range:U+0460-052F,U+20B4,U+2DE0-2DFF,U+A640-A69F}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxkNaUOL0oYRolx8sebiIY9k.woff2) format('woff2');unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxooGEx1DzoxsbCRd2IM2afI.woff2) format('woff2');unicode-range:U+1F00-1FFF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxnPzCMEhbIaaYiFY6KPniws.woff2) format('woff2');unicode-range:U+0370-03FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxmqi69zMYkLa7XwlUIemKB4.woff2) format('woff2');unicode-range:U+0102-0103,U+1EA0-1EF9,U+20AB}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxowYyzpnB4tyYboSwKGmD2g.woff2) format('woff2');unicode-range:U+0100-024F,U+1E00-1EFF,U+20A0-20AB,U+20AD-20CF,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'Open Sans';font-style:italic;font-weight:800;src:local('Open Sans ExtraBold Italic'),local('OpenSans-ExtraBoldItalic'),url(https://fonts.gstatic.com/s/opensans/v14/PRmiXeptR36kaC0GEAetxnibbpXgLHK_uTT48UMyjSM.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2212,U+2215}html,body,div,span,iframe,h1,h3,h4,p,blockquote,a,img,small,i,ul,li,header,hgroup,nav{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}header,hgroup,nav{display:block}body{line-height:1}ul{list-style:none}blockquote{quotes:none}blockquote:before,blockquote:after{content:'';content:none}*{margin:0;padding:0;box-sizing:border-box;outline:0}body{font-family:'Open Sans',sans-serif;font-size:14px;color:#333;font-weight:600;line-height:20px;background:#fff;overflow-x:hidden}a{color:#217fbb;text-decoration:none;outline:0}p{margin-bottom:10px;font-weight:500;color:#777;line-height:24px}h1,h3,h4{margin-bottom:15px;font-weight:700;line-height:1}h1{font-size:45px}h3{font-size:30px}h4{font-size:24px}img{width:100%;margin-bottom:-5px}input{width:100%;height:34px;border:1px rgba(42,159,234,.35) solid;background:#f9f9f9;margin:10px 0;padding:0 10px;color:;line-height:}span{font-weight:700;color:#217fbb}.back-to-top{position:fixed;bottom:53px;right:10px;display:none;background:rgba(42,159,234,.9);border-color:rgba(42,159,234,.8);border-radius:0;padding:5px 10px;opacity:.6;z-index:1}.back-to-top .glyphicon{color:#fff}#home_about{display:block;padding:50px 0;position:relative}.hero span,.home_about_l span{font-weight:700;color:#217fbb}.contact_map iframe{display:block;position:relative;width:100%;box-shadow:0 10px 12px rgba(0,0,0,.2)}.icon_btn::before{content:"";font-family:FontAwesome;font-size:18px;left:-5px;padding:0 1px;position:absolute;transform:translateZ(0)}.icon_btn{box-shadow:0 0 1px transparent;display:inline-block;padding-left:1.2em;position:relative;transform:perspective(1px) translateZ(0);vertical-align:middle}.read_more::before{background:#306c88 none repeat scroll 0 0;bottom:0;content:"";left:0;position:absolute;right:0;top:0;transform:scaleX(0);transform-origin:0 50% 0;z-index:-1}.read_more{box-shadow:0 0 1px transparent;display:inline-block;position:relative;transform:perspective(1px) translateZ(0);vertical-align:middle}.scroll_btm{animation:2s ease 0s normal none infinite running sc_pulse;background:#fff none repeat scroll 0 0;border-radius:50%;bottom:20px;box-shadow:0 0 0 rgba(255,255,255,.7);display:block;height:35px;left:50%;position:absolute;width:35px;z-index:1;margin-left:-20px}.scroll_btm .fa{font-size:22px;padding-top:7px}.slid_sp{text-align:center}@-webkit-keyframes sc_pulse{0%{-webkit-box-shadow:0 0 0 0 rgba(42,159,234,.8)}70%{-webkit-box-shadow:0 0 0 10px rgba(42,159,234,0)}100%{-webkit-box-shadow:0 0 0 0 rgba(42,159,234,0)}}@keyframes sc_pulse{0%{-moz-box-shadow:0 0 0 0 rgba(42,159,234,.8);box-shadow:0 0 0 0 rgba(42,159,234,.8)}70%{-moz-box-shadow:0 0 0 10px rgba(42,159,234,0);box-shadow:0 0 0 10px rgba(42,159,234,0)}100%{-moz-box-shadow:0 0 0 0 rgba(42,159,234,0);box-shadow:0 0 0 0 rgba(42,159,234,0)}}#header_top{display:block;padding:10px 0;position:relative}.header_top_l li{display:inline-block;font-size:13px;font-weight:500;margin-right:7px;vertical-align:middle}.header_top_r li{display:inline-block;margin-left:;vertical-align:middle}.header_top_r{text-align:right}.header_top_r .fa{background:#217fbb none repeat scroll 0 0;border-radius:50%;color:#fff;font-size:12px;height:25px;line-height:25px;text-align:center;width:25px;overflow:hidden}.header_slider_o{position:relative}#header{display:block;position:absolute;background:;top:15px;width:100%;z-index:100}.navbar-default{background:none;border:0;margin-bottom:0}.navbar-default .navbar-brand{color:#fff;font-weight:700;text-transform:uppercase}.navbar-brand{padding:0}.navbar-brand>img{max-width:85px}.iso-logo img{width:80%;margin-top:15px;opacity:.7}#slider{display:block;position:relative}#slider .carousel-inner .item::before{background:rgba(0,0,0,.7) none repeat scroll 0 0;bottom:0;content:"";height:100%;position:absolute;top:0;width:100%;z-index:1}#slider .hero{position:absolute;top:50%;left:50%;z-index:3;color:#fff;text-align:center;text-transform:uppercase;text-shadow:1px 1px 0 rgba(0,0,0,.75);-webkit-transform:translate3d(-50%,-50%,0);-moz-transform:translate3d(-50%,-50%,0);-ms-transform:translate3d(-50%,-50%,0);-o-transform:translate3d(-50%,-50%,0);transform:translate3d(-50%,-50%,0)}#slider .carousel-fade .carousel-inner .item .hero{opacity:0}#slider .carousel-fade .carousel-inner .item.active .hero{opacity:1}.hero span{font-weight:700;color:#217fbb}#slider .hero h1{display:inline-block;position:relative}#slider .hero h1::before{background:#217fbb;content:"";height:2px;left:-30%;position:absolute;top:50%;width:70px}#slider .hero h1::after{background:#217fbb;content:"";height:2px;right:-30%;position:absolute;top:50%;width:70px}#slider .hero h3{font-weight:300;line-height:36px}@media screen and (min-width:991px){#slider .hero{width:1100px}}@media screen and (max-width:640px){#slider .hero h1{font-size:4em}}.carousel-fade .carousel-inner .item{opacity:0;overflow:hidden}.item.active img{transform:scale(1.1,1.1)}.carousel-fade .carousel-inner .active{opacity:1}@media all and (transform-3d),(-webkit-transform-3d){.carousel-fade .carousel-inner>.item.active{opacity:1;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}}#home_about{background:url(/wp-content/uploads/2017/05/about_bg.jpg) fixed no-repeat;background-size:cover;padding:50px 0}#home_about:before{position:absolute;content:"";background:rgba(238,238,238,.95);width:50%;height:100%;top:0;left:0;bottom:0}#home_about:after{position:absolute;content:"";background:rgba(255,255,255,.96);width:50%;height:100%;top:0;right:0;bottom:0}.heading_title>h3{font-weight:300;position:relative;padding:10px 0;display:inline-block}.home_about_l span{display:block;line-height:24px}.heading_title>h3::before{background:#217fbb;content:"";height:2px;position:absolute;top:0;width:75px}.build_img img{width:55px}.read_btn{background:#217fbb none repeat scroll 0 0;margin-top:15px;padding-left:15px}.icon_btn.icon_btn_2{color:#fff;padding:10px 15px 10px 25px;z-index:1;outline:0}.inner_bef::before{background:#306c88 none repeat scroll 0 0;content:"";height:100%;left:0;position:absolute;top:0;width:33px;z-index:1}.heading_title{padding:20px 0 20px;text-align:center}.service_img_blo .img_hold>img{border-radius:50%;box-shadow:0 0 10px 6px rgba(0,0,0,.1)}.item blockquote{border-left:none;margin:0}.item blockquote p:before{content:"\f10d";font-family:'Fontawesome';float:left;margin-right:5px;color:#217fbb;font-size:20px}#home_testimonial small{color:#217fbb}.select_li option{padding:0 10px}#home_project_work .modal-dialog{margin:80px auto 30px;max-width:1100px;width:100%}#home_project_work .modal-header{border:0 none;padding:8px 15px;position:absolute;right:16px;top:8px;z-index:1}#home_project_work .modal-body{padding:40px 20px;position:relative;border:10px solid rgba(42,159,234,.8)}#home_project_work .modal-content{border:0}#home_project_work .portfolio_decs{background:#eee none repeat scroll 0 0;padding:15px 15px}#home_project_work .port_tag{font-size:12px;margin-bottom:5px}#home_project_work .modal{background:rgba(42,159,234,.9)}#home_project_work button.close{background:#217fbb none repeat scroll 0 0;border:0 none;color:#fff;opacity:1;padding:0 8px 3px}.modal-content{box-shadow:0 5px 15px rgba(0,0,0,.5);margin:10px}@media only screen and (min-width:768px) and (max-width:991px){#slider .hero{left:10%;right:10%;top:30%}#slider .hero{transform:none}}@media (max-width:767px){.iso-logo img{width:40%!important;opacity:1}#header_top,.header_top_r{text-align:center}.header_top_l{margin-bottom:10px}#home_about::before{width:100%}#home_about::after{width:0}.home_about_l{margin-bottom:20px}#slider .hero{left:1%;right:1%;top:30%}#slider .hero h1::before,#slider .hero h1::after{width:25%}#slider .hero h1{font-size:30px}#slider .hero h3{font-size:18px;line-height:18px}#slider .hero{transform:none}.scroll_btm{bottom:-15px;margin-left:-20px}#header{background:#fff none repeat scroll 0 0;box-shadow:0 0 10px 0 rgba(0,0,0,.2);padding:10px 0;position:relative}#header{top:0}.navbar-brand>img{max-width:75px}.heading_title{padding-bottom:0}}@media (max-width:480px){#slider .hero{left:1%;right:1%;top:20%}#slider .hero h1{font-size:22px}#slider .hero h3{font-size:14px;line-height:15px}h3{font-size:24px}h4{font-size:22px}h1{font-size:32px}}@media (max-width:280px){#slider .hero{left:5%;right:5%;top:20%}#slider .hero h1{font-size:20px}#slider .hero h3{font-size:13px;line-height:13px}}.portfolio img{height:auto!important}.attachment-post-thumbnail.size-post-thumbnail.wp-post-image{height:100%}@media only screen and (min-width:768px) and (max-width:991px){.slider_text_c{color:#fff;font-size:15px;font-weight:700}}@media (max-width:480px){.slider_text_c{font-size:10px}}@media only screen and (min-width:687px) and (max-width:1024px){.read_btn.read_more{margin-top:40px}}@media only screen and (min-width:768px) and (max-width:1024px) and (orientation:landscape){.slider_text_c{font-size:20px;margin:65px}}.text-title{display:block;overflow:hidden;text-overflow:ellipsis;text-transform:capitalize}@media only screen and (min-width:768px) and (max-width:991px){#portfoliolist .portfolio{background:rgba(42,159,234,.8) none repeat scroll 0 0;margin:1% 1% 15px;padding:1px}}@media (max-width:480px){#portfoliolist .portfolio{background:rgba(42,159,234,.8) none repeat scroll 0 0;margin:1% 1% 15px;padding:1px}.portfolio .text-category{font-size:10px}.text-title{font-size:12px}.portfolio_decs span{overflow-wrap:break-word;text-transform:capitalize;font-size:20px}.portfolio .label-text{padding:5px 0}.text-title{font-size:12px}}@media (max-width:767px){.build_img img{margin-bottom:10px}}.slider_text_c{color:#fff}.td-certificate .modal-content{margin:10vh!important;border-radius:3px!important;border:0!important}@media only screen and (max-width:1024px){.td-certificate .modal-content{margin:10vh 2vh!important}}.mega-menu-item{line-height:40px!important}.menu_navi .navbar-header{position:absolute;z-index:10}.navbar .fa{padding-right:5px}.mega-sub-menu{padding:20px 10px!important}.mega-sub-menu .mega-menu-item{border-right:1px solid rgba(0,0,0,.2)!important;padding:15px!important}.mega-sub-menu .mega-menu-item:last-child{border:0!important}.mega2{border-bottom:1px solid rgba(0,0,0,.2)}.gap{margin-right:7px}@media only screen and (max-width:767px){#mega-menu-wrap-top .mega-menu-toggle{position:absolute;right:10px;margin-top:-42px}.mega-menu.mega-menu-horizontal{padding-top:20px!important}.menu_navi .navbar-header{position:relative!important;z-index:0!important;left:3%!important}.mega-sub-menu .mega-menu-item{border-right:0 solid rgba(0,0,0,.2)!important}.td-certificate .modal-content{margin:10vh 2vh!important}}.header_top_l li a{font-weight:600}.td-certificate .modal-dialog{max-width:750px!important;margin:0 auto!important;width:100%}.td-certificate .modal-body{padding:7px!important;background:#306c88;border-radius:3px}#myModal.td-certificate{background:rgba(42,159,234,.9)!important;padding:0!important}.moto{width:100%}.motoparagraph{width:100%;float:left;font-size:23px;text-align:center}.motoparagraph p{margin-bottom:10px;font-weight:500;color:#777;line-height:33px;margin-bottom:33px}.motoparagraph span{display:inline!important}</style>
      <script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="602628bac18f9de0e8cae51b-|49"></script>
      <link rel="preload" href="https://technodeviser.com/wp-content/cache/min/1/7cb7b959f170a73f88a8c8f04c96d2c9.css" as="style" onload="this.onload=null;this.rel='stylesheet'" data-minify="1" />
      <meta name="description" content="Techno Deviser Agency Provides Professional Website Development, Design, Mobile App Development &amp; SEO Services With Latest Technologies." />
      <link rel="canonical" href="https://technodeviser.com/" />
      <meta property="og:locale" content="en_US" />
      <meta property="og:type" content="website" />
      <meta property="og:title" content="Website Development &amp; Digital Marketing Agency in Panchkula" />
      <meta property="og:description" content="Techno Deviser Agency Provides Professional Website Development, Design, Mobile App Development &amp; SEO Services With Latest Technologies." />
      <meta property="og:url" content="https://technodeviser.com/" />
      <meta property="og:site_name" content="technodeviser" />
      <meta name="twitter:card" content="summary" />
      <meta name="twitter:description" content="Techno Deviser Agency Provides Professional Website Development, Design, Mobile App Development &amp; SEO Services With Latest Technologies." />
      <meta name="twitter:title" content="Website Development &amp; Digital Marketing Agency in Panchkula" />
      <script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://technodeviser.com/#organization","name":"","url":"https://technodeviser.com/","sameAs":[]},{"@type":"WebSite","@id":"https://technodeviser.com/#website","url":"https://technodeviser.com/","name":"technodeviser","publisher":{"@id":"https://technodeviser.com/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://technodeviser.com/?s={search_term_string}","query-input":"required name=search_term_string"}},{"@type":"WebPage","@id":"https://technodeviser.com/#webpage","url":"https://technodeviser.com/","inLanguage":"en-US","name":"Website Development &amp; Digital Marketing Agency in Panchkula","isPartOf":{"@id":"https://technodeviser.com/#website"},"about":{"@id":"https://technodeviser.com/#organization"},"datePublished":"2017-05-15T05:24:50+00:00","dateModified":"2017-05-17T11:35:36+00:00","description":"Techno Deviser Agency Provides Professional Website Development, Design, Mobile App Development & SEO Services With Latest Technologies."}]}</script> 
      <link rel='dns-prefetch' href='//www.google.com' />
      <link rel='dns-prefetch' href='//fonts.googleapis.com' />
      <link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
      <link rel="alternate" type="application/rss+xml" title="technodeviser &raquo; Feed" href="https://technodeviser.com/feed/" />
      <link rel="alternate" type="application/rss+xml" title="technodeviser &raquo; Comments Feed" href="https://technodeviser.com/comments/feed/" />
      <style type="text/css">img.wp-smiley,img.emoji{display:inline!important;border:none!important;box-shadow:none!important;height:1em!important;width:1em!important;margin:0 .07em!important;vertical-align:-0.1em!important;background:none!important;padding:0!important}</style>
      <script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="602628bac18f9de0e8cae51b-|49"></script>
      <link rel='preload' id='woocommerce-smallscreen-css' href='https://technodeviser.com/wp-content/cache/busting/1/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen-3.6.6.css' as="style" onload="this.onload=null;this.rel='stylesheet'" type='text/css' media='only screen and (max-width: 768px)' />
      <style id='woocommerce-inline-inline-css' type='text/css'>.woocommerce form .form-row .required{visibility:visible}</style>
      <script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="602628bac18f9de0e8cae51b-|49"></script>
      <link rel='preload' id='avail-fonts-css' href='https://fonts.googleapis.com/css?family=Libre+Franklin%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C800%2C800i&#038;subset=latin%2Clatin-ext' as="style" onload="this.onload=null;this.rel='stylesheet'" type='text/css' media='all' />
      <!--[if lt IE 9]>
      <link rel='preload' id='avail-ie8-css'  href='https://technodeviser.com/wp-content/themes/avail/assets/css/ie8.css?ver=1.0' as="style" onload="this.onload=null;this.rel='stylesheet'" type='text/css' media='all' />
      <![endif]-->
      <style id='rocket-lazyload-inline-css' type='text/css'>.rll-youtube-player{position:relative;padding-bottom:56.23%;height:0;overflow:hidden;max-width:100%}.rll-youtube-player iframe{position:absolute;top:0;left:0;width:100%;height:100%;z-index:100;background:0 0}.rll-youtube-player img{bottom:0;display:block;left:0;margin:auto;max-width:100%;width:100%;position:absolute;right:0;top:0;border:none;height:auto;cursor:pointer;-webkit-transition:.4s all;-moz-transition:.4s all;transition:.4s all}.rll-youtube-player img:hover{-webkit-filter:brightness(75%)}.rll-youtube-player .play{height:72px;width:72px;left:50%;top:50%;margin-left:-36px;margin-top:-36px;position:absolute;background:url(https://technodeviser.com/wp-content/plugins/wp-rocket/assets/img/youtube.png) no-repeat;cursor:pointer}</style>
      <script type="602628bac18f9de0e8cae51b-text/javascript" src='https://technodeviser.com/wp-content/cache/busting/1/wp-includes/js/jquery/jquery-1.12.4-wp.js'></script> <!--[if lt IE 9]> <script type='text/javascript' src='https://technodeviser.com/wp-content/themes/avail/assets/js/html5.js?ver=3.7.3'></script> <![endif]-->
      <link rel='https://api.w.org/' href='https://technodeviser.com/wp-json/' />
      <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://technodeviser.com/xmlrpc.php?rsd" />
      <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://technodeviser.com/wp-includes/wlwmanifest.xml" />
      <meta name="generator" content="WordPress 5.2.11" />
      <meta name="generator" content="WooCommerce 3.6.6" />
      <link rel='shortlink' href='https://technodeviser.com/' />
      <noscript>
         <style>.woocommerce-product-gallery{opacity:1!important}</style>
      </noscript>
      <style type="text/css">.recentcomments a{display:inline!important;padding:0!important;margin:0!important}</style>
      <link rel="icon" href="https://technodeviser.com/wp-content/uploads/2017/05/TD_fevicon.png" sizes="32x32" />
      <link rel="icon" href="https://technodeviser.com/wp-content/uploads/2017/05/TD_fevicon.png" sizes="192x192" />
      <link rel="apple-touch-icon-precomposed" href="https://technodeviser.com/wp-content/uploads/2017/05/TD_fevicon.png" />
      <meta name="msapplication-TileImage" content="https://technodeviser.com/wp-content/uploads/2017/05/TD_fevicon.png" />
      <style type="text/css" id="wp-custom-css">.woocommerce .woocommerce-ordering select{border:1px solid #000}.woocommerce-cart input#coupon_code{width:140px;margin-bottom:10px}.woocommerce-cart .actions .coupon input.button{width:140px}.navbar .fa{font-size:18px}.single-product .single_p_author_set{display:none}.single-product .single_p_date_set{display:none}.single-product .entry-title{font-size:28px;text-align:left}.list_text{list-style:disc;padding-left:20px}div#mfesecure-ts-image{left:0px!important}</style>
      <style type="text/css"></style>
      <noscript>
         <style id="rocket-lazyload-nojs-css">.rll-youtube-player,[data-lazy-src]{display:none!important}</style>
      </noscript>
      <script type="602628bac18f9de0e8cae51b-text/javascript">/*! loadCSS rel=preload polyfill. [c]2017 Filament Group, Inc. MIT License */
         (function(w){"use strict";if(!w.loadCSS){w.loadCSS=function(){}}
         var rp=loadCSS.relpreload={};rp.support=(function(){var ret;try{ret=w.document.createElement("link").relList.supports("preload")}catch(e){ret=!1}
         return function(){return ret}})();rp.bindMediaToggle=function(link){var finalMedia=link.media||"all";function enableStylesheet(){link.media=finalMedia}
         if(link.addEventListener){link.addEventListener("load",enableStylesheet)}else if(link.attachEvent){link.attachEvent("onload",enableStylesheet)}
         setTimeout(function(){link.rel="stylesheet";link.media="only x"});setTimeout(enableStylesheet,3000)};rp.poly=function(){if(rp.support()){return}
         var links=w.document.getElementsByTagName("link");for(var i=0;i<links.length;i++){var link=links[i];if(link.rel==="preload"&&link.getAttribute("as")==="style"&&!link.getAttribute("data-loadcss")){link.setAttribute("data-loadcss",!0);rp.bindMediaToggle(link)}}};if(!rp.support()){rp.poly();var run=w.setInterval(rp.poly,500);if(w.addEventListener){w.addEventListener("load",function(){rp.poly();w.clearInterval(run)})}else if(w.attachEvent){w.attachEvent("onload",function(){rp.poly();w.clearInterval(run)})}}
         if(typeof exports!=="undefined"){exports.loadCSS=loadCSS}
         else{w.loadCSS=loadCSS}}(typeof global!=="undefined"?global:this))
      </script>
   </head>
   <body class="home page-template-default page page-id-4 woocommerce-no-js mega-menu-top avail-front-page has-header-image page-two-column colors-light">
      <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WRVW445"
         height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
      <div id="header_top">
         <div class="container">
            <div class="row">
               <div class="col-sm-6">
                  <div class="header_top_l">
                     <ul>
                        <li><a href="/cdn-cgi/l/email-protection#73531a1d151c330716101b1d1c1716051a0016015d101c1e79"><i class="fa fa-envelope" aria-hidden="true"></i> <span class="__cf_email__" data-cfemail="c3aaada5ac83b7a6a0abadaca7a6b5aab0a6b1eda0acae">[email&#160;protected]</span></a></li>
                     </ul>
                  </div>
               </div>
               <div class="col-sm-6">
                  <div class="header_top_r">
                     <ul>
                        <li><a target="_blank" href="https://www.facebook.com/technodeviser/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a target="_blank" href="https://twitter.com/technodeviser"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a target="_blank" href="https://www.linkedin.com/company/techno-deviser"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="header_slider_o">
         <header id="header">
            <div class="container">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="menu_navi">
                        <nav class="navbar navbar-default">
                           <div class="">
                              <div class="">
                                 <div class="navbar-header">
                                    <a class="navbar-brand" href="https://technodeviser.com">
                                       <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="/wp-content/uploads/2017/05/logo.png">
                                       <noscript><img src="/wp-content/uploads/2017/05/logo.png"></noscript>
                                    </a>
                                 </div>
                              </div>
                              <div class="">
                                 <div id="mega-menu-wrap-top" class="mega-menu-wrap">
                                    <div class="mega-menu-toggle">
                                       <div class="mega-toggle-blocks-left"></div>
                                       <div class="mega-toggle-blocks-center"></div>
                                       <div class="mega-toggle-blocks-right">
                                          <div class='mega-toggle-block mega-menu-toggle-block mega-toggle-block-1' id='mega-toggle-block-1' tabindex='0'><span class='mega-toggle-label' role='button' aria-expanded='false'><span class='mega-toggle-label-closed'></span><span class='mega-toggle-label-open'></span></span></div>
                                       </div>
                                    </div>
                                    <ul id="mega-menu-top" class="mega-menu max-mega-menu mega-menu-horizontal mega-no-js" data-event="hover" data-effect="fade_up" data-effect-speed="400" data-effect-mobile="disabled" data-effect-speed-mobile="200" data-mobile-force-width="false" data-second-click="close" data-document-click="collapse" data-vertical-behaviour="standard" data-breakpoint="767" data-unbind="true">
                                       <li class='mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-home mega-current-menu-item mega-page_item mega-page-item-4 mega-current_page_item mega-align-bottom-left mega-menu-flyout mega-menu-item-18' id='mega-menu-item-18'><a class="mega-menu-link" href="https://technodeviser.com/" tabindex="0">HOME</a></li>
                                       <li class='mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-megamenu mega-menu-item-has-children mega-align-bottom-left mega-menu-megamenu mega-menu-item-16' id='mega-menu-item-16'>
                                          <a class="mega-menu-link" href="https://technodeviser.com/services/" aria-haspopup="true" aria-expanded="false" tabindex="0">SERVICES<span class="mega-indicator"></span></a>
                                          <ul class="mega-sub-menu">
                                             <li class='mega-menu-item mega-menu-item-type-widget widget_text mega-menu-columns-1-of-4 mega-menu-item-text-22' id='mega-menu-item-text-22'>
                                                <h4 class="mega-block-title">Front End Development</h4>
                                                <div class="textwidget"><a href="/psd-and-responsive-html"><i class="fa fa-html5"></i>PSD and Responsive HTML </a><br> <a href="/sass"><i class="fa fa-css3"></i>SASS & LESS</a></div>
                                             </li>
                                             <li class='mega-menu-item mega-menu-item-type-widget widget_text mega-menu-columns-1-of-4 mega-menu-item-text-23' id='mega-menu-item-text-23'>
                                                <h4 class="mega-block-title">Theme/Plugin</h4>
                                                <div class="textwidget">
                                                   <div class="mega2">CMS Development<br> <a href="/wordpress"><i class="fa fa-wordpress"></i>Wordpress </a><br><a href="/drupal"><i class="fa fa-drupal"></i>Drupal</a><br><a href="/joomla"><i class="fa fa-joomla"></i>Joomla</a></div>
                                                   E-commerce Development<br> <a href="/magento"> Magento </a><i class="fa fa-bolt" style="font-size:24px;color:#217fbb"></i><a href="/woocommerce"> WooCommerce </a><br> <a href="/shopify" class="gap">Shopify</a><a href="/bigcommerce"> BigCommerce </a><br> <a href="/open-cart" class="gap">OpenCart </a> <a href="/zencart"> ZenCart </a>
                                                </div>
                                             </li>
                                             <li class='mega-menu-item mega-menu-item-type-widget widget_text mega-menu-columns-1-of-4 mega-menu-item-text-24' id='mega-menu-item-text-24'>
                                                <h4 class="mega-block-title">Mobile Development</h4>
                                                <div class="textwidget"><a href="/android-development"><i class="fa fa-android"></i> Android Development</a><br><a href="/ios-development"> <i class="fa fa-apple"></i> IOS Development</a><br><a href="/mobile-responsive-websites"> <i class="fa fa-mobile"></i> Mobile Responsive Websites</a><br><a href="/cross-platform-development"> <i class="fa fa-desktop"></i> Cross Platform Development</a></div>
                                             </li>
                                             <li class='mega-menu-item mega-menu-item-type-widget widget_text mega-menu-columns-1-of-4 mega-menu-item-text-25' id='mega-menu-item-text-25'>
                                                <h4 class="mega-block-title">Web Marketing</h4>
                                                <div class="textwidget"><a href="/search-engine-optimization">Search Engine Optimization <i class="fa fa-bolt" style="font-size:24px;color:#217fbb"></i></a><br><a href="/social-media-marketing"> Social Media Marketing</a><br><a href="/email-campaigns"> Email Campaigns</a></div>
                                             </li>
                                          </ul>
                                       </li>
                                       <li class='mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-align-bottom-left mega-menu-flyout mega-menu-item-248' id='mega-menu-item-248'><a class="mega-menu-link" href="https://technodeviser.com/training/" tabindex="0">Training</a></li>
                                       <li class='mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-align-bottom-left mega-menu-flyout mega-menu-item-17' id='mega-menu-item-17'><a class="mega-menu-link" href="https://technodeviser.com/about-us/" tabindex="0">ABOUT US</a></li>
                                       <li class='mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-align-bottom-left mega-menu-flyout mega-menu-item-282' id='mega-menu-item-282'><a class="mega-menu-link" href="https://technodeviser.com/career/" tabindex="0">Career</a></li>
                                       <li class='mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-align-bottom-left mega-menu-flyout mega-menu-item-14' id='mega-menu-item-14'><a class="mega-menu-link" href="https://technodeviser.com/contact-us/" tabindex="0">CONTACT US</a></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <div id="slider">
            <div class="">
               <div id="carousel" class="carousel slide carousel-fade" data-ride="carousel">
                  <div class="carousel-inner carousel-zoom">
                     <div class="active item">
                        <img width="1200" height="500" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20500'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="slider" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/slider.jpg 1200w, https://technodeviser.com/wp-content/uploads/2017/05/slider-600x250.jpg 600w, https://technodeviser.com/wp-content/uploads/2017/05/slider-300x125.jpg 300w, https://technodeviser.com/wp-content/uploads/2017/05/slider-768x320.jpg 768w, https://technodeviser.com/wp-content/uploads/2017/05/slider-1024x427.jpg 1024w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/slider-1200x500.jpg" />
                        <noscript><img width="1200" height="500" src="https://technodeviser.com/wp-content/uploads/2017/05/slider-1200x500.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="slider" srcset="https://technodeviser.com/wp-content/uploads/2017/05/slider.jpg 1200w, https://technodeviser.com/wp-content/uploads/2017/05/slider-600x250.jpg 600w, https://technodeviser.com/wp-content/uploads/2017/05/slider-300x125.jpg 300w, https://technodeviser.com/wp-content/uploads/2017/05/slider-768x320.jpg 768w, https://technodeviser.com/wp-content/uploads/2017/05/slider-1024x427.jpg 1024w" sizes="100vw" /></noscript>
                        <div class="">
                           <div class="hero">
                              <hgroup>
                                 <h1>We are creative</h1>
                                 <h3>Get start your next <span>awesome project</span></h3>
                              </hgroup>
                           </div>
                        </div>
                     </div>
                     <div class=" item">
                        <img width="1200" height="500" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20500'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="slider2" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/slider2.jpg 1200w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-600x250.jpg 600w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-300x125.jpg 300w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-768x320.jpg 768w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-1024x427.jpg 1024w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/slider2-1200x500.jpg" />
                        <noscript><img width="1200" height="500" src="https://technodeviser.com/wp-content/uploads/2017/05/slider2-1200x500.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="slider2" srcset="https://technodeviser.com/wp-content/uploads/2017/05/slider2.jpg 1200w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-600x250.jpg 600w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-300x125.jpg 300w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-768x320.jpg 768w, https://technodeviser.com/wp-content/uploads/2017/05/slider2-1024x427.jpg 1024w" sizes="100vw" /></noscript>
                        <div class="">
                           <div class="hero">
                              <hgroup>
                                 <h3>
                                    <div class="slider_text_c">Our experienced client serving <span>Creative Team</span>, <span>Digital Marketers</span>, <span>Social Media Managers</span> and <span>Engineers</span> are the best in the business. We scour the globe for the top talents to join TECHNO Deviser team. We love what we do, which helps us fulfill your business goals and objectives</div>
                                 </h3>
                              </hgroup>
                           </div>
                        </div>
                     </div>
                     <div class=" item">
                        <img width="1200" height="500" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201200%20500'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="slider3" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/slider3.jpg 1200w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-600x250.jpg 600w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-300x125.jpg 300w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-768x320.jpg 768w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-1024x427.jpg 1024w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/slider3-1200x500.jpg" />
                        <noscript><img width="1200" height="500" src="https://technodeviser.com/wp-content/uploads/2017/05/slider3-1200x500.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="slider3" srcset="https://technodeviser.com/wp-content/uploads/2017/05/slider3.jpg 1200w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-600x250.jpg 600w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-300x125.jpg 300w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-768x320.jpg 768w, https://technodeviser.com/wp-content/uploads/2017/05/slider3-1024x427.jpg 1024w" sizes="100vw" /></noscript>
                        <div class="">
                           <div class="hero">
                              <hgroup>
                                 <h1>We are amazing</h1>
                                 <h3>Get start your next <span>awesome project</span></h3>
                              </hgroup>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="slid_sp"><a href="#moto"><span class="scroll_btm"><i class="fa fa-angle-double-down" aria-hidden="true"></i></span></a></div>
               </div>
            </div>
         </div>
      </div>
      <div id="moto">
         <div class="container">
            <div class="heading_title">
               <h3><span>OUR</span> MOTTO</h3>
            </div>
            <div class="moto">
               <div class="home_about_l" data-aos="fade-up">
                  <div class="motoparagraph">
                     <p>Our motto is to provide excellent service in given timeline and at Techno Deviser:<br> Your Goal is our Interest, your Need is our Drive and <span>Your Business is Our Business</span></p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="home_about">
         <div class="container">
            <div class="row">
               <div class="col-sm-6">
                  <div class="home_about_l" data-aos="fade-up">
                     <section id="text-17" class="widget widget_text">
                        <div class="textwidget">
                           <div class="h_ab_set1">
                              <h3>ABOUT <span>TECHNO DEVISER</span></h3>
                              <p>We introduce our self ‘Techno Deviser’ as leading & promising IT Company Headquartered in Panchkula having best IT solutions for your business and online presence. We have expertise in Website Development and Digital Marketing. Our team of professionals is competent and skilled to plan, build and develop unique and exclusive Websites. For each of our client, we bring fresh approach and strategy which is tailored made according to client’s business needs.<b> We match our clients’ expectations by building remarkable websites by using suitable platform i.e. Magento, Shopify, Word press etc according to client’s requirement. </b>Your business is not having a website and you are looking forward to create one or your Company is already having a website, but you need an energizer look for your online presence, we are here to serve you with our expert reflection of world-class work delivery.</p>
                              <p> It is well said “First Impression is last impression”, how you want your customers to perceive your product or service, a well designed & user friendly website is answer. A responsive, dedicated and mobile friendly website of a business is need of hour for any company or organisation in world. Under umbrella of web designing and development, we thrive to offer & deliver vast services including everything, for instance, Static website designing, Dynamic website designing, user experience design to enhance visitor experience, flash designing (we can get any type of content animated online for your website), Graphic optimisation and Graphic design. Our website design and development is innovative, either you need a website for your e-commerce business or just a static corporate web design; we have proficiency in all fields.</p>
                           </div>
                        </div>
                     </section>
                  </div>
               </div>
               <div class="col-sm-6">
                  <div class="home_about_r" data-aos="fade-up">
                     <section id="text-18" class="widget widget_text">
                        <div class="textwidget">
                           <div class="build_img">
                              <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="/wp-content/uploads/2017/05/buiding_img.png">
                              <noscript><img src="/wp-content/uploads/2017/05/buiding_img.png"></noscript>
                           </div>
                           <h3>WE'VE GROWN <span>FAST</span></h3>
                           <div class="h_about_h1_set">
                              <p>
                              <h1><span>Our first love?</span></h1>
                              Seeing businesses grow.
                              </p>
                              <p>
                              <h1><span>We believe that inbound marketing is jet fuel for growth.</h1>
                              Prehistoric sales and marketing practices, on the other hand, are more like quicksand.
                              </p>
                              <p>
                              <h1><span>Do digital the right way.</span></h1>
                              That means getting results in an ethical manner.</p>
                              <p>
                              <h1><span>We focus on execution;</span></h1>
                              we get things built, produced and delivered on time.</p>
                              <p>
                              <h1><span>We have helped small businesses succeed -</span></h1>
                              giving them the targeted marketing they need to generate more calls, more social media likes, more clicks and eventually more clients.</p>
                           </div>
                        </div>
                     </section>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="home_sevices">
         <div class="container">
            <div class="heading_title">
               <h3><span>SERVICES</span> WE OFFER</h3>
            </div>
            <div class="set1"> Not every Marketing Agency is created equal. At Techno Deviser, we know that the best results come from having the right people working on the right project. Our team offers expertise in various areas of Marketing Agency services, which is why each client is matched with a suitable group of experts to help them achieve their goals. With our proven strategies, your business is bound for wild success.</div>
            <div class="row mrng_btm">
               <div class="col-sm-5">
                  <div class="service_img_blo " data-aos="flip-left">
                     <div class="img_hold">
                        <img width="601" height="601" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20601%20601'%3E%3C/svg%3E" class="img-responsive responsive--full wp-post-image" alt="service_img" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/service_img.png 601w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-300x300.png 300w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-100x100.png 100w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-600x600.png 600w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-150x150.png 150w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/service_img.png" />
                        <noscript><img width="601" height="601" src="https://technodeviser.com/wp-content/uploads/2017/05/service_img.png" class="img-responsive responsive--full wp-post-image" alt="service_img" srcset="https://technodeviser.com/wp-content/uploads/2017/05/service_img.png 601w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-300x300.png 300w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-100x100.png 100w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-600x600.png 600w, https://technodeviser.com/wp-content/uploads/2017/05/service_img-150x150.png 150w" sizes="100vw" /></noscript>
                     </div>
                  </div>
               </div>
               <div class="col-sm-7">
                  <div class="service_content" data-aos="fade-up">
                     <h4>SOCIAL<span>Media Marketing, Media Management, Media Content Creation</span></h4>
                     <P>Our skilled team of social marketers will create, manage, and deliver top-performing social media campaigns for your business. We position you to become an influencer through social media marketing and generate more leads and sales for your business. Social media management services are designed to grow your brand’s online presence.Our services include daily account management, influenced Google rankings, blog promotions, reputation management, and social customer service.</P>
                     <div class="read_btn read_more">
                        <div class="inner_bef"><a class="icon_btn icon_btn_2" href="/services/">READ MORE</a></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row mrng_btm">
               <div class="col-sm-7">
                  <div class="service_content" data-aos="fade-up">
                     <h4>BUSSINESS <span>Small and Large Business Website Solutions</span></h4>
                     <P>If your small or medium sized business needs a website, we can help. If you are in need of more than just web design, we have solutions for you.<span>UX/UI Research, Design & Protyping</span> Our Mobile Application Development (web app/native app) services are a combination of our expertise and knowledge of the mobile platform itself as well as our creativity in user experience design. Our expertise in User Experience Design (UX) and User Interface Design has enabled us to simplify and enhance the interaction between our client’s target customers and their digital presence.<span>Web and Enterprise Interactive Portal</span> We design and develop deliver portal solutions of a wide variety of types, scope and complexity. And whatever the underlying scenario, we assure delivery of a dynamic experience your end user.</P>
                     <div class="read_btn read_more">
                        <div class="inner_bef"><a class="icon_btn icon_btn_2" href="http:/services/">READ MORE</a></div>
                     </div>
                  </div>
               </div>
               <div class="col-sm-5">
                  <div class="service_img_blo serimg_cntr" data-aos="flip-left">
                     <div class="img_hold">
                        <img width="601" height="601" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20601%20601'%3E%3C/svg%3E" class="img-responsive responsive--full wp-post-image" alt="service_img2" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/service_img2.png 601w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-300x300.png 300w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-100x100.png 100w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-600x600.png 600w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-150x150.png 150w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/service_img2.png" />
                        <noscript><img width="601" height="601" src="https://technodeviser.com/wp-content/uploads/2017/05/service_img2.png" class="img-responsive responsive--full wp-post-image" alt="service_img2" srcset="https://technodeviser.com/wp-content/uploads/2017/05/service_img2.png 601w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-300x300.png 300w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-100x100.png 100w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-600x600.png 600w, https://technodeviser.com/wp-content/uploads/2017/05/service_img2-150x150.png 150w" sizes="100vw" /></noscript>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row mrng_btm">
               <div class="col-sm-5">
                  <div class="service_img_blo " data-aos="flip-left">
                     <div class="img_hold">
                        <img width="601" height="601" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20601%20601'%3E%3C/svg%3E" class="img-responsive responsive--full wp-post-image" alt="service_img3" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/service_img3.png 601w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-300x300.png 300w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-100x100.png 100w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-600x600.png 600w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-150x150.png 150w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/service_img3.png" />
                        <noscript><img width="601" height="601" src="https://technodeviser.com/wp-content/uploads/2017/05/service_img3.png" class="img-responsive responsive--full wp-post-image" alt="service_img3" srcset="https://technodeviser.com/wp-content/uploads/2017/05/service_img3.png 601w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-300x300.png 300w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-100x100.png 100w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-600x600.png 600w, https://technodeviser.com/wp-content/uploads/2017/05/service_img3-150x150.png 150w" sizes="100vw" /></noscript>
                     </div>
                  </div>
               </div>
               <div class="col-sm-7">
                  <div class="service_content" data-aos="fade-up">
                     <h4>TECHNOLOGIES<span>Emerging Platform Technologies Implementation</span></h4>
                     <P>We design and develop deliver portal solutions of a wide variety of types, scope and complexity. And whatever the underlying scenario, we assure delivery of a dynamic experience your end user.</P>
                     <div class="read_btn read_more">
                        <div class="inner_bef"><a class="icon_btn icon_btn_2" href="/services/">READ MORE</a></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="home_project_work">
         <div class="container">
            <div class="heading_title">
               <h3>OUR LATEST <span>PORTFOLIO</span></h3>
            </div>
            <div class="row">
               <div class="col-sm-12">
                  <div class="inner_pro_work">
                     <div class="">
                        <ul id="filters" class="clearfix">
                           <li><span class="filter active" data-filter=.AllWorks>All Works</span></li>
                           <li><span class="filter" data-filter=.AppDevelopment>App Development</span></li>
                           <li><span class="filter" data-filter=.Magento1x-2x>Magento 1.x-2.x</span></li>
                           <li><span class="filter" data-filter=.SEO>SEO</span></li>
                           <li><span class="filter" data-filter=.Shopify>Shopify</span></li>
                           <li><span class="filter" data-filter=.WebDesign>Web Design</span></li>
                           <li><span class="filter" data-filter=.Wordpress>Wordpress</span></li>
                        </ul>
                        <div id="portfoliolist">
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://yumacre.com/" class="text-title"> Yumacre</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/yumcare.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/yumcare.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Yumacre</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Notions of constant and never ending improvement (Velocity) are what drive SVN | Velocity Commercial Real Estate.  SVN | Velocity was founded with the idea that commercial real estate professionals have an enormous responsibility to promote the business, entrepreneurship, and investment activities ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://yumacre.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/tampacre2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/tampacre2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://tampacre.com/" class="text-title"> Tampacre</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/tampcare.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/tampcare.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Tampacre</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>
                                                   Commercial Real Estate Agent John Milsaps has spent the past decade dedicated to his role as a commercial real estate professional who specializes in <a href="https://tampacre.com/landlord-representation/">landlord representation</a> and 
                                                   <a href="https://tampacre.com/seller-representation/">
                                                      seller r...
                                                </p>
                                                <div class="read_btn read_more"><div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://tampacre.com/">READ MORE</a></div></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td2AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://svnkova.com/" class="text-title"> Svnkova</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td2AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Svnkova</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>We conduct ourselves with the highest level of integrity, morals, and ethical standards and seek to continually examine and improve ourselves in order to be the best we can be. SVN | KOVA – As a fully integrated family of real estate companies spanning multiple disciplines, we are regarded as an i...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://svnkova.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td3AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnfla2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnfla2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://svnfla.com/" class="text-title"> Svnfla</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td3AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Svnfla</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>The SVN Florida Land Alliance (“FLA”) is a select group of experienced Commercial Real Estate Advisors focused on LAND. “FLA” services the entire State of Florida from the Panhandle to the Keys. In addition to traditional Commercial Brokerage(CRE), “FLA” provides the entire spectrum of d...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://svnfla.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td4AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://stickyprofiles.com/" class="text-title"> Stickyprofiles</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td4AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofile.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofile.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Stickyprofiles</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>LinkedIn Sticky Profiles is an outsourced LinkedIn Marketing Company that does LinkedIn social marketing for you. From writing your sticky profile (meaning viewers stick around to engage) to Managing your LinkedIn Account to our custom –designed LinkedIn training/sales coaching, WE DO IT FOR YOU....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://stickyprofiles.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td5AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://sootaway.net/" class="text-title"> Sootaway</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td5AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Sootaway</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>
                                                <p class="font_8">Sootaway, formerly known as Patrick Buell Chimney Services, was founded by Patrick Buell in Pensacola in the summer of 2014. As a Gulf Coast native who cares about his community, Patrick prides himself on being honest and trustworthy in all aspects of business, and always giving ea...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://sootaway.net/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td6AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://hfklaw.com" class="text-title"> Hfklaw</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td6AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Hfklaw</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Serve as an independent source of original content, exploring issues confronting the commercial real estate industry
                                                   Impartially cover the events, issues, personalities and ideas that count in commercial real estate today
                                                   Be a sounding board for discussion of new ideas among experienced CRE profes...
                                                </p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://hfklaw.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td7AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://alliancerealtyadvisory.com/" class="text-title"> Alliancerealtyadvisory</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td7AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/acredvisory.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/acredvisory.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Alliancerealtyadvisory</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>ARA is ARG’s underwriting and asset-sourcing arm for principal assets in the marketplace for FO (Family Office) and FOA (Family Office Advisory firms) . ARA will underwrite the initial asset specifications and markets for acquisition consideration. ARA members engineer additional steps to achieve ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://alliancerealtyadvisory.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td8AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://alliancecreadvisors.com/" class="text-title"> Alliancecreadvisors</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td8AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Alliancecreadvisors</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>The Alliance Commercial Real Estate Group is a professional advisory services firm that focuses on the transaction management and financial services arenas of fixed assets. The ARG organization works to create value through commercial real estate for shareholders, clients and its partner organizatio...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://alliancecreadvisors.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td9AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/jjosh-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/jjosh-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.jjlyonsmarketing.com" class="text-title"> JJlyonsmarketing</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td9AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/jjlyonsmarketing.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/jjlyonsmarketing.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>JJlyonsmarketing</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Joshua Lyons Marketing, LLC was established in 2015. Since its inception, our team of dedicated writers, content developers, and designers have made it our mission to provide our clients with the top-notch services that have become synonymous with our name. Trust, honesty, and integrity are the foun...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.jjlyonsmarketing.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td10AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="prosand" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/prosand-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="prosand" srcset="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/prosand-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://prosand.com.au/" class="text-title"> prosand</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td10AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/prosand.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/prosand.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>prosand</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>We are a family business and take great pride in our work and the happiness and satisfaction of our valued clients.The extensive timber flooring range at Prosand ensures that our timber floors provide the ideal solutions for any application requirements.Our projects are characterised by th...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://prosand.com.au/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td11AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="mysterywritershowcase" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="mysterywritershowcase" srcset="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://mysterywritershowcase.com/" class="text-title"> mysterywritershowcase.com</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td11AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>mysterywritershowcase.com</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Welcome to Mystery Writer Showcase, a place where you can find top mystery books and audios. We have dedicated this site to individuals who are looking for mystery works of all times. You’ll find different mystery works of several genres and sub genres for you to peruse and find something interest...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://mysterywritershowcase.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td12AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="lamaisonduchocolat" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="lamaisonduchocolat" srcset="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.lamaisonduchocolat.us/en_us/" class="text-title"> lamaisonduchocolat</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td12AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>lamaisonduchocolat</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p> We ship using Federal Express. Once the package has left our facility, La Maison du Chocolat cannot assume responsibility for any shipping delays/problems due solely to the shipping carrier. In order to facilitate delivery, you may add additional information such as apartment, suite, or floor numb...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.lamaisonduchocolat.us/en_us/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td13AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="gourmetfoodstore" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="gourmetfoodstore" srcset="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.gourmetfoodstore.com/" class="text-title"> gourmetfoodstore</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td13AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>gourmetfoodstore</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Gourmet Food Store is an epicure's paradise, an online store for those who love great food and great ingredients. We offer you the ultimate selection of international specialty foods such as caviar, cheese, foie gras and pate, gourmet chocolates, oils and vinegars, smoked salmon, specialty meats, te...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.gourmetfoodstore.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td14AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://faceyourdragon.com" class="text-title"> faceyourdragon</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td14AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/faceyourdragon-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>faceyourdragon</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Why We Help You Face Your DragonJust like you, we have a burning desire to share our messageWe know how desperately you want to get this out to the world. The fire is burning hot, deep in your soul; it beckons to be unleashed.You might not know what that is, or maybe you are certain what...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://faceyourdragon.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td15AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="mp45-400" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/mp45-400.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/mp45-400-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/mp45-400.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/mp45-400.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="mp45-400" srcset="https://technodeviser.com/wp-content/uploads/2017/05/mp45-400.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/mp45-400-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.mp45.com" class="text-title"> mp45</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td15AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/mp45-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/mp45-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>mp45</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>MP45 is the best gym workout program. Created by Muscle Prodigy. This muscle building guide, cardio training routine and meal plan schedule is for a beginner or advanced athlete....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.mp45.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td16AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://abundancecoaching.com/" class="text-title"> abundancecoaching</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td16AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/abundancecoaching-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>abundancecoaching</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Have you ever wondered if Life Coaching is for you? Maybe you do set goals and you do have an idea of what your purpose and direction in life is. This simply is not enough for you to experience the abundance in life that you deserve. If your life purpose and most important goals don’t require you ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://abundancecoaching.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td17AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="goodlifeproject" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="goodlifeproject" srcset="https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.goodlifeproject.com" class="text-title"> goodlifeproject</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td17AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/goodlifeproject-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>goodlifeproject</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>GLP is more of a “who” than a “what?”We’re a global community of people from all walks of life. From artists to entrepreneurs, full-time parents to C-suite execs, students to savants and everything in-between, if you’ve got a pulse, you’ve already passed the first test!Together...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.goodlifeproject.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td18AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="projectlifemastery" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="projectlifemastery" srcset="https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://projectlifemastery.com/" class="text-title"> projectlifemastery</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td18AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/projectlifemastery-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>projectlifemastery</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Stefan James from Project Life Mastery reveals his very best strategies to mastering and living life fully; everything from how to be motivated, his secrets to success, how to make money online, making passive income online, how to change your beliefs and mindset, being healthy and physically fit, b...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://projectlifemastery.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td19AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="diamondlifeusa400" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa400.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa400-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa400.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa400.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="diamondlifeusa400" srcset="https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa400.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa400-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.diamondlifeusa.com/" class="text-title"> diamondlifeusa</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td19AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/diamondlifeusa-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>diamondlifeusa</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Diamond Life Baseball has teamed with Elev8 Sports Institute to bring you the highest quality of Baseball Instruction in a great atmosphere. Diamond Life has a team of former Major League Players on Staff along with other former pro players that will help and develop the skills that your player will...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.diamondlifeusa.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td20AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="newgradoptometry" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="newgradoptometry" srcset="https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.newgradoptometry.com" class="text-title"> newgradoptometry</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td20AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/newgradoptometry-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>newgradoptometry</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>NewGradOptometry provides students and newly graduated optometrists with the content and resources they need to be successful after optometry school.We believe that new graduate optometrists hold the key to the future of our profession. By equipping new ODs with the proper tools and resources we can...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.newgradoptometry.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td21AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://vacation-races-merchandise.myshopify.com/" class="text-title"> vacation-races-merchandise</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td21AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>vacation-races-merchandise</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Vacation Races is all about beautiful races near major vacation destinations. Our National Park Half Marathon Series enables runners to enjoy the country's most beautiful destinations. Learn more at www.VacationRaces.com...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://vacation-races-merchandise.myshopify.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td22AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="4seasonsstore" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="4seasonsstore" srcset="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.4seasonsstore.co.uk" class="text-title"> 4seasonsstore</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td22AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>4seasonsstore</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p> Take a look through our collection for the latest range of Men's jackets and coats. From streetwear jackets to winter coats we have the best choice available in stock for you now....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.4seasonsstore.co.uk">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td23AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="vandcrew" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="vandcrew" srcset="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://vandcrew.myshopify.com" class="text-title"> vandcrew.myshopify</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td23AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>vandcrew.myshopify</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p> V+Crew - loving the simple things….Organic logo tops for your little crew.
                                                   Welcome to the world of V&Crew. We are a London based design team, working with the things we love- organic cotton, clean lines and monochrome styling for your little one.
                                                   Our brand compliments every day living, a minima...
                                                </p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://vandcrew.myshopify.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td24AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="pommadedivine" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="pommadedivine" srcset="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://pommadedivine.com" class="text-title"> pommadedivine</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td24AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>pommadedivine</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>We are very excited and proud to announce that we are now stocked by NET-A-PORTER, the world's premier online luxury fashion and beauty destination.Our lovely fans in over 180 countries will be happy to know that this makes it even easier for you to experience the magic of Pommade Divine Nature'...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://pommadedivine.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td25AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="theslshop" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/theslshop-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="theslshop" srcset="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/theslshop-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.theslshop.com" class="text-title"> theslshop</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td25AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>theslshop</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p> Want to get the best from your classic Mercedes-Benz and enjoy an ownership experience like no other? Then you’ve come to the right place.SL Shop is a family run, independent Mercedes-Benz specialist dedicated to the Mercedes R107 SL. Based in Warwickshire and boasting clients from around th...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.theslshop.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td26AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="showpo" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/showpo-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="showpo" srcset="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/showpo-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.iloveshowpo.com" class="text-title"> showpo</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td26AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>showpo</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>We are so happy that you want to join Showpo! The video below tells you a bit more about our team and the type of people we look for. Scroll beneath the video and you'll see the roles that we are currently recruiting.We are a fast and growing company so we are constantly on the hunt for more uni...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.iloveshowpo.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td27AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="shellsheli" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/shellsheli-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="shellsheli" srcset="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/shellsheli-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.shellsheli.com" class="text-title"> shellsheli</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td27AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>shellsheli</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>If you are looking for modest layering, Shell Sheli is your place. We have shells in up to 40 colors and over a dozen styles and cuts. Super fast shipping and free shipping available. We carry adult, child, maternity and plus sizes....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.shellsheli.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td28AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="onegreekstore" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="onegreekstore" srcset="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.onegreekstore.com" class="text-title"> onegreekstore</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td28AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>onegreekstore</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>One Greek Store was founded in the summer of 2006 by three college students at the University of Florida. The founders recognized a unique need in the Greek community. They wanted to provide Greek Clothing and merchandise of exceptional quality at reasonable prices.Although the idea behind One G...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.onegreekstore.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td29AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="chinapresentations" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="chinapresentations" srcset="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.chinapresentations.net" class="text-title"> chinapresentations</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td29AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>chinapresentations</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>China Presentations is an independent retailer of China, Crystal, Cutlery and Giftware established in 1962. We are a family run business in our third generation. We have recently opened a brand new showroom at our premises in Mill Hill, North West London. Customers come from all over the world to bu...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.chinapresentations.net">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td30AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="cerisse" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/cerisse-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="cerisse" srcset="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/cerisse-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://cerisse.co.uk" class="text-title"> cerisse</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td30AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>cerisse</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>CERISSE MORGAN is an Interior and Fashion Company, which began operating in London and setting itself apart from other brands with it’s unique interior prints. The company boasts a beautiful range that utilises dark elements inspired by Psychoanalytic interpretation and life’s experiences. Each ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://cerisse.co.uk">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td31AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="eden4flowers" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="eden4flowers" srcset="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.eden4flowers.co.uk " class="text-title"> eden4flowers</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td31AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>eden4flowers</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Today our customers can order and send UK wide so much more than just our flower bouquets at Eden4flowers.co.uk From our recently extended range of delicious food hampers at Eden4hampers.co.uk featuring delicious foods from selected from across the UK. A foodie gift makes a great office to office g...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.eden4flowers.co.uk ">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td32AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.carcoverworld.com" class="text-title"> carcoverworld</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td32AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>carcoverworld</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>We take pride in our USA-Made, best-in-the-business product line of Covercraft Industries and Coverking Car & Seat Covers. We also carry a line of semi-custom covers. Our Defender WeatherGuard Extreme continues to be a best seller all-around.Car Cover World is a veteran-owned business and as...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.carcoverworld.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td33AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="merumaya" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="merumaya" srcset="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.merumaya.com/" class="text-title"> MERUMAYA</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td33AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/m.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/m.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>MERUMAYA</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>Our evidence-based, sensorial skincare, helps you feel beautiful, uplifts confidence and boosts youthful radiance. Loaded with anti-inflammatories, even sensitive and acneic skins can finally enjoy the benefits of these powerfully effective formulae, that soothe as they perform. We seek to create po...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.merumaya.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td34AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="ilovevintage" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="ilovevintage" srcset="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.ilovevintage.com" class="text-title"> ilovevintage</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td34AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>ilovevintage</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.ilovevintage.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td35AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="card" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/2-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/2-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/2-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/2-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="card" srcset="https://technodeviser.com/wp-content/uploads/2017/05/2-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/2-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> QR Quick Response</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td35AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/2-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/2-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>QR Quick Response</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td36AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="card" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/5.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/5-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/5.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/5.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="card" srcset="https://technodeviser.com/wp-content/uploads/2017/05/5.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/5-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Techlion</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td36AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/5.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/5.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Techlion</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td37AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="card" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/4.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/4-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/4.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/4.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="card" srcset="https://technodeviser.com/wp-content/uploads/2017/05/4.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/4-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> BMF</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td37AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/4.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/4.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>BMF</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td38AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="cart" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/1-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/1-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/1-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/1-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="cart" srcset="https://technodeviser.com/wp-content/uploads/2017/05/1-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/1-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Typography Company</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td38AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/1-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/1-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Typography Company</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td39AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" srcset="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Graph Plotting</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td39AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Graph Plotting</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td40AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/3-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" srcset="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/3-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Weatherette</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td40AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Weatherette</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td41AllWorks">
                              <div class='portfolio AllWorks' data-cat='.AllWorks'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" srcset="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Visual Infography</a> <span class="text-category">All Works</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td41AllWorks" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Visual Infography</span></h4>
                                                <div class="port_tag">Catagory: All Works</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0AppDevelopment">
                              <div class='portfolio AppDevelopment' data-cat='.AppDevelopment'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" srcset="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Graph Plotting</a> <span class="text-category">App Development</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0AppDevelopment" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/2.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Graph Plotting</span></h4>
                                                <div class="port_tag">Catagory: App Development</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1AppDevelopment">
                              <div class='portfolio AppDevelopment' data-cat='.AppDevelopment'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/3-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" srcset="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/3-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Weatherette</a> <span class="text-category">App Development</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1AppDevelopment" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/3.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Weatherette</span></h4>
                                                <div class="port_tag">Catagory: App Development</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td2AppDevelopment">
                              <div class='portfolio AppDevelopment' data-cat='.AppDevelopment'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="app" srcset="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="" class="text-title"> Visual Infography</a> <span class="text-category">App Development</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td2AppDevelopment" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Visual Infography</span></h4>
                                                <div class="port_tag">Catagory: App Development</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="theslshop" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/theslshop-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="theslshop" srcset="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/theslshop-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.theslshop.com" class="text-title"> theslshop</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/theslshop.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>theslshop</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p> Want to get the best from your classic Mercedes-Benz and enjoy an ownership experience like no other? Then you’ve come to the right place.SL Shop is a family run, independent Mercedes-Benz specialist dedicated to the Mercedes R107 SL. Based in Warwickshire and boasting clients from around th...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.theslshop.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="showpo" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/showpo-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="showpo" srcset="https://technodeviser.com/wp-content/uploads/2017/05/showpo.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/showpo-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.iloveshowpo.com" class="text-title"> showpo</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/showpo.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>showpo</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>We are so happy that you want to join Showpo! The video below tells you a bit more about our team and the type of people we look for. Scroll beneath the video and you'll see the roles that we are currently recruiting.We are a fast and growing company so we are constantly on the hunt for more uni...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.iloveshowpo.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td2Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="shellsheli" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/shellsheli-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="shellsheli" srcset="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/shellsheli-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.shellsheli.com" class="text-title"> shellsheli</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td2Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/shellsheli.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>shellsheli</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>If you are looking for modest layering, Shell Sheli is your place. We have shells in up to 40 colors and over a dozen styles and cuts. Super fast shipping and free shipping available. We carry adult, child, maternity and plus sizes....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.shellsheli.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td3Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="onegreekstore" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="onegreekstore" srcset="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.onegreekstore.com" class="text-title"> onegreekstore</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td3Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/onegreekstore.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>onegreekstore</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>One Greek Store was founded in the summer of 2006 by three college students at the University of Florida. The founders recognized a unique need in the Greek community. They wanted to provide Greek Clothing and merchandise of exceptional quality at reasonable prices.Although the idea behind One G...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.onegreekstore.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td4Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="chinapresentations" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="chinapresentations" srcset="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.chinapresentations.net" class="text-title"> chinapresentations</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td4Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/chinapresentations.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>chinapresentations</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>China Presentations is an independent retailer of China, Crystal, Cutlery and Giftware established in 1962. We are a family run business in our third generation. We have recently opened a brand new showroom at our premises in Mill Hill, North West London. Customers come from all over the world to bu...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.chinapresentations.net">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td5Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="cerisse" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/cerisse-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="cerisse" srcset="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/cerisse-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://cerisse.co.uk" class="text-title"> cerisse</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td5Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/cerisse.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>cerisse</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>CERISSE MORGAN is an Interior and Fashion Company, which began operating in London and setting itself apart from other brands with it’s unique interior prints. The company boasts a beautiful range that utilises dark elements inspired by Psychoanalytic interpretation and life’s experiences. Each ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://cerisse.co.uk">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td6Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="eden4flowers" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="eden4flowers" srcset="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.eden4flowers.co.uk " class="text-title"> eden4flowers</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td6Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/eden4flowers.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>eden4flowers</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>Today our customers can order and send UK wide so much more than just our flower bouquets at Eden4flowers.co.uk From our recently extended range of delicious food hampers at Eden4hampers.co.uk featuring delicious foods from selected from across the UK. A foodie gift makes a great office to office g...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.eden4flowers.co.uk ">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td7Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld-2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.carcoverworld.com" class="text-title"> carcoverworld</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td7Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/carcoverworld.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>carcoverworld</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>We take pride in our USA-Made, best-in-the-business product line of Covercraft Industries and Coverking Car & Seat Covers. We also carry a line of semi-custom covers. Our Defender WeatherGuard Extreme continues to be a best seller all-around.Car Cover World is a veteran-owned business and as...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.carcoverworld.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td8Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="merumaya" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="merumaya" srcset="https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/merumaya-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.merumaya.com/" class="text-title"> MERUMAYA</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td8Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/m.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/m.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>MERUMAYA</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>Our evidence-based, sensorial skincare, helps you feel beautiful, uplifts confidence and boosts youthful radiance. Loaded with anti-inflammatories, even sensitive and acneic skins can finally enjoy the benefits of these powerfully effective formulae, that soothe as they perform. We seek to create po...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.merumaya.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td9Magento1x-2x">
                              <div class='portfolio Magento1x-2x' data-cat='.Magento1x-2x'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="ilovevintage" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="ilovevintage" srcset="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage-2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.ilovevintage.com" class="text-title"> ilovevintage</a> <span class="text-category">Magento 1.x-2.x</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td9Magento1x-2x" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/ilovevintage.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>ilovevintage</span></h4>
                                                <div class="port_tag">Catagory: Magento 1.x-2.x</div>
                                                <p>...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.ilovevintage.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0SEO">
                              <div class='portfolio SEO' data-cat='.SEO'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="lamaisonduchocolat" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="lamaisonduchocolat" srcset="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.lamaisonduchocolat.us/en_us/" class="text-title"> lamaisonduchocolat</a> <span class="text-category">SEO</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0SEO" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/lamaisonduchocolat-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>lamaisonduchocolat</span></h4>
                                                <div class="port_tag">Catagory: SEO</div>
                                                <p> We ship using Federal Express. Once the package has left our facility, La Maison du Chocolat cannot assume responsibility for any shipping delays/problems due solely to the shipping carrier. In order to facilitate delivery, you may add additional information such as apartment, suite, or floor numb...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.lamaisonduchocolat.us/en_us/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1SEO">
                              <div class='portfolio SEO' data-cat='.SEO'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="gourmetfoodstore" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="gourmetfoodstore" srcset="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.gourmetfoodstore.com/" class="text-title"> gourmetfoodstore</a> <span class="text-category">SEO</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1SEO" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/gourmetfoodstore-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>gourmetfoodstore</span></h4>
                                                <div class="port_tag">Catagory: SEO</div>
                                                <p>Gourmet Food Store is an epicure's paradise, an online store for those who love great food and great ingredients. We offer you the ultimate selection of international specialty foods such as caviar, cheese, foie gras and pate, gourmet chocolates, oils and vinegars, smoked salmon, specialty meats, te...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.gourmetfoodstore.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0Shopify">
                              <div class='portfolio Shopify' data-cat='.Shopify'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://vacation-races-merchandise.myshopify.com/" class="text-title"> vacation-races-merchandise</a> <span class="text-category">Shopify</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0Shopify" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/vacation-races-merchandise-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>vacation-races-merchandise</span></h4>
                                                <div class="port_tag">Catagory: Shopify</div>
                                                <p>Vacation Races is all about beautiful races near major vacation destinations. Our National Park Half Marathon Series enables runners to enjoy the country's most beautiful destinations. Learn more at www.VacationRaces.com...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://vacation-races-merchandise.myshopify.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1Shopify">
                              <div class='portfolio Shopify' data-cat='.Shopify'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="4seasonsstore" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="4seasonsstore" srcset="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://www.4seasonsstore.co.uk" class="text-title"> 4seasonsstore</a> <span class="text-category">Shopify</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1Shopify" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/4seasonsstore-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>4seasonsstore</span></h4>
                                                <div class="port_tag">Catagory: Shopify</div>
                                                <p> Take a look through our collection for the latest range of Men's jackets and coats. From streetwear jackets to winter coats we have the best choice available in stock for you now....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://www.4seasonsstore.co.uk">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td2Shopify">
                              <div class='portfolio Shopify' data-cat='.Shopify'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="vandcrew" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="vandcrew" srcset="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://vandcrew.myshopify.com" class="text-title"> vandcrew.myshopify</a> <span class="text-category">Shopify</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td2Shopify" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/vandcrew-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>vandcrew.myshopify</span></h4>
                                                <div class="port_tag">Catagory: Shopify</div>
                                                <p> V+Crew - loving the simple things….Organic logo tops for your little crew.
                                                   Welcome to the world of V&Crew. We are a London based design team, working with the things we love- organic cotton, clean lines and monochrome styling for your little one.
                                                   Our brand compliments every day living, a minima...
                                                </p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://vandcrew.myshopify.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td3Shopify">
                              <div class='portfolio Shopify' data-cat='.Shopify'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="pommadedivine" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="pommadedivine" srcset="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://pommadedivine.com" class="text-title"> pommadedivine</a> <span class="text-category">Shopify</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td3Shopify" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-1.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/pommadedivine-1.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>pommadedivine</span></h4>
                                                <div class="port_tag">Catagory: Shopify</div>
                                                <p>We are very excited and proud to announce that we are now stocked by NET-A-PORTER, the world's premier online luxury fashion and beauty destination.Our lovely fans in over 180 countries will be happy to know that this makes it even easier for you to experience the magic of Pommade Divine Nature'...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://pommadedivine.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0WebDesign">
                              <div class='portfolio WebDesign' data-cat='.WebDesign'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="prosand" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/prosand-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="prosand" srcset="https://technodeviser.com/wp-content/uploads/2017/05/prosand-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/prosand-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://prosand.com.au/" class="text-title"> prosand</a> <span class="text-category">Web Design</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0WebDesign" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/prosand.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/prosand.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>prosand</span></h4>
                                                <div class="port_tag">Catagory: Web Design</div>
                                                <p>We are a family business and take great pride in our work and the happiness and satisfaction of our valued clients.The extensive timber flooring range at Prosand ensures that our timber floors provide the ideal solutions for any application requirements.Our projects are characterised by th...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://prosand.com.au/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1WebDesign">
                              <div class='portfolio WebDesign' data-cat='.WebDesign'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="mysterywritershowcase" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="mysterywritershowcase" srcset="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1.jpg 400w, https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase-1-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://mysterywritershowcase.com/" class="text-title"> mysterywritershowcase.com</a> <span class="text-category">Web Design</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1WebDesign" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase.jpg">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/05/mysterywritershowcase.jpg" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>mysterywritershowcase.com</span></h4>
                                                <div class="port_tag">Catagory: Web Design</div>
                                                <p>Welcome to Mystery Writer Showcase, a place where you can find top mystery books and audios. We have dedicated this site to individuals who are looking for mystery works of all times. You’ll find different mystery works of several genres and sub genres for you to peruse and find something interest...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://mysterywritershowcase.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td0Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/yumacre.com2_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://yumacre.com/" class="text-title"> Yumacre</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td0Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/yumcare.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/yumcare.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Yumacre</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>Notions of constant and never ending improvement (Velocity) are what drive SVN | Velocity Commercial Real Estate.  SVN | Velocity was founded with the idea that commercial real estate professionals have an enormous responsibility to promote the business, entrepreneurship, and investment activities ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://yumacre.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td1Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/tampacre2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/tampacre2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/tampacre2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://tampacre.com/" class="text-title"> Tampacre</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td1Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/tampcare.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/tampcare.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Tampacre</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>
                                                   Commercial Real Estate Agent John Milsaps has spent the past decade dedicated to his role as a commercial real estate professional who specializes in <a href="https://tampacre.com/landlord-representation/">landlord representation</a> and 
                                                   <a href="https://tampacre.com/seller-representation/">
                                                      seller r...
                                                </p>
                                                <div class="read_btn read_more"><div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://tampacre.com/">READ MORE</a></div></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td2Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnkova.com_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://svnkova.com/" class="text-title"> Svnkova</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td2Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/svnkova.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Svnkova</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>We conduct ourselves with the highest level of integrity, morals, and ethical standards and seek to continually examine and improve ourselves in order to be the best we can be. SVN | KOVA – As a fully integrated family of real estate companies spanning multiple disciplines, we are regarded as an i...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://svnkova.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td3Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnfla2-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/svnfla2.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/svnfla2-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://svnfla.com/" class="text-title"> Svnfla</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td3Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/svnfla.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Svnfla</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>The SVN Florida Land Alliance (“FLA”) is a select group of experienced Commercial Real Estate Advisors focused on LAND. “FLA” services the entire State of Florida from the Panhandle to the Keys. In addition to traditional Commercial Brokerage(CRE), “FLA” provides the entire spectrum of d...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://svnfla.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td4Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/stickyprofiles2-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://stickyprofiles.com/" class="text-title"> Stickyprofiles</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td4Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofile.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/stickyprofile.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Stickyprofiles</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>LinkedIn Sticky Profiles is an outsourced LinkedIn Marketing Company that does LinkedIn social marketing for you. From writing your sticky profile (meaning viewers stick around to engage) to Managing your LinkedIn Account to our custom –designed LinkedIn training/sales coaching, WE DO IT FOR YOU....</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://stickyprofiles.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td5Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/sootaway.net1_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://sootaway.net/" class="text-title"> Sootaway</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td5Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/sootaway.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Sootaway</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>
                                                <p class="font_8">Sootaway, formerly known as Patrick Buell Chimney Services, was founded by Patrick Buell in Pensacola in the summer of 2014. As a Gulf Coast native who cares about his community, Patrick prides himself on being honest and trustworthy in all aspects of business, and always giving ea...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://sootaway.net/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td6Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.com1_-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="http://hfklaw.com" class="text-title"> Hfklaw</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td6Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/hfklaw.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Hfklaw</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>Serve as an independent source of original content, exploring issues confronting the commercial real estate industry
                                                   Impartially cover the events, issues, personalities and ideas that count in commercial real estate today
                                                   Be a sounding board for discussion of new ideas among experienced CRE profes...
                                                </p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="http://hfklaw.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td7Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancerealtyadvisory2-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://alliancerealtyadvisory.com/" class="text-title"> Alliancerealtyadvisory</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td7Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/acredvisory.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/acredvisory.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Alliancerealtyadvisory</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>ARA is ARG’s underwriting and asset-sourcing arm for principal assets in the marketplace for FO (Family Office) and FOA (Family Office Advisory firms) . ARA will underwrite the initial asset specifications and markets for acquisition consideration. ARA members engineer additional steps to achieve ...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://alliancerealtyadvisory.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td8Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_-300x225.jpg 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_.jpg 400w, https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.com_-300x225.jpg 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://alliancecreadvisors.com/" class="text-title"> Alliancecreadvisors</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td8Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/alliancecreadvisors.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>Alliancecreadvisors</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>The Alliance Commercial Real Estate Group is a professional advisory services firm that focuses on the transaction management and financial services arenas of fixed assets. The ARG organization works to create value through commercial real estate for shareholders, clients and its partner organizatio...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://alliancecreadvisors.com/">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="" data-toggle="modal" data-target="#portfolio_td9Wordpress">
                              <div class='portfolio Wordpress' data-cat='.Wordpress'>
                                 <div class="portfolio-wrapper">
                                    <img width="400" height="300" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20300'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/jjosh-300x225.png 300w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png" />
                                    <noscript><img width="400" height="300" src="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2019/05/jjosh.png 400w, https://technodeviser.com/wp-content/uploads/2019/05/jjosh-300x225.png 300w" sizes="100vw" /></noscript>
                                    <div class="label">
                                       <div class="label-text"> 
                           <a target="_blank" href="https://www.jjlyonsmarketing.com" class="text-title"> JJlyonsmarketing</a> <span class="text-category">Wordpress</span></div><div class="label-bg"></div></div></div></div></a>
                           <div id="portfolio_td9Wordpress" class="modal fade in" role="dialog">
                              <div class="modal-dialog">
                                 <div class="modal-content row">
                                    <div class="modal-header custom-modal-header">
                                       <button type="button" class="close" data-dismiss="modal">×</button>
                                       <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="col-sm-12 col-md-7">
                                             <div class="portfolio_image">
                                                <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="portfolio image" title="portfolio name" data-lazy-src="https://technodeviser.com/wp-content/uploads/2019/05/jjlyonsmarketing.png">
                                                <noscript><img src="https://technodeviser.com/wp-content/uploads/2019/05/jjlyonsmarketing.png" alt="portfolio image" title="portfolio name"></noscript>
                                             </div>
                                          </div>
                                          <div class="col-sm-12 col-md-5">
                                             <div class="portfolio_decs">
                                                <h4><span>JJlyonsmarketing</span></h4>
                                                <div class="port_tag">Catagory: Wordpress</div>
                                                <p>Joshua Lyons Marketing, LLC was established in 2015. Since its inception, our team of dedicated writers, content developers, and designers have made it our mission to provide our clients with the top-notch services that have become synonymous with our name. Trust, honesty, and integrity are the foun...</p>
                                                <div class="read_btn read_more">
                                                   <div class="inner_bef"><a target="_blank" class="icon_btn icon_btn_2" href="https://www.jjlyonsmarketing.com">READ MORE</a></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="home_testimonial">
         <div class="container">
            <div class="heading_title">
               <h3>CLIENTS <span>FEEDBACK</span></h3>
            </div>
            <div class="testimonialparagraph">
               <p> We have clients worldwide and our testimonials speak our success stories that how we have helped businesses to establish their online presence with incredible growth. All of our clients have witnessed tremendous growth in their business and online presence performance</p>
            </div>
            <div class="row">
               <div class="col-md-12" data-wow-delay="0.2s">
                  <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                     <ol class="carousel-indicators">
                        <li data-target="#quote-carousel" data-slide-to="0" class="active">
                           <img width="128" height="128" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20128%20128'%3E%3C/svg%3E" class="img-responsive responsive--full wp-post-image" alt="client1" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/client1.jpg 128w, https://technodeviser.com/wp-content/uploads/2017/05/client1-100x100.jpg 100w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/client1.jpg" />
                           <noscript><img width="128" height="128" src="https://technodeviser.com/wp-content/uploads/2017/05/client1.jpg" class="img-responsive responsive--full wp-post-image" alt="client1" srcset="https://technodeviser.com/wp-content/uploads/2017/05/client1.jpg 128w, https://technodeviser.com/wp-content/uploads/2017/05/client1-100x100.jpg 100w" sizes="100vw" /></noscript>
                        </li>
                        <li data-target="#quote-carousel" data-slide-to="1" class="">
                           <img width="310" height="400" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20310%20400'%3E%3C/svg%3E" class="img-responsive responsive--full wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/tony.png 310w, https://technodeviser.com/wp-content/uploads/2017/05/tony-233x300.png 233w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/tony.png" />
                           <noscript><img width="310" height="400" src="https://technodeviser.com/wp-content/uploads/2017/05/tony.png" class="img-responsive responsive--full wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/tony.png 310w, https://technodeviser.com/wp-content/uploads/2017/05/tony-233x300.png 233w" sizes="100vw" /></noscript>
                        </li>
                        <li data-target="#quote-carousel" data-slide-to="2" class="">
                           <img width="310" height="400" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20310%20400'%3E%3C/svg%3E" class="img-responsive responsive--full wp-post-image" alt="" data-lazy-srcset="https://technodeviser.com/wp-content/uploads/2017/05/011.png 310w, https://technodeviser.com/wp-content/uploads/2017/05/011-233x300.png 233w" data-lazy-sizes="100vw" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/05/011.png" />
                           <noscript><img width="310" height="400" src="https://technodeviser.com/wp-content/uploads/2017/05/011.png" class="img-responsive responsive--full wp-post-image" alt="" srcset="https://technodeviser.com/wp-content/uploads/2017/05/011.png 310w, https://technodeviser.com/wp-content/uploads/2017/05/011-233x300.png 233w" sizes="100vw" /></noscript>
                        </li>
                     </ol>
                     <div class="carousel-inner text-center">
                        <div class="item active">
                           <blockquote>
                              <div class="row">
                                 <div class="col-sm-12 col-md-8 col-md-offset-2">
                                    <p>Awesome, first class work. Perfect english.Always available for me, even in emergency situations. Always answers Skype and is always Ready to Work.</p>
                                    <small>Andrew Angle, USA</small>
                                 </div>
                              </div>
                           </blockquote>
                        </div>
                        <div class="item ">
                           <blockquote>
                              <div class="row">
                                 <div class="col-sm-12 col-md-8 col-md-offset-2">
                                    <p> They are awesome! They are very reliable and very good with communication. Looking forward to working with them on future projects.</p>
                                    <small>Tony Tran, USA.</small>
                                 </div>
                              </div>
                           </blockquote>
                        </div>
                        <div class="item ">
                           <blockquote>
                              <div class="row">
                                 <div class="col-sm-12 col-md-8 col-md-offset-2">
                                    <p>They did great job on helping us redesign website.Always communicative and there anytime we needed to make any changes.I will recommend this team 100%</p>
                                    <small>Kristin Trout, USA</small>
                                 </div>
                              </div>
                           </blockquote>
                        </div>
                     </div>
                     <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a><a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="get_touch_o">
      <div class="container">
         <div class="heading_title">
            <h3>GET IN <span>TOUCH</span></h3>
         </div>
         <div class="row">
            <div class="col-sm-12">
               <div class="touch_heading" data-aos="fade-right" data-aos-duration="1000">
                  <h2>FULL-SUITE DIGITAL AGENCY</h2>
                  <p>E-commerce Development, Web Design, SEO & Mobile application Specialists</p>
               </div>
               <div role="form" class="wpcf7" id="wpcf7-f122-o1" lang="en-US" dir="ltr">
                  <div class="screen-reader-response"></div>
                  <form action="/#wpcf7-f122-o1" method="post" class="wpcf7-form" novalidate="novalidate">
                     <div style="display: none;"> <input type="hidden" name="_wpcf7" value="122" /> <input type="hidden" name="_wpcf7_version" value="5.1.3" /> <input type="hidden" name="_wpcf7_locale" value="en_US" /> <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f122-o1" /> <input type="hidden" name="_wpcf7_container_post" value="0" /> <input type="hidden" name="g-recaptcha-response" value="" /></div>
                     <div class="select_query">
                        <div class="select_li">
                           <span class="wpcf7-form-control-wrap your-apply_project">
                              <select name="your-apply_project" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required apply_project" aria-required="true" aria-invalid="false">
                                 <option value="Websites-Solutions">Websites-Solutions</option>
                                 <option value="E-Commerce">E-Commerce</option>
                                 <option value="Graphic-Design">Graphic-Design</option>
                                 <option value="SEO-Services">SEO-Services</option>
                              </select>
                           </span>
                        </div>
                        <div class="get_btn"><input id="aa" type="button" value="GET A QUOTES"></div>
                        </p>
                     </div>
                     <div class="row">
                        <div class="col-sm-12 col-md-offset-3 col-md-6">
                           <div class="get_form">
                              <div class="row">
                                 <div class="col-sm-6"> <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required name1" aria-required="true" aria-invalid="false" placeholder="Name*" /></span></div>
                                 <div class="col-sm-6"> <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email email1" aria-required="true" aria-invalid="false" placeholder="Email*" /></span></div>
                                 </p>
                              </div>
                              <div class="row">
                                 <div class="col-sm-6"> <span class="wpcf7-form-control-wrap your-contact"><input type="tel" name="your-contact" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel contect1" aria-required="true" aria-invalid="false" placeholder="Contact*" /></span></div>
                                 <div class="col-sm-6"> <span class="wpcf7-form-control-wrap your-business"><input type="text" name="your-business" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required business1" aria-required="true" aria-invalid="false" placeholder="Business*" /></span></div>
                                 </p>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12"> <span class="wpcf7-form-control-wrap your-enquiry"><textarea name="your-enquiry" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required enquiry1" aria-required="true" aria-invalid="false" placeholder="Enquiry*"></textarea></span></div>
                                 </p>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12"></div>
                                 <div class="row">
                                    <div class="col-sm-12">
                                       <div class="get_btn2 get2"><input type="submit" value="CALL ME" class="wpcf7-form-control wpcf7-submit" /></div>
                                       </p>
                                    </div>
                                    </p>
                                 </div>
                                 <div class="wpcf7-response-output wpcf7-display-none"></div>
                  </form>
                  </div></div></div></div>
               </div>
            </div>
         </div>
      </div>
      <div id="follow_us">
         <div class="container">
            <div class="heading_title">
               <h3>SOCIAL <span>FOLLOW US</span></h3>
            </div>
            <div class="row">
               <div class="col-sm-6">
                  <div class="social_follow_l" data-aos="fade-up" data-aos-duration="2000">
                     <section id="text-19" class="widget widget_text">
                        <div class="textwidget">
                           <div class="fb-page" data-href="https://www.facebook.com/technodeviser/" data-tabs="timeline" data-height="275" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                              <blockquote cite="https://www.facebook.com/technodeviser/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/technodeviser/">Techno Deviser</a></blockquote>
                           </div>
                        </div>
                     </section>
                  </div>
               </div>
               <div class="col-sm-6">
                  <div class="social_follow_r" data-aos="fade-up" data-aos-duration="2000">
                     <section id="text-20" class="widget widget_text">
                        <div class="textwidget"><a class="twitter-timeline" href="https://twitter.com/technodeviser" data-height="275">Tweets by technodeviser</a></div>
                     </section>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade td-certificate" id="myModal" role="dialog">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-body">
                  <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/11/TD-certificate.jpg">
                  <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/11/TD-certificate.jpg"></noscript>
               </div>
            </div>
         </div>
      </div>
      <div id="contact_touch">
         <div class="container">
            <div class="heading_title">
               <h3>CONTACT <span>US</span></h3>
            </div>
            <div class="row">
               <div class="col-sm-4">
                  <div class="contact_blo contact_keymse" data-aos="fade-up" data-aos-duration="1000">
                     <section id="text-12" class="widget widget_text">
                        <div class="textwidget">
                           <h3>Get in Touch <span>With Us!</span></h3>
                           <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="/wp-content/uploads/2017/05/keyboard_img2.png">
                           <noscript><img src="/wp-content/uploads/2017/05/keyboard_img2.png"></noscript>
                        </div>
                     </section>
                  </div>
               </div>
               <div class="col-sm-1"></div>
               <div class="col-sm-4">
                  <div class="contact_blo visit_blo" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="2000">
                     <section id="text-13" class="widget widget_text">
                        <div class="textwidget">
                           <h6>VISIT US</h6>
                           <dl>
                              <dt><i class="fa fa-envelope" aria-hidden="true"></i></dt>
                              <dd><small>Email: </small> <a href="/cdn-cgi/l/email-protection#bd9dd4d3dbd2fdc9d8ded5d3d2d9d8cbd4ced8cf93ded2d0"><span class="__cf_email__" data-cfemail="7e171018113e0a1b1d1610111a1b08170d1b0c501d1113">[email&#160;protected]</span> </a></dd>
                              <dt><i class="fa fa-location-arrow" aria-hidden="true"></i></dt>
                              <dd><small>Address: </small> <em><span>Techknow Deviser Professional Pvt. Ltd</span> E-287 4th Floor, Sector 75, Industrial Area Phase 8-A, Sahibzada Ajit Singh Nagar, Punjab 160055, India</em></dd>
                           </dl>
                        </div>
                     </section>
                  </div>
               </div>
               <div class="col-sm-1"></div>
               <div class="col-sm-2">
                  <div class="contact_blo iso-logo" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="2000">
                     <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://technodeviser.com/wp-content/uploads/2017/06/tdg.png">
                        <noscript><img src="https://technodeviser.com/wp-content/uploads/2017/06/tdg.png"></noscript>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="contact_map">
         <div class="">
            <div class="">
               <div class="social_icon" data-aos="flip-left" data-aos-duration="2000">
                  <section id="text-16" class="widget widget_text">
                     <div class="textwidget">
                        <p>FOLLOW US</p>
                        <ul>
                           <li><a href="https://www.facebook.com/technodeviser/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                           <li><a href="https://twitter.com/technodeviser"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                           <li><a target="_blank" href="https://www.linkedin.com/company/techno-deviser" rel="noopener noreferrer"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        </ul>
                     </div>
                  </section>
               </div>
            </div>
         </div>
      </div>
      <div class="copyright"> <small>copyright© 2021. All rights reserved. </small></div>
      <a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Click to Top" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>
      <div id="fb-root"></div>
      <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=97914956"></script> <script type="602628bac18f9de0e8cae51b-text/javascript">/* <![CDATA[ */ var wpcf7 = {"apiSettings":{"root":"https:\/\/technodeviser.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"}; /* ]]> */</script> <script type="602628bac18f9de0e8cae51b-text/javascript">/* <![CDATA[ */ var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/technodeviser.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"}; /* ]]> */</script> <script type="602628bac18f9de0e8cae51b-text/javascript">/* <![CDATA[ */ var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"}; /* ]]> */</script> <script type="602628bac18f9de0e8cae51b-text/javascript">/* <![CDATA[ */ var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_ab561e7949fc899c308a06dcb9b2826e","fragment_name":"wc_fragments_ab561e7949fc899c308a06dcb9b2826e","request_timeout":"5000"}; /* ]]> */</script> <script type="602628bac18f9de0e8cae51b-text/javascript" src='https://www.google.com/recaptcha/api.js?render=6Ld4FuYUAAAAAMTgX55eOAwbLvfocSjsrYoxQXOk&#038;ver=3.0'></script> <script type="602628bac18f9de0e8cae51b-text/javascript">/* <![CDATA[ */ var availScreenReaderText = {"quote":"<svg class=\"icon icon-quote-right\" aria-hidden=\"true\" role=\"img\"> <use href=\"#icon-quote-right\" xlink:href=\"#icon-quote-right\"><\/use> <\/svg>","expand":"Expand child menu","collapse":"Collapse child menu","icon":"<svg class=\"icon icon-angle-down\" aria-hidden=\"true\" role=\"img\"> <use href=\"#icon-angle-down\" xlink:href=\"#icon-angle-down\"><\/use> <span class=\"svg-fallback icon-angle-down\"><\/span><\/svg>"}; /* ]]> */</script> <script type="602628bac18f9de0e8cae51b-text/javascript">/* <![CDATA[ */ var megamenu = {"timeout":"300","interval":"100"}; /* ]]> */</script> 
      <svg style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
         <defs>
            <symbol id="icon-behance" viewBox="0 0 37 32">
               <path class="path1" d="M33 6.054h-9.125v2.214h9.125v-2.214zM28.5 13.661q-1.607 0-2.607 0.938t-1.107 2.545h7.286q-0.321-3.482-3.571-3.482zM28.786 24.107q1.125 0 2.179-0.571t1.357-1.554h3.946q-1.786 5.482-7.625 5.482-3.821 0-6.080-2.357t-2.259-6.196q0-3.714 2.33-6.17t6.009-2.455q2.464 0 4.295 1.214t2.732 3.196 0.902 4.429q0 0.304-0.036 0.839h-11.75q0 1.982 1.027 3.063t2.973 1.080zM4.946 23.214h5.286q3.661 0 3.661-2.982 0-3.214-3.554-3.214h-5.393v6.196zM4.946 13.625h5.018q1.393 0 2.205-0.652t0.813-2.027q0-2.571-3.393-2.571h-4.643v5.25zM0 4.536h10.607q1.554 0 2.768 0.25t2.259 0.848 1.607 1.723 0.563 2.75q0 3.232-3.071 4.696 2.036 0.571 3.071 2.054t1.036 3.643q0 1.339-0.438 2.438t-1.179 1.848-1.759 1.268-2.161 0.75-2.393 0.232h-10.911v-22.5z"></path>
            </symbol>
            <symbol id="icon-deviantart" viewBox="0 0 18 32">
               <path class="path1" d="M18.286 5.411l-5.411 10.393 0.429 0.554h4.982v7.411h-9.054l-0.786 0.536-2.536 4.875-0.536 0.536h-5.375v-5.411l5.411-10.411-0.429-0.536h-4.982v-7.411h9.054l0.786-0.536 2.536-4.875 0.536-0.536h5.375v5.411z"></path>
            </symbol>
            <symbol id="icon-medium" viewBox="0 0 32 32">
               <path class="path1" d="M10.661 7.518v20.946q0 0.446-0.223 0.759t-0.652 0.313q-0.304 0-0.589-0.143l-8.304-4.161q-0.375-0.179-0.634-0.598t-0.259-0.83v-20.357q0-0.357 0.179-0.607t0.518-0.25q0.25 0 0.786 0.268l9.125 4.571q0.054 0.054 0.054 0.089zM11.804 9.321l9.536 15.464-9.536-4.75v-10.714zM32 9.643v18.821q0 0.446-0.25 0.723t-0.679 0.277-0.839-0.232l-7.875-3.929zM31.946 7.5q0 0.054-4.58 7.491t-5.366 8.705l-6.964-11.321 5.786-9.411q0.304-0.5 0.929-0.5 0.25 0 0.464 0.107l9.661 4.821q0.071 0.036 0.071 0.107z"></path>
            </symbol>
            <symbol id="icon-slideshare" viewBox="0 0 32 32">
               <path class="path1" d="M15.589 13.214q0 1.482-1.134 2.545t-2.723 1.063-2.723-1.063-1.134-2.545q0-1.5 1.134-2.554t2.723-1.054 2.723 1.054 1.134 2.554zM24.554 13.214q0 1.482-1.125 2.545t-2.732 1.063q-1.589 0-2.723-1.063t-1.134-2.545q0-1.5 1.134-2.554t2.723-1.054q1.607 0 2.732 1.054t1.125 2.554zM28.571 16.429v-11.911q0-1.554-0.571-2.205t-1.982-0.652h-19.857q-1.482 0-2.009 0.607t-0.527 2.25v12.018q0.768 0.411 1.58 0.714t1.446 0.5 1.446 0.33 1.268 0.196 1.25 0.071 1.045 0.009 1.009-0.036 0.795-0.036q1.214-0.018 1.696 0.482 0.107 0.107 0.179 0.161 0.464 0.446 1.089 0.911 0.125-1.625 2.107-1.554 0.089 0 0.652 0.027t0.768 0.036 0.813 0.018 0.946-0.018 0.973-0.080 1.089-0.152 1.107-0.241 1.196-0.348 1.205-0.482 1.286-0.616zM31.482 16.339q-2.161 2.661-6.643 4.5 1.5 5.089-0.411 8.304-1.179 2.018-3.268 2.643-1.857 0.571-3.25-0.268-1.536-0.911-1.464-2.929l-0.018-5.821v-0.018q-0.143-0.036-0.438-0.107t-0.42-0.089l-0.018 6.036q0.071 2.036-1.482 2.929-1.411 0.839-3.268 0.268-2.089-0.643-3.25-2.679-1.875-3.214-0.393-8.268-4.482-1.839-6.643-4.5-0.446-0.661-0.071-1.125t1.071 0.018q0.054 0.036 0.196 0.125t0.196 0.143v-12.393q0-1.286 0.839-2.196t2.036-0.911h22.446q1.196 0 2.036 0.911t0.839 2.196v12.393l0.375-0.268q0.696-0.482 1.071-0.018t-0.071 1.125z"></path>
            </symbol>
            <symbol id="icon-snapchat-ghost" viewBox="0 0 30 32">
               <path class="path1" d="M15.143 2.286q2.393-0.018 4.295 1.223t2.92 3.438q0.482 1.036 0.482 3.196 0 0.839-0.161 3.411 0.25 0.125 0.5 0.125 0.321 0 0.911-0.241t0.911-0.241q0.518 0 1 0.321t0.482 0.821q0 0.571-0.563 0.964t-1.232 0.563-1.232 0.518-0.563 0.848q0 0.268 0.214 0.768 0.661 1.464 1.83 2.679t2.58 1.804q0.5 0.214 1.429 0.411 0.5 0.107 0.5 0.625 0 1.25-3.911 1.839-0.125 0.196-0.196 0.696t-0.25 0.83-0.589 0.33q-0.357 0-1.107-0.116t-1.143-0.116q-0.661 0-1.107 0.089-0.571 0.089-1.125 0.402t-1.036 0.679-1.036 0.723-1.357 0.598-1.768 0.241q-0.929 0-1.723-0.241t-1.339-0.598-1.027-0.723-1.036-0.679-1.107-0.402q-0.464-0.089-1.125-0.089-0.429 0-1.17 0.134t-1.045 0.134q-0.446 0-0.625-0.33t-0.25-0.848-0.196-0.714q-3.911-0.589-3.911-1.839 0-0.518 0.5-0.625 0.929-0.196 1.429-0.411 1.393-0.571 2.58-1.804t1.83-2.679q0.214-0.5 0.214-0.768 0-0.5-0.563-0.848t-1.241-0.527-1.241-0.563-0.563-0.938q0-0.482 0.464-0.813t0.982-0.33q0.268 0 0.857 0.232t0.946 0.232q0.321 0 0.571-0.125-0.161-2.536-0.161-3.393 0-2.179 0.482-3.214 1.143-2.446 3.071-3.536t4.714-1.125z"></path>
            </symbol>
            <symbol id="icon-yelp" viewBox="0 0 27 32">
               <path class="path1" d="M13.804 23.554v2.268q-0.018 5.214-0.107 5.446-0.214 0.571-0.911 0.714-0.964 0.161-3.241-0.679t-2.902-1.589q-0.232-0.268-0.304-0.643-0.018-0.214 0.071-0.464 0.071-0.179 0.607-0.839t3.232-3.857q0.018 0 1.071-1.25 0.268-0.339 0.705-0.438t0.884 0.063q0.429 0.179 0.67 0.518t0.223 0.75zM11.143 19.071q-0.054 0.982-0.929 1.25l-2.143 0.696q-4.911 1.571-5.214 1.571-0.625-0.036-0.964-0.643-0.214-0.446-0.304-1.339-0.143-1.357 0.018-2.973t0.536-2.223 1-0.571q0.232 0 3.607 1.375 1.25 0.518 2.054 0.839l1.5 0.607q0.411 0.161 0.634 0.545t0.205 0.866zM25.893 24.375q-0.125 0.964-1.634 2.875t-2.42 2.268q-0.661 0.25-1.125-0.125-0.25-0.179-3.286-5.125l-0.839-1.375q-0.25-0.375-0.205-0.821t0.348-0.821q0.625-0.768 1.482-0.464 0.018 0.018 2.125 0.714 3.625 1.179 4.321 1.42t0.839 0.366q0.5 0.393 0.393 1.089zM13.893 13.089q0.089 1.821-0.964 2.179-1.036 0.304-2.036-1.268l-6.75-10.679q-0.143-0.625 0.339-1.107 0.732-0.768 3.705-1.598t4.009-0.563q0.714 0.179 0.875 0.804 0.054 0.321 0.393 5.455t0.429 6.777zM25.714 15.018q0.054 0.696-0.464 1.054-0.268 0.179-5.875 1.536-1.196 0.268-1.625 0.411l0.018-0.036q-0.411 0.107-0.821-0.071t-0.661-0.571q-0.536-0.839 0-1.554 0.018-0.018 1.339-1.821 2.232-3.054 2.679-3.643t0.607-0.696q0.5-0.339 1.161-0.036 0.857 0.411 2.196 2.384t1.446 2.991v0.054z"></path>
            </symbol>
            <symbol id="icon-vine" viewBox="0 0 27 32">
               <path class="path1" d="M26.732 14.768v3.536q-1.804 0.411-3.536 0.411-1.161 2.429-2.955 4.839t-3.241 3.848-2.286 1.902q-1.429 0.804-2.893-0.054-0.5-0.304-1.080-0.777t-1.518-1.491-1.83-2.295-1.92-3.286-1.884-4.357-1.634-5.616-1.259-6.964h5.054q0.464 3.893 1.25 7.116t1.866 5.661 2.17 4.205 2.5 3.482q3.018-3.018 5.125-7.25-2.536-1.286-3.982-3.929t-1.446-5.946q0-3.429 1.857-5.616t5.071-2.188q3.179 0 4.875 1.884t1.696 5.313q0 2.839-1.036 5.107-0.125 0.018-0.348 0.054t-0.821 0.036-1.125-0.107-1.107-0.455-0.902-0.92q0.554-1.839 0.554-3.286 0-1.554-0.518-2.357t-1.411-0.804q-0.946 0-1.518 0.884t-0.571 2.509q0 3.321 1.875 5.241t4.768 1.92q1.107 0 2.161-0.25z"></path>
            </symbol>
            <symbol id="icon-vk" viewBox="0 0 35 32">
               <path class="path1" d="M34.232 9.286q0.411 1.143-2.679 5.25-0.429 0.571-1.161 1.518-1.393 1.786-1.607 2.339-0.304 0.732 0.25 1.446 0.304 0.375 1.446 1.464h0.018l0.071 0.071q2.518 2.339 3.411 3.946 0.054 0.089 0.116 0.223t0.125 0.473-0.009 0.607-0.446 0.491-1.054 0.223l-4.571 0.071q-0.429 0.089-1-0.089t-0.929-0.393l-0.357-0.214q-0.536-0.375-1.25-1.143t-1.223-1.384-1.089-1.036-1.009-0.277q-0.054 0.018-0.143 0.063t-0.304 0.259-0.384 0.527-0.304 0.929-0.116 1.384q0 0.268-0.063 0.491t-0.134 0.33l-0.071 0.089q-0.321 0.339-0.946 0.393h-2.054q-1.268 0.071-2.607-0.295t-2.348-0.946-1.839-1.179-1.259-1.027l-0.446-0.429q-0.179-0.179-0.491-0.536t-1.277-1.625-1.893-2.696-2.188-3.768-2.33-4.857q-0.107-0.286-0.107-0.482t0.054-0.286l0.071-0.107q0.268-0.339 1.018-0.339l4.893-0.036q0.214 0.036 0.411 0.116t0.286 0.152l0.089 0.054q0.286 0.196 0.429 0.571 0.357 0.893 0.821 1.848t0.732 1.455l0.286 0.518q0.518 1.071 1 1.857t0.866 1.223 0.741 0.688 0.607 0.25 0.482-0.089q0.036-0.018 0.089-0.089t0.214-0.393 0.241-0.839 0.17-1.446 0-2.232q-0.036-0.714-0.161-1.304t-0.25-0.821l-0.107-0.214q-0.446-0.607-1.518-0.768-0.232-0.036 0.089-0.429 0.304-0.339 0.679-0.536 0.946-0.464 4.268-0.429 1.464 0.018 2.411 0.232 0.357 0.089 0.598 0.241t0.366 0.429 0.188 0.571 0.063 0.813-0.018 0.982-0.045 1.259-0.027 1.473q0 0.196-0.018 0.75t-0.009 0.857 0.063 0.723 0.205 0.696 0.402 0.438q0.143 0.036 0.304 0.071t0.464-0.196 0.679-0.616 0.929-1.196 1.214-1.92q1.071-1.857 1.911-4.018 0.071-0.179 0.179-0.313t0.196-0.188l0.071-0.054 0.089-0.045t0.232-0.054 0.357-0.009l5.143-0.036q0.696-0.089 1.143 0.045t0.554 0.295z"></path>
            </symbol>
            <symbol id="icon-search" viewBox="0 0 30 32">
               <path class="path1" d="M20.571 14.857q0-3.304-2.348-5.652t-5.652-2.348-5.652 2.348-2.348 5.652 2.348 5.652 5.652 2.348 5.652-2.348 2.348-5.652zM29.714 29.714q0 0.929-0.679 1.607t-1.607 0.679q-0.964 0-1.607-0.679l-6.125-6.107q-3.196 2.214-7.125 2.214-2.554 0-4.884-0.991t-4.018-2.679-2.679-4.018-0.991-4.884 0.991-4.884 2.679-4.018 4.018-2.679 4.884-0.991 4.884 0.991 4.018 2.679 2.679 4.018 0.991 4.884q0 3.929-2.214 7.125l6.125 6.125q0.661 0.661 0.661 1.607z"></path>
            </symbol>
            <symbol id="icon-envelope-o" viewBox="0 0 32 32">
               <path class="path1" d="M29.714 26.857v-13.714q-0.571 0.643-1.232 1.179-4.786 3.679-7.607 6.036-0.911 0.768-1.482 1.196t-1.545 0.866-1.83 0.438h-0.036q-0.857 0-1.83-0.438t-1.545-0.866-1.482-1.196q-2.821-2.357-7.607-6.036-0.661-0.536-1.232-1.179v13.714q0 0.232 0.17 0.402t0.402 0.17h26.286q0.232 0 0.402-0.17t0.17-0.402zM29.714 8.089v-0.438t-0.009-0.232-0.054-0.223-0.098-0.161-0.161-0.134-0.25-0.045h-26.286q-0.232 0-0.402 0.17t-0.17 0.402q0 3 2.625 5.071 3.446 2.714 7.161 5.661 0.107 0.089 0.625 0.527t0.821 0.67 0.795 0.563 0.902 0.491 0.768 0.161h0.036q0.357 0 0.768-0.161t0.902-0.491 0.795-0.563 0.821-0.67 0.625-0.527q3.714-2.946 7.161-5.661 0.964-0.768 1.795-2.063t0.83-2.348zM32 7.429v19.429q0 1.179-0.839 2.018t-2.018 0.839h-26.286q-1.179 0-2.018-0.839t-0.839-2.018v-19.429q0-1.179 0.839-2.018t2.018-0.839h26.286q1.179 0 2.018 0.839t0.839 2.018z"></path>
            </symbol>
            <symbol id="icon-close" viewBox="0 0 25 32">
               <path class="path1" d="M23.179 23.607q0 0.714-0.5 1.214l-2.429 2.429q-0.5 0.5-1.214 0.5t-1.214-0.5l-5.25-5.25-5.25 5.25q-0.5 0.5-1.214 0.5t-1.214-0.5l-2.429-2.429q-0.5-0.5-0.5-1.214t0.5-1.214l5.25-5.25-5.25-5.25q-0.5-0.5-0.5-1.214t0.5-1.214l2.429-2.429q0.5-0.5 1.214-0.5t1.214 0.5l5.25 5.25 5.25-5.25q0.5-0.5 1.214-0.5t1.214 0.5l2.429 2.429q0.5 0.5 0.5 1.214t-0.5 1.214l-5.25 5.25 5.25 5.25q0.5 0.5 0.5 1.214z"></path>
            </symbol>
            <symbol id="icon-angle-down" viewBox="0 0 21 32">
               <path class="path1" d="M19.196 13.143q0 0.232-0.179 0.411l-8.321 8.321q-0.179 0.179-0.411 0.179t-0.411-0.179l-8.321-8.321q-0.179-0.179-0.179-0.411t0.179-0.411l0.893-0.893q0.179-0.179 0.411-0.179t0.411 0.179l7.018 7.018 7.018-7.018q0.179-0.179 0.411-0.179t0.411 0.179l0.893 0.893q0.179 0.179 0.179 0.411z"></path>
            </symbol>
            <symbol id="icon-folder-open" viewBox="0 0 34 32">
               <path class="path1" d="M33.554 17q0 0.554-0.554 1.179l-6 7.071q-0.768 0.911-2.152 1.545t-2.563 0.634h-19.429q-0.607 0-1.080-0.232t-0.473-0.768q0-0.554 0.554-1.179l6-7.071q0.768-0.911 2.152-1.545t2.563-0.634h19.429q0.607 0 1.080 0.232t0.473 0.768zM27.429 10.857v2.857h-14.857q-1.679 0-3.518 0.848t-2.929 2.134l-6.107 7.179q0-0.071-0.009-0.223t-0.009-0.223v-17.143q0-1.643 1.179-2.821t2.821-1.179h5.714q1.643 0 2.821 1.179t1.179 2.821v0.571h9.714q1.643 0 2.821 1.179t1.179 2.821z"></path>
            </symbol>
            <symbol id="icon-twitter" viewBox="0 0 30 32">
               <path class="path1" d="M28.929 7.286q-1.196 1.75-2.893 2.982 0.018 0.25 0.018 0.75 0 2.321-0.679 4.634t-2.063 4.437-3.295 3.759-4.607 2.607-5.768 0.973q-4.839 0-8.857-2.589 0.625 0.071 1.393 0.071 4.018 0 7.161-2.464-1.875-0.036-3.357-1.152t-2.036-2.848q0.589 0.089 1.089 0.089 0.768 0 1.518-0.196-2-0.411-3.313-1.991t-1.313-3.67v-0.071q1.214 0.679 2.607 0.732-1.179-0.786-1.875-2.054t-0.696-2.75q0-1.571 0.786-2.911 2.161 2.661 5.259 4.259t6.634 1.777q-0.143-0.679-0.143-1.321 0-2.393 1.688-4.080t4.080-1.688q2.5 0 4.214 1.821 1.946-0.375 3.661-1.393-0.661 2.054-2.536 3.179 1.661-0.179 3.321-0.893z"></path>
            </symbol>
            <symbol id="icon-facebook" viewBox="0 0 19 32">
               <path class="path1" d="M17.125 0.214v4.714h-2.804q-1.536 0-2.071 0.643t-0.536 1.929v3.375h5.232l-0.696 5.286h-4.536v13.554h-5.464v-13.554h-4.554v-5.286h4.554v-3.893q0-3.321 1.857-5.152t4.946-1.83q2.625 0 4.071 0.214z"></path>
            </symbol>
            <symbol id="icon-github" viewBox="0 0 27 32">
               <path class="path1" d="M13.714 2.286q3.732 0 6.884 1.839t4.991 4.991 1.839 6.884q0 4.482-2.616 8.063t-6.759 4.955q-0.482 0.089-0.714-0.125t-0.232-0.536q0-0.054 0.009-1.366t0.009-2.402q0-1.732-0.929-2.536 1.018-0.107 1.83-0.321t1.679-0.696 1.446-1.188 0.946-1.875 0.366-2.688q0-2.125-1.411-3.679 0.661-1.625-0.143-3.643-0.5-0.161-1.446 0.196t-1.643 0.786l-0.679 0.429q-1.661-0.464-3.429-0.464t-3.429 0.464q-0.286-0.196-0.759-0.482t-1.491-0.688-1.518-0.241q-0.804 2.018-0.143 3.643-1.411 1.554-1.411 3.679 0 1.518 0.366 2.679t0.938 1.875 1.438 1.196 1.679 0.696 1.83 0.321q-0.696 0.643-0.875 1.839-0.375 0.179-0.804 0.268t-1.018 0.089-1.17-0.384-0.991-1.116q-0.339-0.571-0.866-0.929t-0.884-0.429l-0.357-0.054q-0.375 0-0.518 0.080t-0.089 0.205 0.161 0.25 0.232 0.214l0.125 0.089q0.393 0.179 0.777 0.679t0.563 0.911l0.179 0.411q0.232 0.679 0.786 1.098t1.196 0.536 1.241 0.125 0.991-0.063l0.411-0.071q0 0.679 0.009 1.58t0.009 0.973q0 0.321-0.232 0.536t-0.714 0.125q-4.143-1.375-6.759-4.955t-2.616-8.063q0-3.732 1.839-6.884t4.991-4.991 6.884-1.839zM5.196 21.982q0.054-0.125-0.125-0.214-0.179-0.054-0.232 0.036-0.054 0.125 0.125 0.214 0.161 0.107 0.232-0.036zM5.75 22.589q0.125-0.089-0.036-0.286-0.179-0.161-0.286-0.054-0.125 0.089 0.036 0.286 0.179 0.179 0.286 0.054zM6.286 23.393q0.161-0.125 0-0.339-0.143-0.232-0.304-0.107-0.161 0.089 0 0.321t0.304 0.125zM7.036 24.143q0.143-0.143-0.071-0.339-0.214-0.214-0.357-0.054-0.161 0.143 0.071 0.339 0.214 0.214 0.357 0.054zM8.054 24.589q0.054-0.196-0.232-0.286-0.268-0.071-0.339 0.125t0.232 0.268q0.268 0.107 0.339-0.107zM9.179 24.679q0-0.232-0.304-0.196-0.286 0-0.286 0.196 0 0.232 0.304 0.196 0.286 0 0.286-0.196zM10.214 24.5q-0.036-0.196-0.321-0.161-0.286 0.054-0.25 0.268t0.321 0.143 0.25-0.25z"></path>
            </symbol>
            <symbol id="icon-bars" viewBox="0 0 27 32">
               <path class="path1" d="M27.429 24v2.286q0 0.464-0.339 0.804t-0.804 0.339h-25.143q-0.464 0-0.804-0.339t-0.339-0.804v-2.286q0-0.464 0.339-0.804t0.804-0.339h25.143q0.464 0 0.804 0.339t0.339 0.804zM27.429 14.857v2.286q0 0.464-0.339 0.804t-0.804 0.339h-25.143q-0.464 0-0.804-0.339t-0.339-0.804v-2.286q0-0.464 0.339-0.804t0.804-0.339h25.143q0.464 0 0.804 0.339t0.339 0.804zM27.429 5.714v2.286q0 0.464-0.339 0.804t-0.804 0.339h-25.143q-0.464 0-0.804-0.339t-0.339-0.804v-2.286q0-0.464 0.339-0.804t0.804-0.339h25.143q0.464 0 0.804 0.339t0.339 0.804z"></path>
            </symbol>
            <symbol id="icon-google-plus" viewBox="0 0 41 32">
               <path class="path1" d="M25.661 16.304q0 3.714-1.554 6.616t-4.429 4.536-6.589 1.634q-2.661 0-5.089-1.036t-4.179-2.786-2.786-4.179-1.036-5.089 1.036-5.089 2.786-4.179 4.179-2.786 5.089-1.036q5.107 0 8.768 3.429l-3.554 3.411q-2.089-2.018-5.214-2.018-2.196 0-4.063 1.107t-2.955 3.009-1.089 4.152 1.089 4.152 2.955 3.009 4.063 1.107q1.482 0 2.723-0.411t2.045-1.027 1.402-1.402 0.875-1.482 0.384-1.321h-7.429v-4.5h12.357q0.214 1.125 0.214 2.179zM41.143 14.125v3.75h-3.732v3.732h-3.75v-3.732h-3.732v-3.75h3.732v-3.732h3.75v3.732h3.732z"></path>
            </symbol>
            <symbol id="icon-linkedin" viewBox="0 0 27 32">
               <path class="path1" d="M6.232 11.161v17.696h-5.893v-17.696h5.893zM6.607 5.696q0.018 1.304-0.902 2.179t-2.42 0.875h-0.036q-1.464 0-2.357-0.875t-0.893-2.179q0-1.321 0.92-2.188t2.402-0.866 2.375 0.866 0.911 2.188zM27.429 18.714v10.143h-5.875v-9.464q0-1.875-0.723-2.938t-2.259-1.063q-1.125 0-1.884 0.616t-1.134 1.527q-0.196 0.536-0.196 1.446v9.875h-5.875q0.036-7.125 0.036-11.554t-0.018-5.286l-0.018-0.857h5.875v2.571h-0.036q0.357-0.571 0.732-1t1.009-0.929 1.554-0.777 2.045-0.277q3.054 0 4.911 2.027t1.857 5.938z"></path>
            </symbol>
            <symbol id="icon-quote-right" viewBox="0 0 30 32">
               <path class="path1" d="M13.714 5.714v12.571q0 1.857-0.723 3.545t-1.955 2.92-2.92 1.955-3.545 0.723h-1.143q-0.464 0-0.804-0.339t-0.339-0.804v-2.286q0-0.464 0.339-0.804t0.804-0.339h1.143q1.893 0 3.232-1.339t1.339-3.232v-0.571q0-0.714-0.5-1.214t-1.214-0.5h-4q-1.429 0-2.429-1t-1-2.429v-6.857q0-1.429 1-2.429t2.429-1h6.857q1.429 0 2.429 1t1 2.429zM29.714 5.714v12.571q0 1.857-0.723 3.545t-1.955 2.92-2.92 1.955-3.545 0.723h-1.143q-0.464 0-0.804-0.339t-0.339-0.804v-2.286q0-0.464 0.339-0.804t0.804-0.339h1.143q1.893 0 3.232-1.339t1.339-3.232v-0.571q0-0.714-0.5-1.214t-1.214-0.5h-4q-1.429 0-2.429-1t-1-2.429v-6.857q0-1.429 1-2.429t2.429-1h6.857q1.429 0 2.429 1t1 2.429z"></path>
            </symbol>
            <symbol id="icon-mail-reply" viewBox="0 0 32 32">
               <path class="path1" d="M32 20q0 2.964-2.268 8.054-0.054 0.125-0.188 0.429t-0.241 0.536-0.232 0.393q-0.214 0.304-0.5 0.304-0.268 0-0.42-0.179t-0.152-0.446q0-0.161 0.045-0.473t0.045-0.42q0.089-1.214 0.089-2.196 0-1.804-0.313-3.232t-0.866-2.473-1.429-1.804-1.884-1.241-2.375-0.759-2.75-0.384-3.134-0.107h-4v4.571q0 0.464-0.339 0.804t-0.804 0.339-0.804-0.339l-9.143-9.143q-0.339-0.339-0.339-0.804t0.339-0.804l9.143-9.143q0.339-0.339 0.804-0.339t0.804 0.339 0.339 0.804v4.571h4q12.732 0 15.625 7.196 0.946 2.393 0.946 5.946z"></path>
            </symbol>
            <symbol id="icon-youtube" viewBox="0 0 27 32">
               <path class="path1" d="M17.339 22.214v3.768q0 1.196-0.696 1.196-0.411 0-0.804-0.393v-5.375q0.393-0.393 0.804-0.393 0.696 0 0.696 1.196zM23.375 22.232v0.821h-1.607v-0.821q0-1.214 0.804-1.214t0.804 1.214zM6.125 18.339h1.911v-1.679h-5.571v1.679h1.875v10.161h1.786v-10.161zM11.268 28.5h1.589v-8.821h-1.589v6.75q-0.536 0.75-1.018 0.75-0.321 0-0.375-0.375-0.018-0.054-0.018-0.625v-6.5h-1.589v6.982q0 0.875 0.143 1.304 0.214 0.661 1.036 0.661 0.857 0 1.821-1.089v0.964zM18.929 25.857v-3.518q0-1.304-0.161-1.768-0.304-1-1.268-1-0.893 0-1.661 0.964v-3.875h-1.589v11.839h1.589v-0.857q0.804 0.982 1.661 0.982 0.964 0 1.268-0.982 0.161-0.482 0.161-1.786zM24.964 25.679v-0.232h-1.625q0 0.911-0.036 1.089-0.125 0.643-0.714 0.643-0.821 0-0.821-1.232v-1.554h3.196v-1.839q0-1.411-0.482-2.071-0.696-0.911-1.893-0.911-1.214 0-1.911 0.911-0.5 0.661-0.5 2.071v3.089q0 1.411 0.518 2.071 0.696 0.911 1.929 0.911 1.286 0 1.929-0.946 0.321-0.482 0.375-0.964 0.036-0.161 0.036-1.036zM14.107 9.375v-3.75q0-1.232-0.768-1.232t-0.768 1.232v3.75q0 1.25 0.768 1.25t0.768-1.25zM26.946 22.786q0 4.179-0.464 6.25-0.25 1.054-1.036 1.768t-1.821 0.821q-3.286 0.375-9.911 0.375t-9.911-0.375q-1.036-0.107-1.83-0.821t-1.027-1.768q-0.464-2-0.464-6.25 0-4.179 0.464-6.25 0.25-1.054 1.036-1.768t1.839-0.839q3.268-0.357 9.893-0.357t9.911 0.357q1.036 0.125 1.83 0.839t1.027 1.768q0.464 2 0.464 6.25zM9.125 0h1.821l-2.161 7.125v4.839h-1.786v-4.839q-0.25-1.321-1.089-3.786-0.661-1.839-1.161-3.339h1.893l1.268 4.696zM15.732 5.946v3.125q0 1.446-0.5 2.107-0.661 0.911-1.893 0.911-1.196 0-1.875-0.911-0.5-0.679-0.5-2.107v-3.125q0-1.429 0.5-2.089 0.679-0.911 1.875-0.911 1.232 0 1.893 0.911 0.5 0.661 0.5 2.089zM21.714 3.054v8.911h-1.625v-0.982q-0.946 1.107-1.839 1.107-0.821 0-1.054-0.661-0.143-0.429-0.143-1.339v-7.036h1.625v6.554q0 0.589 0.018 0.625 0.054 0.393 0.375 0.393 0.482 0 1.018-0.768v-6.804h1.625z"></path>
            </symbol>
            <symbol id="icon-dropbox" viewBox="0 0 32 32">
               <path class="path1" d="M7.179 12.625l8.821 5.446-6.107 5.089-8.75-5.696zM24.786 22.536v1.929l-8.75 5.232v0.018l-0.018-0.018-0.018 0.018v-0.018l-8.732-5.232v-1.929l2.625 1.714 6.107-5.071v-0.036l0.018 0.018 0.018-0.018v0.036l6.125 5.071zM9.893 2.107l6.107 5.089-8.821 5.429-6.036-4.821zM24.821 12.625l6.036 4.839-8.732 5.696-6.125-5.089zM22.125 2.107l8.732 5.696-6.036 4.821-8.821-5.429z"></path>
            </symbol>
            <symbol id="icon-instagram" viewBox="0 0 27 32">
               <path class="path1" d="M18.286 16q0-1.893-1.339-3.232t-3.232-1.339-3.232 1.339-1.339 3.232 1.339 3.232 3.232 1.339 3.232-1.339 1.339-3.232zM20.75 16q0 2.929-2.054 4.982t-4.982 2.054-4.982-2.054-2.054-4.982 2.054-4.982 4.982-2.054 4.982 2.054 2.054 4.982zM22.679 8.679q0 0.679-0.482 1.161t-1.161 0.482-1.161-0.482-0.482-1.161 0.482-1.161 1.161-0.482 1.161 0.482 0.482 1.161zM13.714 4.75q-0.125 0-1.366-0.009t-1.884 0-1.723 0.054-1.839 0.179-1.277 0.33q-0.893 0.357-1.571 1.036t-1.036 1.571q-0.196 0.518-0.33 1.277t-0.179 1.839-0.054 1.723 0 1.884 0.009 1.366-0.009 1.366 0 1.884 0.054 1.723 0.179 1.839 0.33 1.277q0.357 0.893 1.036 1.571t1.571 1.036q0.518 0.196 1.277 0.33t1.839 0.179 1.723 0.054 1.884 0 1.366-0.009 1.366 0.009 1.884 0 1.723-0.054 1.839-0.179 1.277-0.33q0.893-0.357 1.571-1.036t1.036-1.571q0.196-0.518 0.33-1.277t0.179-1.839 0.054-1.723 0-1.884-0.009-1.366 0.009-1.366 0-1.884-0.054-1.723-0.179-1.839-0.33-1.277q-0.357-0.893-1.036-1.571t-1.571-1.036q-0.518-0.196-1.277-0.33t-1.839-0.179-1.723-0.054-1.884 0-1.366 0.009zM27.429 16q0 4.089-0.089 5.661-0.179 3.714-2.214 5.75t-5.75 2.214q-1.571 0.089-5.661 0.089t-5.661-0.089q-3.714-0.179-5.75-2.214t-2.214-5.75q-0.089-1.571-0.089-5.661t0.089-5.661q0.179-3.714 2.214-5.75t5.75-2.214q1.571-0.089 5.661-0.089t5.661 0.089q3.714 0.179 5.75 2.214t2.214 5.75q0.089 1.571 0.089 5.661z"></path>
            </symbol>
            <symbol id="icon-flickr" viewBox="0 0 27 32">
               <path class="path1" d="M22.286 2.286q2.125 0 3.634 1.509t1.509 3.634v17.143q0 2.125-1.509 3.634t-3.634 1.509h-17.143q-2.125 0-3.634-1.509t-1.509-3.634v-17.143q0-2.125 1.509-3.634t3.634-1.509h17.143zM12.464 16q0-1.571-1.107-2.679t-2.679-1.107-2.679 1.107-1.107 2.679 1.107 2.679 2.679 1.107 2.679-1.107 1.107-2.679zM22.536 16q0-1.571-1.107-2.679t-2.679-1.107-2.679 1.107-1.107 2.679 1.107 2.679 2.679 1.107 2.679-1.107 1.107-2.679z"></path>
            </symbol>
            <symbol id="icon-tumblr" viewBox="0 0 19 32">
               <path class="path1" d="M16.857 23.732l1.429 4.232q-0.411 0.625-1.982 1.179t-3.161 0.571q-1.857 0.036-3.402-0.464t-2.545-1.321-1.696-1.893-0.991-2.143-0.295-2.107v-9.714h-3v-3.839q1.286-0.464 2.304-1.241t1.625-1.607 1.036-1.821 0.607-1.768 0.268-1.58q0.018-0.089 0.080-0.152t0.134-0.063h4.357v7.571h5.946v4.5h-5.964v9.25q0 0.536 0.116 1t0.402 0.938 0.884 0.741 1.455 0.25q1.393-0.036 2.393-0.518z"></path>
            </symbol>
            <symbol id="icon-dribbble" viewBox="0 0 27 32">
               <path class="path1" d="M18.286 26.786q-0.75-4.304-2.5-8.893h-0.036l-0.036 0.018q-0.286 0.107-0.768 0.295t-1.804 0.875-2.446 1.464-2.339 2.045-1.839 2.643l-0.268-0.196q3.286 2.679 7.464 2.679 2.357 0 4.571-0.929zM14.982 15.946q-0.375-0.875-0.946-1.982-5.554 1.661-12.018 1.661-0.018 0.125-0.018 0.375 0 2.214 0.786 4.223t2.214 3.598q0.893-1.589 2.205-2.973t2.545-2.223 2.33-1.446 1.777-0.857l0.661-0.232q0.071-0.018 0.232-0.063t0.232-0.080zM13.071 12.161q-2.143-3.804-4.357-6.75-2.464 1.161-4.179 3.321t-2.286 4.857q5.393 0 10.821-1.429zM25.286 17.857q-3.75-1.071-7.304-0.518 1.554 4.268 2.286 8.375 1.982-1.339 3.304-3.384t1.714-4.473zM10.911 4.625q-0.018 0-0.036 0.018 0.018-0.018 0.036-0.018zM21.446 7.214q-3.304-2.929-7.732-2.929-1.357 0-2.768 0.339 2.339 3.036 4.393 6.821 1.232-0.464 2.321-1.080t1.723-1.098 1.17-1.018 0.67-0.723zM25.429 15.875q-0.054-4.143-2.661-7.321l-0.018 0.018q-0.161 0.214-0.339 0.438t-0.777 0.795-1.268 1.080-1.786 1.161-2.348 1.152q0.446 0.946 0.786 1.696 0.036 0.107 0.116 0.313t0.134 0.295q0.643-0.089 1.33-0.125t1.313-0.036 1.232 0.027 1.143 0.071 1.009 0.098 0.857 0.116 0.652 0.107 0.446 0.080zM27.429 16q0 3.732-1.839 6.884t-4.991 4.991-6.884 1.839-6.884-1.839-4.991-4.991-1.839-6.884 1.839-6.884 4.991-4.991 6.884-1.839 6.884 1.839 4.991 4.991 1.839 6.884z"></path>
            </symbol>
            <symbol id="icon-skype" viewBox="0 0 27 32">
               <path class="path1" d="M20.946 18.982q0-0.893-0.348-1.634t-0.866-1.223-1.304-0.875-1.473-0.607-1.563-0.411l-1.857-0.429q-0.536-0.125-0.786-0.188t-0.625-0.205-0.536-0.286-0.295-0.375-0.134-0.536q0-1.375 2.571-1.375 0.768 0 1.375 0.214t0.964 0.509 0.679 0.598 0.714 0.518 0.857 0.214q0.839 0 1.348-0.571t0.509-1.375q0-0.982-1-1.777t-2.536-1.205-3.25-0.411q-1.214 0-2.357 0.277t-2.134 0.839-1.589 1.554-0.598 2.295q0 1.089 0.339 1.902t1 1.348 1.429 0.866 1.839 0.58l2.607 0.643q1.607 0.393 2 0.643 0.571 0.357 0.571 1.071 0 0.696-0.714 1.152t-1.875 0.455q-0.911 0-1.634-0.286t-1.161-0.688-0.813-0.804-0.821-0.688-0.964-0.286q-0.893 0-1.348 0.536t-0.455 1.339q0 1.643 2.179 2.813t5.196 1.17q1.304 0 2.5-0.33t2.188-0.955 1.58-1.67 0.589-2.348zM27.429 22.857q0 2.839-2.009 4.848t-4.848 2.009q-2.321 0-4.179-1.429-1.375 0.286-2.679 0.286-2.554 0-4.884-0.991t-4.018-2.679-2.679-4.018-0.991-4.884q0-1.304 0.286-2.679-1.429-1.857-1.429-4.179 0-2.839 2.009-4.848t4.848-2.009q2.321 0 4.179 1.429 1.375-0.286 2.679-0.286 2.554 0 4.884 0.991t4.018 2.679 2.679 4.018 0.991 4.884q0 1.304-0.286 2.679 1.429 1.857 1.429 4.179z"></path>
            </symbol>
            <symbol id="icon-foursquare" viewBox="0 0 23 32">
               <path class="path1" d="M17.857 7.75l0.661-3.464q0.089-0.411-0.161-0.714t-0.625-0.304h-12.714q-0.411 0-0.688 0.304t-0.277 0.661v19.661q0 0.125 0.107 0.018l5.196-6.286q0.411-0.464 0.679-0.598t0.857-0.134h4.268q0.393 0 0.661-0.259t0.321-0.527q0.429-2.321 0.661-3.411 0.071-0.375-0.205-0.714t-0.652-0.339h-5.25q-0.518 0-0.857-0.339t-0.339-0.857v-0.75q0-0.518 0.339-0.848t0.857-0.33h6.179q0.321 0 0.625-0.241t0.357-0.527zM21.911 3.786q-0.268 1.304-0.955 4.759t-1.241 6.25-0.625 3.098q-0.107 0.393-0.161 0.58t-0.25 0.58-0.438 0.589-0.688 0.375-1.036 0.179h-4.839q-0.232 0-0.393 0.179-0.143 0.161-7.607 8.821-0.393 0.446-1.045 0.509t-0.866-0.098q-0.982-0.393-0.982-1.75v-25.179q0-0.982 0.679-1.83t2.143-0.848h15.857q1.696 0 2.268 0.946t0.179 2.839zM21.911 3.786l-2.821 14.107q0.071-0.304 0.625-3.098t1.241-6.25 0.955-4.759z"></path>
            </symbol>
            <symbol id="icon-wordpress" viewBox="0 0 32 32">
               <path class="path1" d="M2.268 16q0-2.911 1.196-5.589l6.554 17.946q-3.5-1.696-5.625-5.018t-2.125-7.339zM25.268 15.304q0 0.339-0.045 0.688t-0.179 0.884-0.205 0.786-0.313 1.054-0.313 1.036l-1.357 4.571-4.964-14.75q0.821-0.054 1.571-0.143 0.339-0.036 0.464-0.33t-0.045-0.554-0.509-0.241l-3.661 0.179q-1.339-0.018-3.607-0.179-0.214-0.018-0.366 0.089t-0.205 0.268-0.027 0.33 0.161 0.295 0.348 0.143l1.429 0.143 2.143 5.857-3 9-5-14.857q0.821-0.054 1.571-0.143 0.339-0.036 0.464-0.33t-0.045-0.554-0.509-0.241l-3.661 0.179q-0.125 0-0.411-0.009t-0.464-0.009q1.875-2.857 4.902-4.527t6.563-1.67q2.625 0 5.009 0.946t4.259 2.661h-0.179q-0.982 0-1.643 0.723t-0.661 1.705q0 0.214 0.036 0.429t0.071 0.384 0.143 0.411 0.161 0.375 0.214 0.402 0.223 0.375 0.259 0.429 0.25 0.411q1.125 1.911 1.125 3.786zM16.232 17.196l4.232 11.554q0.018 0.107 0.089 0.196-2.25 0.786-4.554 0.786-2 0-3.875-0.571zM28.036 9.411q1.696 3.107 1.696 6.589 0 3.732-1.857 6.884t-4.982 4.973l4.196-12.107q1.054-3.018 1.054-4.929 0-0.75-0.107-1.411zM16 0q3.25 0 6.214 1.268t5.107 3.411 3.411 5.107 1.268 6.214-1.268 6.214-3.411 5.107-5.107 3.411-6.214 1.268-6.214-1.268-5.107-3.411-3.411-5.107-1.268-6.214 1.268-6.214 3.411-5.107 5.107-3.411 6.214-1.268zM16 31.268q3.089 0 5.92-1.214t4.875-3.259 3.259-4.875 1.214-5.92-1.214-5.92-3.259-4.875-4.875-3.259-5.92-1.214-5.92 1.214-4.875 3.259-3.259 4.875-1.214 5.92 1.214 5.92 3.259 4.875 4.875 3.259 5.92 1.214z"></path>
            </symbol>
            <symbol id="icon-stumbleupon" viewBox="0 0 34 32">
               <path class="path1" d="M18.964 12.714v-2.107q0-0.75-0.536-1.286t-1.286-0.536-1.286 0.536-0.536 1.286v10.929q0 3.125-2.25 5.339t-5.411 2.214q-3.179 0-5.42-2.241t-2.241-5.42v-4.75h5.857v4.679q0 0.768 0.536 1.295t1.286 0.527 1.286-0.527 0.536-1.295v-11.071q0-3.054 2.259-5.214t5.384-2.161q3.143 0 5.393 2.179t2.25 5.25v2.429l-3.482 1.036zM28.429 16.679h5.857v4.75q0 3.179-2.241 5.42t-5.42 2.241q-3.161 0-5.411-2.223t-2.25-5.366v-4.786l2.339 1.089 3.482-1.036v4.821q0 0.75 0.536 1.277t1.286 0.527 1.286-0.527 0.536-1.277v-4.911z"></path>
            </symbol>
            <symbol id="icon-digg" viewBox="0 0 37 32">
               <path class="path1" d="M5.857 5.036h3.643v17.554h-9.5v-12.446h5.857v-5.107zM5.857 19.661v-6.589h-2.196v6.589h2.196zM10.964 10.143v12.446h3.661v-12.446h-3.661zM10.964 5.036v3.643h3.661v-3.643h-3.661zM16.089 10.143h9.518v16.821h-9.518v-2.911h5.857v-1.464h-5.857v-12.446zM21.946 19.661v-6.589h-2.196v6.589h2.196zM27.071 10.143h9.5v16.821h-9.5v-2.911h5.839v-1.464h-5.839v-12.446zM32.911 19.661v-6.589h-2.196v6.589h2.196z"></path>
            </symbol>
            <symbol id="icon-spotify" viewBox="0 0 27 32">
               <path class="path1" d="M20.125 21.607q0-0.571-0.536-0.911-3.446-2.054-7.982-2.054-2.375 0-5.125 0.607-0.75 0.161-0.75 0.929 0 0.357 0.241 0.616t0.634 0.259q0.089 0 0.661-0.143 2.357-0.482 4.339-0.482 4.036 0 7.089 1.839 0.339 0.196 0.589 0.196 0.339 0 0.589-0.241t0.25-0.616zM21.839 17.768q0-0.714-0.625-1.089-4.232-2.518-9.786-2.518-2.732 0-5.411 0.75-0.857 0.232-0.857 1.143 0 0.446 0.313 0.759t0.759 0.313q0.125 0 0.661-0.143 2.179-0.589 4.482-0.589 4.982 0 8.714 2.214 0.429 0.232 0.679 0.232 0.446 0 0.759-0.313t0.313-0.759zM23.768 13.339q0-0.839-0.714-1.25-2.25-1.304-5.232-1.973t-6.125-0.67q-3.643 0-6.5 0.839-0.411 0.125-0.688 0.455t-0.277 0.866q0 0.554 0.366 0.929t0.92 0.375q0.196 0 0.714-0.143 2.375-0.661 5.482-0.661 2.839 0 5.527 0.607t4.527 1.696q0.375 0.214 0.714 0.214 0.518 0 0.902-0.366t0.384-0.92zM27.429 16q0 3.732-1.839 6.884t-4.991 4.991-6.884 1.839-6.884-1.839-4.991-4.991-1.839-6.884 1.839-6.884 4.991-4.991 6.884-1.839 6.884 1.839 4.991 4.991 1.839 6.884z"></path>
            </symbol>
            <symbol id="icon-soundcloud" viewBox="0 0 41 32">
               <path class="path1" d="M14 24.5l0.286-4.304-0.286-9.339q-0.018-0.179-0.134-0.304t-0.295-0.125q-0.161 0-0.286 0.125t-0.125 0.304l-0.25 9.339 0.25 4.304q0.018 0.179 0.134 0.295t0.277 0.116q0.393 0 0.429-0.411zM19.286 23.982l0.196-3.768-0.214-10.464q0-0.286-0.232-0.429-0.143-0.089-0.286-0.089t-0.286 0.089q-0.232 0.143-0.232 0.429l-0.018 0.107-0.179 10.339q0 0.018 0.196 4.214v0.018q0 0.179 0.107 0.304 0.161 0.196 0.411 0.196 0.196 0 0.357-0.161 0.161-0.125 0.161-0.357zM0.625 17.911l0.357 2.286-0.357 2.25q-0.036 0.161-0.161 0.161t-0.161-0.161l-0.304-2.25 0.304-2.286q0.036-0.161 0.161-0.161t0.161 0.161zM2.161 16.5l0.464 3.696-0.464 3.625q-0.036 0.161-0.179 0.161-0.161 0-0.161-0.179l-0.411-3.607 0.411-3.696q0-0.161 0.161-0.161 0.143 0 0.179 0.161zM3.804 15.821l0.446 4.375-0.446 4.232q0 0.196-0.196 0.196-0.179 0-0.214-0.196l-0.375-4.232 0.375-4.375q0.036-0.214 0.214-0.214 0.196 0 0.196 0.214zM5.482 15.696l0.411 4.5-0.411 4.357q-0.036 0.232-0.25 0.232-0.232 0-0.232-0.232l-0.375-4.357 0.375-4.5q0-0.232 0.232-0.232 0.214 0 0.25 0.232zM7.161 16.018l0.375 4.179-0.375 4.393q-0.036 0.286-0.286 0.286-0.107 0-0.188-0.080t-0.080-0.205l-0.357-4.393 0.357-4.179q0-0.107 0.080-0.188t0.188-0.080q0.25 0 0.286 0.268zM8.839 13.411l0.375 6.786-0.375 4.393q0 0.125-0.089 0.223t-0.214 0.098q-0.286 0-0.321-0.321l-0.321-4.393 0.321-6.786q0.036-0.321 0.321-0.321 0.125 0 0.214 0.098t0.089 0.223zM10.518 11.875l0.339 8.357-0.339 4.357q0 0.143-0.098 0.241t-0.241 0.098q-0.321 0-0.357-0.339l-0.286-4.357 0.286-8.357q0.036-0.339 0.357-0.339 0.143 0 0.241 0.098t0.098 0.241zM12.268 11.161l0.321 9.036-0.321 4.321q-0.036 0.375-0.393 0.375-0.339 0-0.375-0.375l-0.286-4.321 0.286-9.036q0-0.161 0.116-0.277t0.259-0.116q0.161 0 0.268 0.116t0.125 0.277zM19.268 24.411v0 0zM15.732 11.089l0.268 9.107-0.268 4.268q0 0.179-0.134 0.313t-0.313 0.134-0.304-0.125-0.143-0.321l-0.25-4.268 0.25-9.107q0-0.196 0.134-0.321t0.313-0.125 0.313 0.125 0.134 0.321zM17.5 11.429l0.25 8.786-0.25 4.214q0 0.196-0.143 0.339t-0.339 0.143-0.339-0.143-0.161-0.339l-0.214-4.214 0.214-8.786q0.018-0.214 0.161-0.357t0.339-0.143 0.33 0.143 0.152 0.357zM21.286 20.214l-0.25 4.125q0 0.232-0.161 0.393t-0.393 0.161-0.393-0.161-0.179-0.393l-0.107-2.036-0.107-2.089 0.214-11.357v-0.054q0.036-0.268 0.214-0.429 0.161-0.125 0.357-0.125 0.143 0 0.268 0.089 0.25 0.143 0.286 0.464zM41.143 19.875q0 2.089-1.482 3.563t-3.571 1.473h-14.036q-0.232-0.036-0.393-0.196t-0.161-0.393v-16.054q0-0.411 0.5-0.589 1.518-0.607 3.232-0.607 3.482 0 6.036 2.348t2.857 5.777q0.946-0.393 1.964-0.393 2.089 0 3.571 1.482t1.482 3.589z"></path>
            </symbol>
            <symbol id="icon-codepen" viewBox="0 0 32 32">
               <path class="path1" d="M3.857 20.875l10.768 7.179v-6.411l-5.964-3.982zM2.75 18.304l3.446-2.304-3.446-2.304v4.607zM17.375 28.054l10.768-7.179-4.804-3.214-5.964 3.982v6.411zM16 19.25l4.857-3.25-4.857-3.25-4.857 3.25zM8.661 14.339l5.964-3.982v-6.411l-10.768 7.179zM25.804 16l3.446 2.304v-4.607zM23.339 14.339l4.804-3.214-10.768-7.179v6.411zM32 11.125v9.75q0 0.732-0.607 1.143l-14.625 9.75q-0.375 0.232-0.768 0.232t-0.768-0.232l-14.625-9.75q-0.607-0.411-0.607-1.143v-9.75q0-0.732 0.607-1.143l14.625-9.75q0.375-0.232 0.768-0.232t0.768 0.232l14.625 9.75q0.607 0.411 0.607 1.143z"></path>
            </symbol>
            <symbol id="icon-twitch" viewBox="0 0 32 32">
               <path class="path1" d="M16 7.75v7.75h-2.589v-7.75h2.589zM23.107 7.75v7.75h-2.589v-7.75h2.589zM23.107 21.321l4.518-4.536v-14.196h-21.321v18.732h5.821v3.875l3.875-3.875h7.107zM30.214 0v18.089l-7.75 7.75h-5.821l-3.875 3.875h-3.875v-3.875h-7.107v-20.679l1.946-5.161h26.482z"></path>
            </symbol>
            <symbol id="icon-meanpath" viewBox="0 0 27 32">
               <path class="path1" d="M23.411 15.036v2.036q0 0.429-0.241 0.679t-0.67 0.25h-3.607q-0.429 0-0.679-0.25t-0.25-0.679v-2.036q0-0.429 0.25-0.679t0.679-0.25h3.607q0.429 0 0.67 0.25t0.241 0.679zM14.661 19.143v-4.464q0-0.946-0.58-1.527t-1.527-0.58h-2.375q-1.214 0-1.714 0.929-0.5-0.929-1.714-0.929h-2.321q-0.946 0-1.527 0.58t-0.58 1.527v4.464q0 0.393 0.375 0.393h0.982q0.393 0 0.393-0.393v-4.107q0-0.429 0.241-0.679t0.688-0.25h1.679q0.429 0 0.679 0.25t0.25 0.679v4.107q0 0.393 0.375 0.393h0.964q0.393 0 0.393-0.393v-4.107q0-0.429 0.25-0.679t0.679-0.25h1.732q0.429 0 0.67 0.25t0.241 0.679v4.107q0 0.393 0.393 0.393h0.982q0.375 0 0.375-0.393zM25.179 17.429v-2.75q0-0.946-0.589-1.527t-1.536-0.58h-4.714q-0.946 0-1.536 0.58t-0.589 1.527v7.321q0 0.375 0.393 0.375h0.982q0.375 0 0.375-0.375v-3.214q0.554 0.75 1.679 0.75h3.411q0.946 0 1.536-0.58t0.589-1.527zM27.429 6.429v19.143q0 1.714-1.214 2.929t-2.929 1.214h-19.143q-1.714 0-2.929-1.214t-1.214-2.929v-19.143q0-1.714 1.214-2.929t2.929-1.214h19.143q1.714 0 2.929 1.214t1.214 2.929z"></path>
            </symbol>
            <symbol id="icon-pinterest-p" viewBox="0 0 23 32">
               <path class="path1" d="M0 10.661q0-1.929 0.67-3.634t1.848-2.973 2.714-2.196 3.304-1.393 3.607-0.464q2.821 0 5.25 1.188t3.946 3.455 1.518 5.125q0 1.714-0.339 3.357t-1.071 3.161-1.786 2.67-2.589 1.839-3.375 0.688q-1.214 0-2.411-0.571t-1.714-1.571q-0.179 0.696-0.5 2.009t-0.42 1.696-0.366 1.268-0.464 1.268-0.571 1.116-0.821 1.384-1.107 1.545l-0.25 0.089-0.161-0.179q-0.268-2.804-0.268-3.357 0-1.643 0.384-3.688t1.188-5.134 0.929-3.625q-0.571-1.161-0.571-3.018 0-1.482 0.929-2.786t2.357-1.304q1.089 0 1.696 0.723t0.607 1.83q0 1.179-0.786 3.411t-0.786 3.339q0 1.125 0.804 1.866t1.946 0.741q0.982 0 1.821-0.446t1.402-1.214 1-1.696 0.679-1.973 0.357-1.982 0.116-1.777q0-3.089-1.955-4.813t-5.098-1.723q-3.571 0-5.964 2.313t-2.393 5.866q0 0.786 0.223 1.518t0.482 1.161 0.482 0.813 0.223 0.545q0 0.5-0.268 1.304t-0.661 0.804q-0.036 0-0.304-0.054-0.911-0.268-1.616-1t-1.089-1.688-0.58-1.929-0.196-1.902z"></path>
            </symbol>
            <symbol id="icon-get-pocket" viewBox="0 0 31 32">
               <path class="path1" d="M27.946 2.286q1.161 0 1.964 0.813t0.804 1.973v9.268q0 3.143-1.214 6t-3.259 4.911-4.893 3.259-5.973 1.205q-3.143 0-5.991-1.205t-4.902-3.259-3.268-4.911-1.214-6v-9.268q0-1.143 0.821-1.964t1.964-0.821h25.161zM15.375 21.286q0.839 0 1.464-0.589l7.214-6.929q0.661-0.625 0.661-1.518 0-0.875-0.616-1.491t-1.491-0.616q-0.839 0-1.464 0.589l-5.768 5.536-5.768-5.536q-0.625-0.589-1.446-0.589-0.875 0-1.491 0.616t-0.616 1.491q0 0.911 0.643 1.518l7.232 6.929q0.589 0.589 1.446 0.589z"></path>
            </symbol>
            <symbol id="icon-vimeo" viewBox="0 0 32 32">
               <path class="path1" d="M30.518 9.25q-0.179 4.214-5.929 11.625-5.946 7.696-10.036 7.696-2.536 0-4.286-4.696-0.786-2.857-2.357-8.607-1.286-4.679-2.804-4.679-0.321 0-2.268 1.357l-1.375-1.75q0.429-0.375 1.929-1.723t2.321-2.063q2.786-2.464 4.304-2.607 1.696-0.161 2.732 0.991t1.446 3.634q0.786 5.125 1.179 6.661 0.982 4.446 2.143 4.446 0.911 0 2.75-2.875 1.804-2.875 1.946-4.393 0.232-2.482-1.946-2.482-1.018 0-2.161 0.464 2.143-7.018 8.196-6.821 4.482 0.143 4.214 5.821z"></path>
            </symbol>
            <symbol id="icon-reddit-alien" viewBox="0 0 32 32">
               <path class="path1" d="M32 15.107q0 1.036-0.527 1.884t-1.42 1.295q0.214 0.821 0.214 1.714 0 2.768-1.902 5.125t-5.188 3.723-7.143 1.366-7.134-1.366-5.179-3.723-1.902-5.125q0-0.839 0.196-1.679-0.911-0.446-1.464-1.313t-0.554-1.902q0-1.464 1.036-2.509t2.518-1.045q1.518 0 2.589 1.125 3.893-2.714 9.196-2.893l2.071-9.304q0.054-0.232 0.268-0.375t0.464-0.089l6.589 1.446q0.321-0.661 0.964-1.063t1.411-0.402q1.107 0 1.893 0.777t0.786 1.884-0.786 1.893-1.893 0.786-1.884-0.777-0.777-1.884l-5.964-1.321-1.857 8.429q5.357 0.161 9.268 2.857 1.036-1.089 2.554-1.089 1.482 0 2.518 1.045t1.036 2.509zM7.464 18.661q0 1.107 0.777 1.893t1.884 0.786 1.893-0.786 0.786-1.893-0.786-1.884-1.893-0.777q-1.089 0-1.875 0.786t-0.786 1.875zM21.929 25q0.196-0.196 0.196-0.464t-0.196-0.464q-0.179-0.179-0.446-0.179t-0.464 0.179q-0.732 0.75-2.161 1.107t-2.857 0.357-2.857-0.357-2.161-1.107q-0.196-0.179-0.464-0.179t-0.446 0.179q-0.196 0.179-0.196 0.455t0.196 0.473q0.768 0.768 2.116 1.214t2.188 0.527 1.625 0.080 1.625-0.080 2.188-0.527 2.116-1.214zM21.875 21.339q1.107 0 1.884-0.786t0.777-1.893q0-1.089-0.786-1.875t-1.875-0.786q-1.107 0-1.893 0.777t-0.786 1.884 0.786 1.893 1.893 0.786z"></path>
            </symbol>
            <symbol id="icon-hashtag" viewBox="0 0 32 32">
               <path class="path1" d="M17.696 18.286l1.143-4.571h-4.536l-1.143 4.571h4.536zM31.411 9.286l-1 4q-0.125 0.429-0.554 0.429h-5.839l-1.143 4.571h5.554q0.268 0 0.446 0.214 0.179 0.25 0.107 0.5l-1 4q-0.089 0.429-0.554 0.429h-5.839l-1.446 5.857q-0.125 0.429-0.554 0.429h-4q-0.286 0-0.464-0.214-0.161-0.214-0.107-0.5l1.393-5.571h-4.536l-1.446 5.857q-0.125 0.429-0.554 0.429h-4.018q-0.268 0-0.446-0.214-0.161-0.214-0.107-0.5l1.393-5.571h-5.554q-0.268 0-0.446-0.214-0.161-0.214-0.107-0.5l1-4q0.125-0.429 0.554-0.429h5.839l1.143-4.571h-5.554q-0.268 0-0.446-0.214-0.179-0.25-0.107-0.5l1-4q0.089-0.429 0.554-0.429h5.839l1.446-5.857q0.125-0.429 0.571-0.429h4q0.268 0 0.446 0.214 0.161 0.214 0.107 0.5l-1.393 5.571h4.536l1.446-5.857q0.125-0.429 0.571-0.429h4q0.268 0 0.446 0.214 0.161 0.214 0.107 0.5l-1.393 5.571h5.554q0.268 0 0.446 0.214 0.161 0.214 0.107 0.5z"></path>
            </symbol>
            <symbol id="icon-chain" viewBox="0 0 30 32">
               <path class="path1" d="M26 21.714q0-0.714-0.5-1.214l-3.714-3.714q-0.5-0.5-1.214-0.5-0.75 0-1.286 0.571 0.054 0.054 0.339 0.33t0.384 0.384 0.268 0.339 0.232 0.455 0.063 0.491q0 0.714-0.5 1.214t-1.214 0.5q-0.268 0-0.491-0.063t-0.455-0.232-0.339-0.268-0.384-0.384-0.33-0.339q-0.589 0.554-0.589 1.304 0 0.714 0.5 1.214l3.679 3.696q0.482 0.482 1.214 0.482 0.714 0 1.214-0.464l2.625-2.607q0.5-0.5 0.5-1.196zM13.446 9.125q0-0.714-0.5-1.214l-3.679-3.696q-0.5-0.5-1.214-0.5-0.696 0-1.214 0.482l-2.625 2.607q-0.5 0.5-0.5 1.196 0 0.714 0.5 1.214l3.714 3.714q0.482 0.482 1.214 0.482 0.75 0 1.286-0.554-0.054-0.054-0.339-0.33t-0.384-0.384-0.268-0.339-0.232-0.455-0.063-0.491q0-0.714 0.5-1.214t1.214-0.5q0.268 0 0.491 0.063t0.455 0.232 0.339 0.268 0.384 0.384 0.33 0.339q0.589-0.554 0.589-1.304zM29.429 21.714q0 2.143-1.518 3.625l-2.625 2.607q-1.482 1.482-3.625 1.482-2.161 0-3.643-1.518l-3.679-3.696q-1.482-1.482-1.482-3.625 0-2.196 1.571-3.732l-1.571-1.571q-1.536 1.571-3.714 1.571-2.143 0-3.643-1.5l-3.714-3.714q-1.5-1.5-1.5-3.643t1.518-3.625l2.625-2.607q1.482-1.482 3.625-1.482 2.161 0 3.643 1.518l3.679 3.696q1.482 1.482 1.482 3.625 0 2.196-1.571 3.732l1.571 1.571q1.536-1.571 3.714-1.571 2.143 0 3.643 1.5l3.714 3.714q1.5 1.5 1.5 3.643z"></path>
            </symbol>
            <symbol id="icon-thumb-tack" viewBox="0 0 21 32">
               <path class="path1" d="M8.571 15.429v-8q0-0.25-0.161-0.411t-0.411-0.161-0.411 0.161-0.161 0.411v8q0 0.25 0.161 0.411t0.411 0.161 0.411-0.161 0.161-0.411zM20.571 21.714q0 0.464-0.339 0.804t-0.804 0.339h-7.661l-0.911 8.625q-0.036 0.214-0.188 0.366t-0.366 0.152h-0.018q-0.482 0-0.571-0.482l-1.357-8.661h-7.214q-0.464 0-0.804-0.339t-0.339-0.804q0-2.196 1.402-3.955t3.17-1.759v-9.143q-0.929 0-1.607-0.679t-0.679-1.607 0.679-1.607 1.607-0.679h11.429q0.929 0 1.607 0.679t0.679 1.607-0.679 1.607-1.607 0.679v9.143q1.768 0 3.17 1.759t1.402 3.955z"></path>
            </symbol>
            <symbol id="icon-arrow-left" viewBox="0 0 43 32">
               <path class="path1" d="M42.311 14.044c-0.178-0.178-0.533-0.356-0.711-0.356h-33.778l10.311-10.489c0.178-0.178 0.356-0.533 0.356-0.711 0-0.356-0.178-0.533-0.356-0.711l-1.6-1.422c-0.356-0.178-0.533-0.356-0.889-0.356s-0.533 0.178-0.711 0.356l-14.578 14.933c-0.178 0.178-0.356 0.533-0.356 0.711s0.178 0.533 0.356 0.711l14.756 14.933c0 0.178 0.356 0.356 0.533 0.356s0.533-0.178 0.711-0.356l1.6-1.6c0.178-0.178 0.356-0.533 0.356-0.711s-0.178-0.533-0.356-0.711l-10.311-10.489h33.778c0.178 0 0.533-0.178 0.711-0.356 0.356-0.178 0.533-0.356 0.533-0.711v-2.133c0-0.356-0.178-0.711-0.356-0.889z"></path>
            </symbol>
            <symbol id="icon-arrow-right" viewBox="0 0 43 32">
               <path class="path1" d="M0.356 17.956c0.178 0.178 0.533 0.356 0.711 0.356h33.778l-10.311 10.489c-0.178 0.178-0.356 0.533-0.356 0.711 0 0.356 0.178 0.533 0.356 0.711l1.6 1.6c0.178 0.178 0.533 0.356 0.711 0.356s0.533-0.178 0.711-0.356l14.756-14.933c0.178-0.356 0.356-0.711 0.356-0.889s-0.178-0.533-0.356-0.711l-14.756-14.933c0-0.178-0.356-0.356-0.533-0.356s-0.533 0.178-0.711 0.356l-1.6 1.6c-0.178 0.178-0.356 0.533-0.356 0.711s0.178 0.533 0.356 0.711l10.311 10.489h-33.778c-0.178 0-0.533 0.178-0.711 0.356-0.356 0.178-0.533 0.356-0.533 0.711v2.311c0 0.178 0.178 0.533 0.356 0.711z"></path>
            </symbol>
            <symbol id="icon-play" viewBox="0 0 22 28">
               <path d="M21.625 14.484l-20.75 11.531c-0.484 0.266-0.875 0.031-0.875-0.516v-23c0-0.547 0.391-0.781 0.875-0.516l20.75 11.531c0.484 0.266 0.484 0.703 0 0.969z"></path>
            </symbol>
            <symbol id="icon-pause" viewBox="0 0 24 28">
               <path d="M24 3v22c0 0.547-0.453 1-1 1h-8c-0.547 0-1-0.453-1-1v-22c0-0.547 0.453-1 1-1h8c0.547 0 1 0.453 1 1zM10 3v22c0 0.547-0.453 1-1 1h-8c-0.547 0-1-0.453-1-1v-22c0-0.547 0.453-1 1-1h8c0.547 0 1 0.453 1 1z"></path>
            </symbol>
         </defs>
      </svg>
      <script type="602628bac18f9de0e8cae51b-text/javascript">window.lazyLoadOptions = {
         elements_selector: "img[data-lazy-src],.rocket-lazyload,iframe[data-lazy-src]",
         data_src: "lazy-src",
         data_srcset: "lazy-srcset",
         data_sizes: "lazy-sizes",
         class_loading: "lazyloading",
         class_loaded: "lazyloaded",
         threshold: 300,
         callback_loaded: function(element) {
             if ( element.tagName === "IFRAME" && element.dataset.rocketLazyload == "fitvidscompatible" ) {
                 if (element.classList.contains("lazyloaded") ) {
                     if (typeof window.jQuery != "undefined") {
                         if (jQuery.fn.fitVids) {
                             jQuery(element).parent().fitVids();
                         }
                     }
                 }
             }
         }};
         window.addEventListener('LazyLoad::Initialized', function (e) {
         var lazyLoadInstance = e.detail.instance;
         
         if (window.MutationObserver) {
         var observer = new MutationObserver(function(mutations) {
             var image_count = 0;
             var iframe_count = 0;
             var rocketlazy_count = 0;
         
             mutations.forEach(function(mutation) {
                 for (i = 0; i < mutation.addedNodes.length; i++) {
                     if (typeof mutation.addedNodes[i].getElementsByTagName !== 'function') {
                         return;
                     }
         
                    if (typeof mutation.addedNodes[i].getElementsByClassName !== 'function') {
                         return;
                     }
         
                     images = mutation.addedNodes[i].getElementsByTagName('img');
                     is_image = mutation.addedNodes[i].tagName == "IMG";
                     iframes = mutation.addedNodes[i].getElementsByTagName('iframe');
                     is_iframe = mutation.addedNodes[i].tagName == "IFRAME";
                     rocket_lazy = mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');
         
                     image_count += images.length;
            iframe_count += iframes.length;
            rocketlazy_count += rocket_lazy.length;
                     
                     if(is_image){
                         image_count += 1;
                     }
         
                     if(is_iframe){
                         iframe_count += 1;
                     }
                 }
             } );
         
             if(image_count > 0 || iframe_count > 0 || rocketlazy_count > 0){
                 lazyLoadInstance.update();
             }
         } );
         
         var b      = document.getElementsByTagName("body")[0];
         var config = { childList: true, subtree: true };
         
         observer.observe(b, config);
         }
         }, false);
      </script><script data-no-minify="1" async src="https://technodeviser.com/wp-content/plugins/wp-rocket/assets/js/lazyload/11.0.6/lazyload.min.js" type="602628bac18f9de0e8cae51b-text/javascript"></script> <script src="https://technodeviser.com/wp-content/cache/min/1/af70606af967dc67c7907f324e51e299.js" data-minify="1" defer type="602628bac18f9de0e8cae51b-text/javascript"></script>
      <noscript>
         <link rel="stylesheet" href="https://technodeviser.com/wp-content/cache/min/1/7cb7b959f170a73f88a8c8f04c96d2c9.css" data-minify="1" />
      </noscript>
      <noscript>
         <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://technodeviser.com/wp-content/cache/busting/1/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen-3.6.6.css' type='text/css' media='only screen and (max-width: 768px)' />
      </noscript>
      <noscript>
         <link rel='stylesheet' id='avail-fonts-css'  href='https://fonts.googleapis.com/css?family=Libre+Franklin%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C800%2C800i&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
      </noscript>
      <noscript>
         <link rel='stylesheet' id='avail-ie8-css'  href='https://technodeviser.com/wp-content/themes/avail/assets/css/ie8.css?ver=1.0' type='text/css' media='all' />
      </noscript>
      <script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="602628bac18f9de0e8cae51b-|49" defer=""></script>
   </body>
</html>