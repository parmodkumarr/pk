<?php 
   require_once('Simulator.php');

   $tool = new Simulator();

   $url ='';
   $html='';
   if(isset($_POST['url'])){
      $url = $_POST['url'];
      $html = $tool->getPageContent($url);
   }
 ?>
<!DOCTYPE html>
<!-- saved from url=(0067)https://totheweb.com/learning_center/tools-search-engine-simulator/ -->
<html class="js touchevents csstransforms supports csstransforms3d csstransitions preserve3d passiveeventlisteners wf-dunbartall-n6-active wf-dunbartall-n7-active wf-dunbartall-n8-active wf-dunbartext-n5-active wf-dunbartext-n6-active wf-dunbartext-n7-active wf-dunbartext-i5-active wf-active" lang="en-US">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="pingback" href="https://totheweb.com/xmlrpc.php">
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
      <script src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/11.1.331.js.download" type="text/javascript" async=""></script>
      <script src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/11.1.331.js(1).download" type="text/javascript" async=""></script>
      <script type="text/javascript" async="" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/recaptcha__en.js.download" crossorigin="anonymous" integrity="sha384-Me/xBbBvuuItTu/oAnI7UkdtjfgtuZXbaYLJKHlUuMOlG+7MivghWo/kKOwhQ7pf"></script>
      <script src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/1036.js.download" async="" type="text/javascript"></script>
      <script async="" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/analytics.js.download"></script>
      <script type="text/javascript" async="" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/analytics.js.download">
      </script>
      <script type="text/javascript" async="" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/js"></script>
      <script src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/wzf7aig.js.download" async=""></script><script async="" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/gtm.js.download"></script>
      <script data-cfasync="false" data-pagespeed-no-defer="">//
         var gtm4wp_datalayer_name = "dataLayer";
         var dataLayer = dataLayer || [];
         //
      </script> 
      <style id="aoatfcss" media="all">@charset "UTF-8";@media screen and (max-width:600px){div.tool-form{padding:0 1.5em}}.header-input{height:70px!important;border-radius:18px 0 0 18px!important;font-size:20px!important;padding:20px!important;flex-grow:2;border-right:0;border-color:#adadad!important}@media screen and (min-width:601px){#large-button-text{display:block;font-weight:100}#small-button-text{display:none;font-weight:100}#header-input-container{display:flex;flex-direction:row;width:70%;margin-left:auto;margin-right:auto;margin-top:80px;max-width:980px}}@media screen and (max-width:670px){#large-button-text{display:none}#small-button-text{display:block}#header-input-container{display:flex;flex-direction:row;margin-left:auto;margin-right:auto;padding:1.5em}}#header-input-container input{font-family:dunbar-text,sans-serif;width:70%}#header-input-container button{font-family:dunbar-text,sans-serif;border:none!important;color:#fff!important;border-radius:18px!important;width:30%;height:70px;margin-left:-15px;background:#4c5767;font-size:20px;outline:0}.error-text{text-align:center;margin-top:15px}@media screen and (min-width:801px){#simulator-result{line-height:30px;max-width:980px;margin-left:auto;margin-right:auto}div.resultHeading{width:33%;float:left;font-weight:700;font-size:18px;color:#000;margin-top:15px}#phrases-container,div.resultData{width:66%;float:left;font-size:18px}div.resultData{margin-top:15px}div#three-word-phrases-container,div#two-word-phrases-container{width:48%;float:left}div#two-word-phrases-container{margin-right:4%}div.resultData.twoWordPhrases,div.resultHeading.twoWordPhrases{margin-right:2%}div.resultHeading.threeWordPhrases,div.resultHeading.twoWordPhrases{width:100%;color:#f16e24!important}div.resultData.threeWordPhrases,div.resultData.twoWordPhrases{width:100%}}@media screen and (max-width:800px){#simulator-result{line-height:30px;width:100%;margin-left:auto;margin-right:auto}div.resultHeading{width:100%;float:left;font-weight:700;font-size:18px;color:#000;margin-top:15px}#phrases-container,div.resultData{width:100%;float:left;font-size:18px}div.resultData.threeWordPhrases,div.resultData.twoWordPhrases{width:100%}div.resultHeading.threeWordPhrases,div.resultHeading.twoWordPhrases{width:100%;color:#f16e24!important}}.resultHeading span{float:right;width:20%;text-align:center}button::-moz-focus-inner{padding:0;border:0}@font-face{font-family:ratemypost;src:url(https://totheweb.com/wp-content/plugins/rate-my-post/public/css/fonts/ratemypost.eot?9e18pt);src:url(https://totheweb.com/wp-content/plugins/rate-my-post/public/css/fonts/ratemypost.eot?9e18pt#iefix) format('embedded-opentype'),url(https://totheweb.com/wp-content/plugins/rate-my-post/public/css/fonts/ratemypost.woff?9e18pt) format('woff'),url(https://totheweb.com/wp-content/plugins/rate-my-post/public/css/fonts/ratemypost.svg?9e18pt#ratemypost) format('svg');font-weight:400;font-style:normal;font-display:block}[class*=" rmp-icon--"]{font-family:ratemypost!important;speak:none;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container{text-align:center;margin:1rem 0}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container p{margin:0}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__icons{margin:0 0 .4rem}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__icons-list{list-style-type:none;padding:0;margin:0}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__icons-list:before{content:""}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__icons-list__icon{display:inline-block;margin:0}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__hover-text{margin:0 0 .4rem}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__submit-btn{display:none}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__not-rated,.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__results{margin:0 0 .4rem}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__not-rated--hidden{display:none;margin:0}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__msg{margin:.4rem 0}.rmp-icon--star:before{content:"\f005"}.rmp-icon--ratings{color:#ccc;font-size:1rem}.rmp-rating-widget .rmp-icon--ratings{font-size:2.5rem}.rmp-icon--full-highlight{color:#ff912c}.rmp-icon--half-highlight{background:linear-gradient(to right,#ff912c 50%,#ccc 50%);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.rmp-rating-widget .rmp-icon--half-highlight{-webkit-background-clip:text;-webkit-text-fill-color:transparent;background:linear-gradient(to right,#bf2526 50%,#ccc 50%);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.rmp-heading{margin:0 0 .4rem}.rmp-heading--title{font-size:1.625rem;font-weight:400}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-heading{margin:0 0 .4rem}.rmp-btn{background-color:#ffcc36;border:none;color:#fff;padding:.5rem;text-decoration:none;font-size:1rem;margin-bottom:.4rem}footer,header,nav{display:block}html{-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}img{max-width:100%;height:auto;vertical-align:middle;border:0;-ms-interpolation-mode:bicubic}button,input{margin:0;vertical-align:middle;font-family:dunbar-text,sans-serif}button{-webkit-appearance:button}input[type=search]{-webkit-appearance:textfield}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{-webkit-appearance:none}iframe{border:0}*,:after,:before{box-sizing:border-box}body{margin:0;line-height:1.7;font-style:normal;font-weight:500;color:#151515;background-color:#fff;overflow-x:visible}a{text-decoration:none;color:#f36d21}[tabindex="-1"]{outline:0!important}.site:after,.site:before,.x-site:after,.x-site:before{content:" ";display:table;width:0}.site:after,.x-site:after{clear:both}.x-root{display:flex}.x-root .site,.x-root .x-site{flex:1 1 auto;position:relative;width:100%;min-width:1px}.x-colophon,.x-masthead{position:relative}.x-crumbs-list{display:flex;flex-flow:row wrap;justify-content:flex-start;align-items:center;align-content:center;margin:0!important;padding:0;list-style:none}.x-crumbs-list-item{display:inherit;flex-direction:inherit;flex-wrap:nowrap;justify-content:inherit;align-items:inherit;align-content:inherit}.x-crumbs-list-item:last-child:after{content:".";display:inline;visibility:hidden;width:0;opacity:0;speak:none}.x-crumbs-link{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;white-space:inherit!important}.x-row{display:flex;position:relative;flex-flow:row nowrap;justify-content:center;align-items:stretch;width:auto;min-width:0;max-width:none;height:auto;min-height:0;max-height:none;margin:0;border:0;border-radius:0;padding:0}.x-row-inner{display:flex;flex-wrap:wrap;flex-grow:1;flex-shrink:1;flex-basis:auto;min-width:0;min-height:0}.x-col{flex-grow:0;flex-shrink:1;flex-basis:auto;display:block;position:relative;width:auto;min-width:0;max-width:100%;height:auto;min-height:0;max-height:none;margin:0;border:0;border-radius:0;padding:0}.x-icon{display:inline-flex!important;flex-flow:row nowrap!important;justify-content:center!important;align-items:center!important;width:auto;height:auto;line-height:inherit;text-align:center}.x-icon:before{display:block!important;position:static!important;top:auto!important;left:auto!important;right:auto!important;bottom:auto!important;width:inherit!important;height:inherit!important;margin:0!important;line-height:inherit!important;text-align:inherit!important}.x-anchor{overflow:hidden;display:inline-flex;flex-flow:column nowrap;justify-content:stretch;position:relative;min-width:1px}.x-anchor-content{overflow:hidden;display:flex;flex:1 0 auto;position:relative;z-index:2;border-radius:inherit;transform:translate3d(0,0,0)}.x-anchor-text{flex-shrink:1;min-width:1px;max-width:100%}.x-anchor-text-primary{position:relative;display:block;z-index:3}.x-anchor-sub-indicator{position:relative;display:block;letter-spacing:0;line-height:1;text-align:center;z-index:2}.x-anchor-sub-indicator:before{display:inherit;width:inherit;height:inherit;line-height:inherit;text-align:inherit}li:not(.menu-item-has-children)>a .x-anchor-sub-indicator{display:none;visibility:hidden;speak:none}.x-bar{position:relative;justify-content:space-between}.x-bar,.x-bar-content{display:flex}.x-bar-h{flex-direction:row}.x-bar-content{flex:1 0 auto;z-index:5}.x-bar,.x-bar-container,.x-bar-content{min-width:1px}.x-bar-space{flex-shrink:0}.x-bar-outer-spacers:after,.x-bar-outer-spacers:before{content:"";flex-grow:0;flex-shrink:0;display:block;visibility:hidden}.x-bar-h .x-bar-container{height:inherit}.x-bar-container{display:flex;position:relative;z-index:1}.x-mod-container{display:flex;flex-direction:inherit;align-items:inherit;position:relative}.x-dropdown{visibility:hidden;position:absolute;margin:0;padding:0;opacity:0;transform:translate3d(0,5%,0);z-index:9999}.menu-item-has-children{position:relative}.x-graphic{flex-shrink:0;position:relative;letter-spacing:0;line-height:1;z-index:2}.x-graphic-child{position:relative}.x-image{display:inline-block;line-height:1;vertical-align:middle}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.x-image{min-height:0}}.x-image img{display:block;max-width:100%;height:auto;vertical-align:bottom;border:0;-ms-interpolation-mode:bicubic}.x-menu,.x-menu .sub-menu{margin:0;padding:0;list-style:none}.x-menu,.x-menu li{min-width:1px}.x-menu-layered .x-anchor{display:flex;opacity:0;transform:translate(25px,0)}.x-menu-layered li:after,.x-menu-layered li:before{content:"";display:table}.x-menu-layered li:after{clear:both}.x-menu-layered{overflow:hidden;position:relative}.x-menu-layered .menu-item-has-children{position:static}.x-menu-layered ul{position:absolute;top:0;left:0;right:0}.x-current-layer>li>.x-anchor{opacity:1;transform:translate(0,0)}.x-off-canvas{overflow-x:hidden;overflow-y:auto;visibility:hidden;position:fixed;top:0;left:0;right:0;bottom:0;z-index:99999998}.x-off-canvas-bg{display:block;position:absolute;top:0;left:0;right:0;bottom:0;opacity:0;z-index:1;transform:translate3d(0,0,0)}.x-off-canvas-close{display:block;position:absolute;top:0;margin:0;border:0;padding:0;line-height:1;text-align:center;background-color:transparent;opacity:0;transform:scale(0);z-index:3}.x-off-canvas-close span{display:block}.x-off-canvas-content{position:absolute;top:0;bottom:0;width:100%;z-index:2}.x-off-canvas-close-right{right:0}.x-off-canvas-content-right{right:0;transform:translate3d(115%,0,0)}.x-search{display:flex;align-items:center;margin:0;border:0;padding:0}.x-search-btn{display:block;flex-shrink:0;margin:0;border:0;padding:0;line-height:1;background-color:transparent}.x-search-btn svg{display:block;width:1em;height:1em;margin:0 auto;line-height:inherit;stroke:currentColor}.x-search-btn-submit{order:1}.x-search-btn-clear{order:3;visibility:hidden}.x-search-input{flex-grow:1;order:2;width:100%;min-width:1px;height:auto!important;border:0!important;padding:0!important;background-color:transparent!important;box-shadow:none!important;-webkit-appearance:none;-moz-appearance:none;appearance:none}.x-search-input::-ms-clear{display:none}.x-search-input::-webkit-input-placeholder{color:currentColor;opacity:1}.x-search-input::-moz-placeholder{color:currentColor;opacity:1}.x-search-input:-ms-input-placeholder{color:currentColor;opacity:1}[data-x-stem]{top:auto;left:auto;right:auto;bottom:auto}.x-text{min-width:1px}.x-text-headline{position:relative}.x-text-content{display:-webkit-flex;display:flex}.x-text-content-text{-webkit-flex-grow:1;flex-grow:1;min-width:1px;max-width:100%}.x-text-content-text,.x-text-content-text-primary,.x-text-content-text-subheadline{display:block}.x-text-content-text-primary,.x-text-content-text-subheadline{margin-top:0;margin-bottom:0}.x-toggle{display:block;position:relative;transform:translate3d(0,0,0);speak:none}.x-toggle>span{display:block;position:absolute;top:0;left:0;width:100%;height:100%;margin:0 auto;border-radius:inherit;background-color:currentColor}.x-toggle-burger{height:1em}[data-x-toggle-anim]{animation:.5s cubic-bezier(.86,0,.07,1) infinite alternate forwards paused}form,p{margin:0 0 1.313em}h1,h2{margin:1.25em 0 .2em;text-rendering:optimizelegibility;font-family:dunbar-tall,sans-serif;font-style:normal;font-weight:600;letter-spacing:0;color:#242424}ol,ul{padding:0;margin:0 0 1.313em 1.655em}ul ul{margin-bottom:0}hr{height:0;margin:1.313em 0;border:0;border-top:1px solid #f2f2f2}button,input,label{font-size:100%;line-height:1.7}label{display:block;margin-bottom:2px}input::-webkit-input-placeholder{color:#c5c5c5}input::-moz-placeholder{color:#c5c5c5}input:-ms-input-placeholder{color:#c5c5c5}input[type=search],input[type=text]{display:inline-block;height:2.65em;margin-bottom:9px;border:1px solid #ddd;padding:0 .65em;font-size:13px;line-height:normal;color:#555;background-color:#fff;border-radius:4px;box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}input{width:auto}.x-container{margin:0 auto}.x-section{display:block;position:relative;margin:0 0 1.313em;padding:45px 0}.x-section:after,.x-section:before{content:" ";display:table;width:0}.x-section:after{clear:both}.widget{text-shadow:0 1px 0 rgba(255,255,255,.95)}.widget a:after,.widget a:before{line-height:1;text-decoration:inherit;opacity:.35;font-family:FontAwesome!important;font-style:normal!important;font-weight:400!important;text-decoration:inherit;text-rendering:auto;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.widget ul:last-child{margin-bottom:0}.widget ul{overflow:hidden;margin-left:0;border:1px solid rgba(0,0,0,.1);list-style:none;border-radius:6px;box-shadow:0 1px 1px rgba(255,255,255,.95)}.widget ul li{border-bottom:1px solid rgba(0,0,0,.1);padding:.65em .85em;line-height:1.5;box-shadow:0 1px 1px rgba(255,255,255,.95)}.widget ul li a{border-bottom:1px dotted;color:#151515}.widget ul li:last-child{border-bottom:0}.visually-hidden{overflow:hidden;position:absolute;width:1px;height:1px;margin:-1px;border:0;padding:0;clip:rect(0 0 0 0)}@media (min-width:1200px){.x-hide-xl{display:none!important}}@media (min-width:979px)and (max-width:1199.98px){.x-hide-lg{display:none!important}}@media (min-width:767px)and (max-width:978.98px){.x-hide-md{display:none!important}}@media (min-width:480px)and (max-width:766.98px){.x-hide-sm{display:none!important}}@media (max-width:479.98px){.x-hide-xs{display:none!important}}.rmp-widgets-container{margin-bottom:80px!important;margin-top:8em!important}.rmp-rating-widget .rmp-icon--full-highlight{color:#bf2526}#ubermenu_navigation_widget-2{min-width:400px}#ubermenu-nav-main-1882-primary{text-align:right}#menu-item-6983 a span.ubermenu-target-title{margin-bottom:1em}#popmake-6223{background-image:url(https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/09/popup-background.jpg);background-position:center center;background-size:cover}.x-crumbs-list .x-crumbs-list-item:first-child .x-crumbs-link{background-image:url(https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/home.svg);background-repeat:no-repeat;width:1.25em;height:1.25em}.x-anchor-sub-indicator{background-image:url(https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/angle-down.svg);background-repeat:no-repeat;width:.75em;height:.75em}.ninja-forms-noscript-message{background:#f1f1f1;border:4px dashed #ccc;color:#333;display:block;font-size:20px;margin:20px 0;padding:40px;text-align:center}.nf-loading-spinner{width:40px;height:40px;margin:100px auto;background-color:hsla(0,0%,82%,.5);border-radius:100%;animation:1s ease-in-out infinite nf-scaleout}@keyframes nf-scaleout{0%{transform:scale(0)}to{transform:scale(1);opacity:0}}.pum-container,.pum-content,.pum-content+.pum-close,.pum-overlay{background:0 0;border:none;bottom:auto;clear:none;float:none;font-family:inherit;font-size:medium;font-style:normal;font-weight:400;height:auto;left:auto;letter-spacing:normal;line-height:normal;max-height:none;max-width:none;min-height:0;min-width:0;overflow:visible;position:static;right:auto;text-align:left;text-decoration:none;text-indent:0;text-transform:none;top:auto;visibility:visible;white-space:normal;width:auto;z-index:auto}.pum-content{position:relative;z-index:1}.pum-overlay{position:fixed;height:100%;width:100%;top:0;left:0;right:0;bottom:0;z-index:1999999999;overflow:initial;display:none}.pum-overlay,.pum-overlay *,.pum-overlay :after,.pum-overlay :before,.pum-overlay:after,.pum-overlay:before{box-sizing:border-box}.pum-container{top:100px;position:absolute;margin-bottom:3em;z-index:1999999999}.pum-container.pum-responsive{left:50%;margin-left:-47.5%;width:95%;height:auto;overflow:visible}@media only screen and (min-width:1024px){.pum-container.pum-responsive.pum-responsive-tiny{margin-left:-15%;width:30%}.pum-container.pum-responsive.pum-position-fixed{position:fixed}}@media only screen and (max-width:1024px){.pum-container.pum-responsive.pum-position-fixed{position:absolute}}.pum-container .pum-content>:last-child{margin-bottom:0}.pum-container .pum-content>:first-child{margin-top:0}.pum-container .pum-content+.pum-close{text-decoration:none;text-align:center;line-height:1;position:absolute;min-width:1em;z-index:2;background-color:transparent}.ubermenu,.ubermenu .ubermenu-column,.ubermenu .ubermenu-icon,.ubermenu .ubermenu-image,.ubermenu .ubermenu-item,.ubermenu .ubermenu-nav,.ubermenu .ubermenu-submenu,.ubermenu .ubermenu-target,.ubermenu-responsive-toggle{margin:0;padding:0;left:auto;right:auto;top:auto;bottom:auto;text-indent:0;clip:auto;position:static;background:0 0;text-transform:none;overflow:visible;z-index:10;-webkit-box-shadow:none;-moz-box-shadow:none;-o-box-shadow:none;box-shadow:none;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;-ms-box-sizing:border-box;-o-box-sizing:border-box;box-sizing:border-box;vertical-align:top;line-height:1.3em;border:none;border-radius:0}.ubermenu,.ubermenu .ubermenu-column,.ubermenu .ubermenu-item,.ubermenu .ubermenu-nav,.ubermenu .ubermenu-submenu,.ubermenu .ubermenu-target,.ubermenu-responsive-toggle{height:auto;width:auto;max-height:none;min-height:0}.ubermenu .ubermenu-image,.ubermenu .ubermenu-submenu-drop{-webkit-backface-visibility:hidden;-moz-backface-visibility:hidden;backface-visibility:hidden;-moz-transform:translateZ(0);-webkit-transform:translateZ(0)}.ubermenu{display:block;line-height:1.3em;text-align:left;background:0 0}.ubermenu,.ubermenu-nav{overflow:visible!important;z-index:100}.ubermenu-nav{text-align:inherit}.ubermenu-nav,.ubermenu-submenu{display:block;margin:0;padding:0;list-style:none}.ubermenu-responsive-toggle{display:none;text-decoration:none;max-width:100%}.ubermenu-responsive-toggle .ubermenu-icon-essential{width:1.3em;text-align:center;margin-right:.6em;font-size:1.3em;vertical-align:text-bottom}.ubermenu-responsive-toggle-content-align-left{text-align:left}button.ubermenu-responsive-toggle-align-full{width:100%}.ubermenu .ubermenu-mobile-footer{display:none}.ubermenu-bar-align-full{clear:both}.ubermenu .ubermenu-item{text-align:left;display:inline-block;vertical-align:top}.ubermenu .ubermenu-item-level-0{vertical-align:bottom;-moz-backface-visibility:visible;backface-visibility:visible}.ubermenu .ubermenu-item.ubermenu-item-level-0{float:none}body:not(.rtl) .ubermenu.ubermenu-horizontal .ubermenu-item-level-0:first-child>.ubermenu-target{border-left:none}.ubermenu .ubermenu-submenu-type-stack>.ubermenu-item-normal>.ubermenu-target,.ubermenu .ubermenu-target,.ubermenu-responsive-toggle{padding:15px 20px}.ubermenu .ubermenu-submenu .ubermenu-submenu-type-stack{width:auto}.ubermenu .ubermenu-submenu-type-stack{padding-top:10px;padding-bottom:10px}.ubermenu .ubermenu-item-type-column>.ubermenu-submenu-type-stack{padding-top:0}.ubermenu .ubermenu-item-type-column>.ubermenu-submenu-type-stack>.ubermenu-item-normal:first-child{margin-top:10px}.ubermenu .ubermenu-submenu-type-stack>.ubermenu-item-normal>.ubermenu-target{padding-top:5px;padding-bottom:5px}.ubermenu .ubermenu-target{display:block;text-decoration:none;position:relative}.ubermenu .ubermenu-target-with-image{overflow:hidden}.ubermenu .ubermenu-submenu .ubermenu-target{backface-visibility:hidden}.ubermenu-sub-indicators .ubermenu-has-submenu-drop>.ubermenu-target>.ubermenu-sub-indicator{position:absolute;right:10px;top:50%;margin-top:-6px}.ubermenu-sub-indicators .ubermenu-has-submenu-drop>.ubermenu-target>.ubermenu-sub-indicator>.ubermenu-icon-essential{display:flex;font-size:9px;margin-top:1px}.ubermenu-sub-indicators .ubermenu-has-submenu-drop>.ubermenu-target{padding-right:25px}.ubermenu .ubermenu-target-text{display:inline-block;vertical-align:baseline;font-family:inherit;font-weight:inherit;color:inherit}.ubermenu .ubermenu-target-description{font-size:80%;font-weight:400;clear:both;display:block}.ubermenu .ubermenu-target-with-image>.ubermenu-target-text{display:block;clear:none}.ubermenu .ubermenu-image{display:block;max-width:100%;opacity:1}.ubermenu .ubermenu-image:not(.ubermenu-image-lazyload){height:auto}.ubermenu .ubermenu-item-layout-image_above>.ubermenu-image{margin-bottom:10px}.ubermenu .ubermenu-icon{width:1.3em;text-align:center;line-height:1em;vertical-align:baseline}.ubermenu .ubermenu-icon-essential,.ubermenu-icon-essential{width:1em;height:1em;display:inline-flex;align-items:center}.ubermenu .ubermenu-icon-essential svg,.ubermenu-icon-essential svg{width:100%;height:100%;fill:currentColor}.ubermenu .ubermenu-column{max-width:100%}.ubermenu .ubermenu-item .ubermenu-submenu-drop{position:absolute;z-index:500;top:-10000px;height:0;max-height:0;visibility:hidden;overflow:hidden;box-shadow:0 0 20px rgba(0,0,0,.15)}.ubermenu .ubermenu-item:not(.ubermenu-active) .ubermenu-submenu-drop{min-height:0!important}.ubermenu .ubermenu-item-level-0>.ubermenu-submenu-drop{clip:rect(0,5000px,5000px,-5000px)}.ubermenu .ubermenu-submenu-drop.ubermenu-submenu-align-full_width{left:0;width:100%}.ubermenu .ubermenu-submenu-type-stack>.ubermenu-item{display:block}.ubermenu .ubermenu-submenu-type-stack>.ubermenu-item.ubermenu-column-auto{width:100%;display:block;float:none;min-width:0}.ubermenu-transition-slide .ubermenu-item .ubermenu-submenu-drop{max-height:0;top:auto}.ubermenu .ubermenu-submenu .ubermenu-column{display:block;float:left;width:auto}.ubermenu .ubermenu-submenu .ubermenu-column-auto{min-width:100px;width:auto}.ubermenu .ubermenu-nav .ubermenu-column-1-4{width:25%}.ubermenu .ubermenu-nav .ubermenu-column-1-8{width:12.5%}.widget.ubermenu_navigation_widget-class{overflow:visible}.ubermenu-target-divider{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:0;padding:0;border:0}.ubermenu .ubermenu-column:after,.ubermenu .ubermenu-image:after,.ubermenu .ubermenu-submenu:after,.ubermenu:after{content:"";display:table;clear:both}.ubermenu-submenu-drop{background:#fff}svg.ubermenu-essential-icons{display:none}@media screen and (min-width:960px){.ubermenu-responsive-default.ubermenu{display:block!important}}@media screen and (max-width:959px){.ubermenu-responsive-toggle{display:block}.ubermenu-responsive-default.ubermenu-responsive{width:100%;max-height:600px;visibility:visible;overflow:visible}.ubermenu-responsive-default.ubermenu-responsive.ubermenu{margin:0}.ubermenu-responsive-default.ubermenu-responsive.ubermenu .ubermenu-nav{display:block}.ubermenu-responsive-default.ubermenu-responsive.ubermenu-responsive-collapse{max-height:none;max-height:0;overflow:hidden!important;visibility:hidden}.ubermenu-responsive-default.ubermenu-responsive.ubermenu-responsive-collapse:not(.ubermenu-in-transition){border-top-width:0;border-bottom-width:0}.ubermenu-responsive-default.ubermenu-responsive.ubermenu-responsive-collapse .ubermenu-item .ubermenu-submenu{display:none}.ubermenu-responsive-default.ubermenu-responsive .ubermenu-item-level-0{width:50%}.ubermenu-responsive-default.ubermenu-responsive .ubermenu-item.ubermenu-item-level-0>.ubermenu-target{border:none;box-shadow:none}.ubermenu-responsive-default.ubermenu-responsive .ubermenu-nav .ubermenu-item .ubermenu-submenu.ubermenu-submenu-drop{width:100%;min-width:100%;max-width:100%;top:auto;left:0!important}.ubermenu-responsive-default.ubermenu-responsive .ubermenu-submenu.ubermenu-submenu-type-mega>.ubermenu-item.ubermenu-column{min-height:0;border-left:none;float:left;display:block}.ubermenu-responsive-default.ubermenu.ubermenu-responsive .ubermenu-column,.ubermenu-responsive-default.ubermenu.ubermenu-responsive .ubermenu-column-auto{min-width:50%}.ubermenu-responsive-default.ubermenu.ubermenu-responsive .ubermenu-column:nth-of-type(2n+1){clear:both}.ubermenu-responsive-default.ubermenu-responsive .ubermenu-submenu-type-stack .ubermenu-column,.ubermenu-responsive-default.ubermenu-responsive .ubermenu-submenu-type-stack .ubermenu-column-auto{width:100%;max-width:100%}.ubermenu-responsive-default.ubermenu-responsive .ubermenu-item.ubermenu-hide-mobile{display:none!important}.ubermenu-responsive-default.ubermenu.ubermenu-mobile-modal{position:fixed;z-index:9999999;opacity:1;top:0;left:0;width:100vw;max-width:100%;max-width:100vw;height:100%;height:calc(100vh - calc(100vh - 100%));height:-webkit-fill-available;max-height:calc(100vh - calc(100vh - 100%));max-height:-webkit-fill-available;border:none;box-sizing:border-box;display:flex;flex-direction:column;justify-content:flex-start;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain;transform:scale(1)}.ubermenu-responsive-default.ubermenu.ubermenu-mobile-modal.ubermenu-responsive-collapse{overflow:hidden!important;opacity:0;transform:scale(.9);visibility:hidden}.ubermenu-responsive-default.ubermenu.ubermenu-mobile-modal .ubermenu-nav{flex:1;overflow-y:auto!important;overscroll-behavior:contain}.ubermenu-responsive-default.ubermenu.ubermenu-mobile-modal .ubermenu-mobile-close-button{border:none;background:0 0;border-radius:0;padding:1em;color:inherit;display:inline-block;text-align:center;font-size:14px}.ubermenu-responsive-default.ubermenu.ubermenu-mobile-modal .ubermenu-mobile-footer .ubermenu-mobile-close-button{width:100%;display:flex;align-items:center;justify-content:center}.ubermenu-responsive-default.ubermenu.ubermenu-mobile-modal .ubermenu-mobile-footer .ubermenu-mobile-close-button .ubermenu-icon-essential{margin-right:.2em}.ubermenu-responsive-default.ubermenu .ubermenu-mobile-footer{display:block;text-align:center;color:inherit}}@media screen and (max-width:480px){.ubermenu-responsive-default.ubermenu.ubermenu-responsive .ubermenu-item-level-0{width:100%}.ubermenu-responsive-default.ubermenu.ubermenu-responsive .ubermenu-column,.ubermenu-responsive-default.ubermenu.ubermenu-responsive .ubermenu-column-auto{min-width:100%}}.ubermenu-skin-vanilla{font-size:12px;color:#888;border:none;background:0 0}.ubermenu-skin-vanilla .ubermenu-target{color:#999}.ubermenu-skin-vanilla .ubermenu-target-description{color:#aaa}.ubermenu-skin-vanilla.ubermenu-responsive-toggle{background:#f9f9f9;color:#888;font-size:12px;text-transform:none;font-weight:400}.ubermenu-skin-vanilla .ubermenu-item-level-0.ubermenu-current-menu-ancestor>.ubermenu-target{color:#444;background:0 0}.ubermenu-skin-vanilla .ubermenu-item-level-0>.ubermenu-target{font-weight:400;color:#888;text-transform:none;border-left:none}body:not(.rtl) .ubermenu-skin-vanilla.ubermenu-horizontal .ubermenu-item-level-0:first-child>.ubermenu-target{box-shadow:none}.ubermenu-skin-vanilla .ubermenu-submenu.ubermenu-submenu-drop{background:#f9f9f9;border:1px solid #e0e0e0}.ubermenu-skin-vanilla.ubermenu-horizontal .ubermenu-item-level-0>.ubermenu-submenu-drop{border-top:1px solid #e0e0e0}.ubermenu-skin-vanilla .ubermenu-submenu,.ubermenu-skin-vanilla .ubermenu-submenu .ubermenu-target{color:#999}.ubermenu-skin-vanilla .ubermenu-submenu .ubermenu-target>.ubermenu-target-description{color:#aaa}.ubermenu-skin-vanilla .ubermenu-submenu .ubermenu-item-header>.ubermenu-target{font-weight:700;color:#777}.ubermenu-skin-vanilla .ubermenu-submenu .ubermenu-current-menu-item>.ubermenu-target{color:#444;background:0 0}.ubermenu-skin-vanilla .ubermenu-submenu-drop{border-bottom-width:3px}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__icons-list__icon{margin-left:5px;margin-right:5px}.pum-theme-6213,.pum-theme-lightbox{background-color:rgba(0,0,0,.6)}.pum-theme-6213 .pum-container,.pum-theme-lightbox .pum-container{padding:25px;border-radius:5px;border:0 solid #000;box-shadow:0 0 30px 0 rgba(2,2,2,1);background-color:rgba(255,115,0,1)}.pum-theme-6213 .pum-content,.pum-theme-lightbox .pum-content{color:#000;font-family:inherit;font-weight:100}.pum-theme-6213 .pum-content+.pum-close,.pum-theme-lightbox .pum-content+.pum-close{position:absolute;height:26px;width:26px;left:auto;right:-13px;bottom:auto;top:-13px;padding:0;color:#fff;font-family:Arial;font-weight:100;font-size:24px;line-height:24px;border:2px solid #fff;border-radius:26px;box-shadow:0 0 15px 1px rgba(2,2,2,.75);text-shadow:0 0 0 rgba(0,0,0,.23);background-color:rgba(0,0,0,1)}#pum-6223{z-index:1999999999}.ubermenu-main{background:#fff;border:1px solid #fff}.ubermenu-main .ubermenu-item-level-0>.ubermenu-target{font-size:12px;text-transform:uppercase;color:#2c2c2c}.ubermenu-main .ubermenu-nav .ubermenu-item.ubermenu-item-level-0>.ubermenu-target{font-weight:400}.ubermenu-main .ubermenu-item-level-0.ubermenu-current-menu-ancestor>.ubermenu-target{color:#f36d21}.ubermenu.ubermenu-main .ubermenu-item-level-0>.ubermenu-target{background:#fff}.ubermenu-main .ubermenu-submenu.ubermenu-submenu-drop{background-color:#f7f7f7;border:1px solid #ddd}.ubermenu-main .ubermenu-item-level-0>.ubermenu-submenu-drop{box-shadow:none}.ubermenu-main .ubermenu-item-normal>.ubermenu-target,.ubermenu-main .ubermenu-submenu .ubermenu-target,.ubermenu-main .ubermenu-submenu.ubermenu-submenu-type-stack>.ubermenu-item-normal>.ubermenu-target{padding:10px 30px}.ubermenu-main .ubermenu-submenu .ubermenu-item-header>.ubermenu-target{font-size:14px;color:#2c2c2c}.ubermenu-main .ubermenu-nav .ubermenu-submenu .ubermenu-item-header>.ubermenu-target{font-weight:700}.ubermenu-main .ubermenu-submenu-type-stack{padding-top:0}.ubermenu-main .ubermenu-item-normal>.ubermenu-target{color:#424242;font-size:12px;font-weight:600}.ubermenu-main .ubermenu-item-normal.ubermenu-current-menu-item>.ubermenu-target{color:#f36d21}.ubermenu-main .ubermenu-target>.ubermenu-target-description{font-size:12px}.ubermenu-main .ubermenu-submenu .ubermenu-target>.ubermenu-target-description,.ubermenu-main .ubermenu-target>.ubermenu-target-description{color:#a1a8a8}.ubermenu .ubermenu-item.ubermenu-item-6955>.ubermenu-target{background:#fff;color:#fdb61e;padding:30px}.ubermenu .ubermenu-item.ubermenu-item-7006>.ubermenu-target{background:#fff;color:#2a87d3;padding:30px}.ubermenu .ubermenu-item.ubermenu-item-6985>.ubermenu-target{background:#fff;color:#db9e07;padding:30px}.ubermenu .ubermenu-item.ubermenu-item-6956,.ubermenu .ubermenu-item.ubermenu-item-6958,.ubermenu .ubermenu-item.ubermenu-item-6965,.ubermenu .ubermenu-item.ubermenu-item-6984,.ubermenu .ubermenu-item.ubermenu-item-6989,.ubermenu .ubermenu-item.ubermenu-item-7000,.ubermenu .ubermenu-item.ubermenu-item-7001,.ubermenu .ubermenu-item.ubermenu-item-7008{background:#f7f7f7}.ubermenu .ubermenu-item.ubermenu-item-6980.ubermenu-current-menu-item>.ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6980>.ubermenu-target{color:#bf2526}.ubermenu .ubermenu-item.ubermenu-item-6971>.ubermenu-target{background:#fff;color:#bf2526;padding:30px}.ubermenu .ubermenu-item.ubermenu-item-6974{background:#f7f7f7}.ubermenu .ubermenu-item.ubermenu-item-7281>.ubermenu-target{padding:20px 0 20px 30px}.ubermenu .ubermenu-item.ubermenu-item-6975>.ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6976>.ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6977>.ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6978>.ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6979>.ubermenu-target{color:#bf2526}.ubermenu .ubermenu-item.ubermenu-item-7013>.ubermenu-target{color:#484848}.ubermenu .ubermenu-item.ubermenu-item-6983>.ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7542>.ubermenu-target{color:#ff6f00}.ubermenu .ubermenu-item.ubermenu-item-7542>.ubermenu-target{padding:30px}html{overflow-x:hidden;font-size:14px}@media (min-width:500px){html{font-size:calc(14px + (16 - 14) * ((100vw - 500px)/ (1000 - 500)))}}@media (min-width:1000px){html{font-size:16px}}.x-container.width{width:88%}.x-container.max{max-width:1200px}body,button,input{font-family:dunbar-text,sans-serif}.e7308-1.x-bar,.e7308-6.x-bar{height:6em;font-size:16px;background-color:#fff;box-shadow:0 .15em .5em 0 rgba(0,0,0,.05);z-index:9999}.e7308-11.x-bar{height:4em;font-size:16px;background-color:#fff;z-index:9998}.e7308-14.x-bar{height:6em;font-size:16px;background-color:#fff;box-shadow:0 .15em .5em 0 rgba(0,0,0,.05);z-index:9999}.e7308-19.x-bar{height:3em;font-size:16px;background-color:#fff;z-index:9998}.e7308-22.x-bar{height:5em;font-size:16px;background-color:#fff;box-shadow:0 .15em .5em 0 rgba(0,0,0,.05);z-index:9999}.e7308-26.x-bar{height:4em;font-size:16px;background-color:#fff;z-index:9999}.e7308-29.x-bar{height:3em;font-size:16px;background-color:#fff;z-index:9998}.e7308-1.x-bar-content,.e7308-6.x-bar-content{flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:6em}.e7308-11.x-bar-content{flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:4em}.e7308-14.x-bar-content{flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 100%;height:6em}.e7308-19.x-bar-content{flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:3em}.e7308-22.x-bar-content{flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 100%;height:5em}.e7308-26.x-bar-content{flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 100%;height:4em}.e7308-29.x-bar-content{flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:3em}.e7308-1.x-bar-outer-spacers:after,.e7308-1.x-bar-outer-spacers:before,.e7308-11.x-bar-outer-spacers:after,.e7308-11.x-bar-outer-spacers:before,.e7308-6.x-bar-outer-spacers:after,.e7308-6.x-bar-outer-spacers:before{flex-basis:4em;width:4em!important;height:4em}.e7308-14.x-bar-outer-spacers:after,.e7308-14.x-bar-outer-spacers:before,.e7308-19.x-bar-outer-spacers:after,.e7308-19.x-bar-outer-spacers:before,.e7308-22.x-bar-outer-spacers:after,.e7308-22.x-bar-outer-spacers:before,.e7308-26.x-bar-outer-spacers:after,.e7308-26.x-bar-outer-spacers:before,.e7308-29.x-bar-outer-spacers:after,.e7308-29.x-bar-outer-spacers:before{flex-basis:2em;width:2em!important;height:2em}.e7308-1.x-bar-space,.e7308-14.x-bar-space,.e7308-6.x-bar-space{font-size:16px;height:6em}.e7308-22.x-bar-space{font-size:16px;height:5em}.e7308-26.x-bar-space{font-size:16px;height:4em}.e7308-13.x-crumbs,.e7308-21.x-crumbs,.e7308-31.x-crumbs{font-family:dunbar-text,sans-serif;font-size:.7em;font-weight:500;line-height:1.4}.e7308-13 .x-crumbs-list,.e7308-21 .x-crumbs-list,.e7308-31 .x-crumbs-list{justify-content:flex-start;margin-left:-8px!important}.e7308-13 .x-crumbs-list-item,.e7308-21 .x-crumbs-list-item,.e7308-31 .x-crumbs-list-item{margin-left:8px}.e7308-13 .x-crumbs-link{font-style:normal;line-height:1.3;color:#707070}.e7308-21 .x-crumbs-link,.e7308-31 .x-crumbs-link{font-style:normal;line-height:1.3;text-transform:uppercase;color:#707070}.e7308-13 .x-crumbs-delimiter,.e7308-21 .x-crumbs-delimiter,.e7308-31 .x-crumbs-delimiter{margin-left:8px;color:rgba(0,0,0,.5)}.e7308-12.x-bar-container,.e7308-15.x-bar-container,.e7308-2.x-bar-container,.e7308-20.x-bar-container,.e7308-23.x-bar-container,.e7308-7.x-bar-container{flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%}.e7308-27.x-bar-container{flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 auto}.e7308-30.x-bar-container{flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%}.e7308-3.x-image,.e7308-8.x-image{width:180px;padding:0 30px 0 0}.e7308-16.x-image,.e7308-24.x-image{width:160px;padding:0 30px 0 0}.e7308-16.x-image img,.e7308-24.x-image img,.e7308-3.x-image img,.e7308-8.x-image img{width:100%}.e7308-18.x-anchor-toggle,.e7308-25.x-anchor-toggle{width:3em;height:3em;font-size:1em;background-color:rgba(255,255,255,1)}.e7308-18.x-anchor-toggle .x-anchor-content,.e7308-25.x-anchor-toggle .x-anchor-content{flex-direction:row;justify-content:center;align-items:center}.e7308-18.x-anchor-toggle .x-graphic,.e7308-25.x-anchor-toggle .x-graphic{margin:5px}.e7308-18.x-anchor-toggle .x-toggle,.e7308-25.x-anchor-toggle .x-toggle{color:rgba(0,0,0,1)}.e7308-18.x-anchor-toggle .x-toggle-burger{width:12em;margin:3.25em 0;font-size:.2em}.e7308-25.x-anchor-toggle .x-toggle-burger{width:12em;margin:3.25em 0;font-size:.15em}.e7308-18.x-anchor-toggle .x-toggle-burger-bun-t,.e7308-25.x-anchor-toggle .x-toggle-burger-bun-t{transform:translate3d(0,-3.25em,0)}.e7308-18.x-anchor-toggle .x-toggle-burger-bun-b,.e7308-25.x-anchor-toggle .x-toggle-burger-bun-b{transform:translate3d(0,3.25em,0)}.e7308-18.x-off-canvas,.e7308-25.x-off-canvas{font-size:16px}.e7308-18.x-off-canvas .x-off-canvas-bg,.e7308-25.x-off-canvas .x-off-canvas-bg{background-color:rgba(0,0,0,.75)}.e7308-18.x-off-canvas .x-off-canvas-close{width:calc(1em * 2);height:calc(1em * 2);font-size:2em;color:rgba(0,0,0,.5)}.e7308-25.x-off-canvas .x-off-canvas-close{width:calc(1em * 2);height:calc(1em * 2);font-size:1.5em;color:rgba(0,0,0,.5)}.e7308-18.x-off-canvas .x-off-canvas-content{max-width:24em;padding:calc(2em * 2);background-color:#fff;box-shadow:0 0 2em 0 rgba(0,0,0,.25)}.e7308-25.x-off-canvas .x-off-canvas-content{max-width:24em;padding:calc(1.5em * 2);background-color:#fff;box-shadow:0 0 2em 0 rgba(0,0,0,.25)}.e7308-18.x-menu{font-size:.9em}.e7308-18.x-menu .x-anchor,.e7308-25.x-menu,.e7308-25.x-menu .x-anchor{font-size:1em}.e7308-18.x-menu .x-anchor .x-anchor-content,.e7308-25.x-menu .x-anchor .x-anchor-content{flex-direction:row;justify-content:center;align-items:center;padding:.5em}.e7308-18.x-menu .x-anchor .x-anchor-text,.e7308-25.x-menu .x-anchor .x-anchor-text{margin:5px auto 5px 5px}.e7308-18.x-menu .x-anchor .x-anchor-text-primary{font-family:dunbar-text,sans-serif;font-size:1em;font-style:normal;font-weight:500;line-height:1.4;color:rgba(0,0,0,1)}.e7308-25.x-menu .x-anchor .x-anchor-text-primary{font-family:dunbar-text,sans-serif;font-size:.9em;font-style:normal;font-weight:500;line-height:1;color:rgba(0,0,0,1)}.e7308-18.x-menu .x-anchor[class*=active] .x-anchor-text-primary,.e7308-25.x-menu .x-anchor[class*=active] .x-anchor-text-primary{color:#f36d21}.e7308-18.x-menu .x-anchor .x-anchor-sub-indicator,.e7308-25.x-menu .x-anchor .x-anchor-sub-indicator{margin:5px;font-size:1em;color:rgba(0,0,0,1)}.e7308-18.x-menu .x-anchor[class*=active] .x-anchor-sub-indicator{color:rgba(0,0,0,.5)}.e7308-25.x-menu .x-anchor[class*=active] .x-anchor-sub-indicator{color:#f36d21}.e7308-4.x-search{width:55%;max-width:none;height:auto;border-radius:50em;font-size:1em;background-color:rgba(56,73,103,.08);border:.5px solid transparent}.e7308-9.x-search{width:40%;max-width:none;height:auto;border-radius:50em;font-size:1em;background-color:rgba(56,73,103,.08);border:.5px solid transparent}.e7308-17.x-search{width:65%;max-width:none;height:auto;border-radius:50em;font-size:1em;background-color:rgba(56,73,103,.08);border:.5px solid transparent}.e7308-28.x-search{width:100%;max-width:none;height:auto;border-radius:100em;font-size:1em;background-color:#f4f4f4;border:.5px solid transparent}.e7308-17.x-search .x-search-input,.e7308-4.x-search .x-search-input,.e7308-9.x-search .x-search-input{order:2;margin:0;font-family:inherit;font-size:.9em;font-style:normal;font-weight:400;line-height:1.3;color:rgba(0,0,0,.5)}.e7308-28.x-search .x-search-input{order:2;margin:0;font-family:inherit;font-size:1em;font-style:normal;font-weight:400;line-height:1.3;color:rgba(0,0,0,.5)}.e7308-17.x-search .x-search-btn-submit,.e7308-28.x-search .x-search-btn-submit,.e7308-4.x-search .x-search-btn-submit,.e7308-9.x-search .x-search-btn-submit{order:1;width:1em;height:1em;margin:.5em .5em .5em .9em;font-size:1em;color:rgba(0,0,0,1)}.e7308-17.x-search .x-search-btn-clear,.e7308-28.x-search .x-search-btn-clear,.e7308-4.x-search .x-search-btn-clear,.e7308-9.x-search .x-search-btn-clear{order:3;width:2em;height:2em;margin:.5em;border-radius:100em;font-size:.9em;color:rgba(255,255,255,1);background-color:rgba(0,0,0,.25)}.e7308-10.x-widget-area,.e7308-5.x-widget-area{font-size:16px}.e7497-1.x-bar{height:auto;padding:2em 0;font-size:16px;background-color:#bf2526;z-index:9999}.e7497-1.x-bar-content{flex-direction:column;justify-content:center;align-items:center;flex:0 1 100%;height:auto}.e7497-1.x-bar-outer-spacers:after,.e7497-1.x-bar-outer-spacers:before{flex-basis:2em;width:2em!important;height:2em}.e7497-4.x-anchor{border-radius:.15em;font-size:1em;border:1px solid #fff}.e7497-4.x-anchor .x-anchor-content{flex-direction:row;justify-content:center;align-items:center;padding:.575em 1.25em}.e7497-4.x-anchor .x-anchor-text{margin:5px}.e7497-4.x-anchor .x-anchor-text-primary{font-family:dunbar-text,sans-serif;font-size:.9em;font-style:normal;font-weight:500;line-height:1;text-transform:uppercase;color:#fff}.e7497-2.x-bar-container{flex-direction:column;justify-content:center;align-items:center;flex-wrap:wrap;align-content:center;flex:1 0 auto}.e7497-3.x-text{padding:0 0 1.5em;font-size:1em;background-color:transparent}.e7497-3.x-text .x-text-content-text-primary{font-family:dunbar-tall,sans-serif;font-size:1.4em;font-style:normal;font-weight:600;line-height:1.2;letter-spacing:0;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:#fff}.e7497-3.x-text .x-text-content-text-subheadline{margin-top:.15em;font-family:dunbar-text,sans-serif;font-size:1.2em;font-style:normal;font-weight:500;line-height:1.2;letter-spacing:0;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:#fff}.e1096-7.x-anchor{font-size:1em}.e1096-7.x-anchor .x-anchor-content{flex-direction:row;justify-content:center;align-items:center}.e1096-7.x-anchor .x-anchor-text{margin:5px}.e1096-7.x-anchor .x-anchor-text-primary{font-family:dunbar-text,sans-serif;font-size:1em;font-style:normal;font-weight:500;line-height:1;color:#f36d21}.e1096-7 .x-dropdown{width:400px;font-size:14px;background-color:#fff;box-shadow:0 .15em 2em 0 rgba(0,0,0,.15)}.e1096-4.x-text{font-size:1em;background-color:transparent}.e1096-4.x-text .x-text-content-text-primary{font-family:dunbar-tall,sans-serif;font-size:1.6em;font-style:normal;font-weight:600;line-height:1.4;letter-spacing:0;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:rgba(0,0,0,1)}.e1096-4.x-text .x-text-content-text-subheadline{margin-top:.35em;font-family:dunbar-text,sans-serif;font-size:1em;font-style:normal;font-weight:500;line-height:1.4;letter-spacing:0;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:rgba(0,0,0,1)}.e1096-6.x-col{display:flex;flex-direction:column;justify-content:flex-start;align-items:center;flex-wrap:wrap;align-content:center;z-index:1;font-size:1em;background-color:transparent}.e1096-3.x-col{z-index:1;max-width:80%;font-size:1em;background-color:transparent}.e1096-2.x-row{z-index:1;margin:0 auto;padding:1px;font-size:1em;background-color:transparent}.e1096-5.x-row{z-index:1;margin:0 auto;padding:20px 0 0;font-size:1em;background-color:transparent}.e1096-2>.x-row-inner{flex-direction:row;justify-content:center;align-items:center;align-content:center;margin:calc(((1rem / 2) + 1px) * -1)}.e1096-5>.x-row-inner{flex-direction:row;justify-content:flex-start;align-items:stretch;align-content:stretch;margin:calc((1rem / 2) * -1)}.e1096-2>.x-row-inner>*,.e1096-5>.x-row-inner>*{flex-grow:1;margin:calc(1rem / 2)}.e1096-1.x-section{margin:0;padding:45px 0 25px;background-color:transparent;z-index:1}@media (max-width:479.98px){.e1096-2>.x-row-inner>:nth-child(n-0),.e1096-5>.x-row-inner>:nth-child(n-0){flex-basis:calc(100% - 1rem)}}@media (min-width:480px) and (max-width:766.98px){.e1096-2>.x-row-inner>:nth-child(n-0),.e1096-5>.x-row-inner>:nth-child(n-0){flex-basis:calc(100% - 1rem)}}@media (min-width:767px) and (max-width:978.98px){.e1096-2>.x-row-inner>:nth-child(n-0),.e1096-5>.x-row-inner>:nth-child(n-0){flex-basis:calc(100% - 1rem)}}@media (min-width:979px) and (max-width:1199.98px){.e1096-2>.x-row-inner>:nth-child(n-0),.e1096-5>.x-row-inner>:nth-child(n-0){flex-basis:calc(100% - 1rem)}}@media (min-width:1200px){.e1096-2>.x-row-inner>:nth-child(n-0),.e1096-5>.x-row-inner>:nth-child(n-0){flex-basis:calc(100% - 1rem)}}.e1096-7 .x-dropdown{left:50%;margin-left:-200px!important;top:40px!important}.widget ul,.widget ul li,.widget ul li a{background:0 0;border:none;box-shadow:none}ul li{padding:5px 0}h1{margin-top:1em;font-size:170%;padding-bottom:20px;line-height:1.4;color:#000}h2{font-size:150%;line-height:1.4;padding-bottom:20px;color:#141414}.x-crumbs-link{text-transform:none!important}</style>
      <link rel="stylesheet" media="all" href="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/autoptimize_b787f37c90f3707cbe6e68b58c50b0df.css" onload="this.onload=null;this.media=&#39;all&#39;;">
      <noscript id="aonoscrcss">
         <link media="all" href="//mk0tothewebprod1couj.kinstacdn.com/wp-content/cache/autoptimize/css/autoptimize_b787f37c90f3707cbe6e68b58c50b0df.css" rel="stylesheet" />
      </noscript>
      <title>Search Engine Simulator Let's You See How Google Views your Page</title>
      <meta name="description" content="Your web page may look beautiful on the screen but if the search engines can&#39;t index your content, then your content doesn&#39;t get indexed. Test your homepage in this tool. ">
      <link rel="canonical" href="https://totheweb.com/learning_center/tools-search-engine-simulator/">
      <meta property="og:locale" content="en_US">
      <meta property="og:type" content="article">
      <meta property="og:title" content="Free Tool: Search Engine Simulator">
      <meta property="og:description" content="Your web page may look beautiful on the screen but if the search engines can&#39;t index your content, then your content doesn&#39;t get indexed. Test your homepage in this tool. ">
      <meta property="og:url" content="https://totheweb.com/learning_center/tools-search-engine-simulator/">
      <meta property="og:site_name" content="ToTheWeb">
      <meta property="article:publisher" content="https://www.facebook.com/totheweb">
      <meta property="article:modified_time" content="2021-08-20T14:23:33+00:00">
      <meta property="og:image" content="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2018/09/Search-Engine-Simulator-80_20fbd47708ae8fa220591a57cb64df2c.jpg">
      <meta property="og:image:width" content="570">
      <meta property="og:image:height" content="428">
      <meta name="twitter:card" content="summary">
      <meta name="twitter:site" content="@totheweb">
      <meta name="twitter:label1" content="Est. reading time">
      <meta name="twitter:data1" content="1 minute">
      <script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://totheweb.com/#website","url":"https://totheweb.com/","name":"ToTheWeb","description":"Search Marketing &amp; Lead Generation","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://totheweb.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"ImageObject","@id":"https://totheweb.com/learning_center/tools-search-engine-simulator/#primaryimage","inLanguage":"en-US","url":"https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2018/09/Search-Engine-Simulator-80_20fbd47708ae8fa220591a57cb64df2c.jpg","contentUrl":"https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2018/09/Search-Engine-Simulator-80_20fbd47708ae8fa220591a57cb64df2c.jpg","width":570,"height":428},{"@type":"WebPage","@id":"https://totheweb.com/learning_center/tools-search-engine-simulator/#webpage","url":"https://totheweb.com/learning_center/tools-search-engine-simulator/","name":"Search Engine Simulator Let's You See How Google Views your Page","isPartOf":{"@id":"https://totheweb.com/#website"},"primaryImageOfPage":{"@id":"https://totheweb.com/learning_center/tools-search-engine-simulator/#primaryimage"},"datePublished":"2014-03-27T08:27:53+00:00","dateModified":"2021-08-20T14:23:33+00:00","description":"Your web page may look beautiful on the screen but if the search engines can't index your content, then your content doesn't get indexed. Test your homepage in this tool.\u00a0","breadcrumb":{"@id":"https://totheweb.com/learning_center/tools-search-engine-simulator/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://totheweb.com/learning_center/tools-search-engine-simulator/"]}]},{"@type":"BreadcrumbList","@id":"https://totheweb.com/learning_center/tools-search-engine-simulator/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://totheweb.com/"},{"@type":"ListItem","position":2,"name":"B2B Search Marketing Tools &#038; Articles","item":"https://totheweb.com/learning_center/"},{"@type":"ListItem","position":3,"name":"Free Tool: Search Engine Simulator"}]}]}</script> 
      <link rel="dns-prefetch" href="https://code.jquery.com/">
      <link rel="dns-prefetch" href="https://www.google.com/">
      <link href="https://fonts.gstatic.com/" crossorigin="anonymous" rel="preconnect">
      <link href="https://ajax.googleapis.com/" rel="preconnect">
      <link href="https://fonts.googleapis.com/" rel="preconnect">
      <link rel="alternate" type="application/rss+xml" title="ToTheWeb » Feed" href="https://totheweb.com/feed/">
      <link rel="alternate" type="application/rss+xml" title="ToTheWeb » Comments Feed" href="https://totheweb.com/comments/feed/">
      <link rel="alternate" type="application/rss+xml" title="ToTheWeb » Free Tool: Search Engine Simulator Comments Feed" href="https://totheweb.com/learning_center/tools-search-engine-simulator/feed/">
      <style id="rate-my-post-inline-css" type="text/css">@media (hover: hover) {.rmp-rating-widget .rmp-icon--hovered {color: #F26D20;    -webkit-background-clip: initial;    -webkit-text-fill-color: initial;    background: transparent;    -webkit-transition: .1s color ease-in;    transition: .1s color ease-in;}}.rmp-rating-widget .rmp-icon--processing-rating {  color: #FF912C;  -webkit-background-clip: initial;  -webkit-text-fill-color: initial;  background: transparent;}.rmp-widgets-container.rmp-wp-plugin.rmp-main-container .rmp-rating-widget__icons-list__icon {margin-left: 5px;margin-right: 5px;}</style>
      <script type="text/javascript" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/jquery.min.js.download" id="jquery-core-js"></script> <script type="text/javascript" id="eio-lazy-load-js-extra">var eio_lazy_vars = {"exactdn_domain":"","skip_autoscale":"0"};</script> <script type="text/javascript" id="foobox-free-min-js-before">/* Run FooBox FREE (v2.7.16) */
         var FOOBOX = window.FOOBOX = {
         	ready: true,
         	disableOthers: false,
         	o: {wordpress: { enabled: true }, countMessage:'image %index of %total', excludes:'.fbx-link,.nofoobox,.nolightbox,a[href*="pinterest.com/pin/create/button/"]', affiliate : { enabled: false }},
         	selectors: [
         		".gallery", ".wp-block-gallery", ".wp-caption", ".wp-block-image", "a:has(img[class*=wp-image-])", ".foobox"
         	],
         	pre: function( $ ){
         		// Custom JavaScript (Pre)
         		
         	},
         	post: function( $ ){
         		// Custom JavaScript (Post)
         		
         		// Custom Captions Code
         		
         	},
         	custom: function( $ ){
         		// Custom Extra JS
         		
         	}
         };
      </script> 
      <link rel="https://api.w.org/" href="https://totheweb.com/wp-json/">
      <link rel="alternate" type="application/json" href="https://totheweb.com/wp-json/wp/v2/pages/1096">
      <link rel="shortlink" href="https://totheweb.com/?p=1096">
      <link rel="alternate" type="application/json+oembed" href="https://totheweb.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ftotheweb.com%2Flearning_center%2Ftools-search-engine-simulator%2F">
      <link rel="alternate" type="text/xml+oembed" href="https://totheweb.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ftotheweb.com%2Flearning_center%2Ftools-search-engine-simulator%2F&amp;format=xml">
      <script type="application/ld+json">{"@context":"https:\/\/schema.org\/","@type":"Article","mainEntityOfPage":{"@type":"WebPage","@id":"https:\/\/totheweb.com\/learning_center\/tools-search-engine-simulator\/"},"url":"https:\/\/totheweb.com\/learning_center\/tools-search-engine-simulator\/","headline":"Free Tool: Search Engine Simulator","datePublished":"2014-03-27T08:27:53+00:00","dateModified":"2021-08-20T14:23:33+00:00","publisher":{"@type":"Organization","@id":"https:\/\/totheweb.com\/#organization","name":"ToTheWeb","logo":{"@type":"ImageObject","url":"https:\/\/totheweb.com\/wp-content\/uploads\/2019\/05\/ToTheWeb-Logo-Schema.gif","width":600,"height":60}},"image":{"@type":"ImageObject","url":"https:\/\/totheweb.com\/wp-content\/uploads\/2018\/09\/Search-Engine-Simulator-80_20fbd47708ae8fa220591a57cb64df2c.jpg","width":696,"height":428},"description":"Search Engine Spider SimulatorThe Search Engine Simulator tool shows you how the engines “see” a web page. It simulates how Google “reads” a webpage by displaying the content exactly how it would see it. Why Use This Tool? + Your web page may look beautiful on the screen but if","author":{"@type":"Person","name":"Rosemary Brisco","url":"https:\/\/totheweb.com\/blog\/author\/rbrisco\/","description":"Rosemary works with companies to turn their website into a sales generating tool by ensuring that the site achieves high visibility in the search engines.","image":{"@type":"ImageObject","url":"https:\/\/secure.gravatar.com\/avatar\/18112c451a6bb4c3508b5be4e8522939?s=96&d=mm&r=g","height":96,"width":96},"sameAs":["https:\/\/totheweb.com","https:\/\/plus.google.com\/+RosemaryBrisco","https:\/\/www.facebook.com\/totheweb\/","https:\/\/twitter.com\/@totheweb"]},"commentCount":"2"}</script> 
      <style id="ubermenu-custom-generated-css">/** Font Awesome 4 Compatibility **/
         .fa{font-style:normal;font-variant:normal;font-weight:normal;font-family:FontAwesome;}
         /** UberMenu Custom Menu Styles (Customizer) **/
         /* main */
         .ubermenu-main { background:#ffffff; border:1px solid #ffffff; }
         .ubermenu-main .ubermenu-item-level-0 > .ubermenu-target { font-size:12px; text-transform:uppercase; color:#2c2c2c; }
         .ubermenu-main .ubermenu-nav .ubermenu-item.ubermenu-item-level-0 > .ubermenu-target { font-weight:400; }
         .ubermenu.ubermenu-main .ubermenu-item-level-0:hover > .ubermenu-target, .ubermenu-main .ubermenu-item-level-0.ubermenu-active > .ubermenu-target { color:#484848; }
         .ubermenu-main .ubermenu-item-level-0.ubermenu-current-menu-item > .ubermenu-target, .ubermenu-main .ubermenu-item-level-0.ubermenu-current-menu-parent > .ubermenu-target, .ubermenu-main .ubermenu-item-level-0.ubermenu-current-menu-ancestor > .ubermenu-target { color:#f36d21; }
         .ubermenu-main .ubermenu-item.ubermenu-item-level-0 > .ubermenu-highlight { color:#484848; }
         .ubermenu.ubermenu-main .ubermenu-item-level-0 > .ubermenu-target { background:#ffffff; }
         .ubermenu-main .ubermenu-submenu.ubermenu-submenu-drop { background-color:#f7f7f7; border:1px solid #dddddd; }
         .ubermenu-main .ubermenu-item-level-0 > .ubermenu-submenu-drop { box-shadow:none; }
         .ubermenu-main .ubermenu-item-normal > .ubermenu-target,.ubermenu-main .ubermenu-submenu .ubermenu-target,.ubermenu-main .ubermenu-submenu .ubermenu-nonlink,.ubermenu-main .ubermenu-submenu .ubermenu-widget,.ubermenu-main .ubermenu-submenu .ubermenu-custom-content-padded,.ubermenu-main .ubermenu-submenu .ubermenu-retractor,.ubermenu-main .ubermenu-submenu .ubermenu-colgroup .ubermenu-column,.ubermenu-main .ubermenu-submenu.ubermenu-submenu-type-stack > .ubermenu-item-normal > .ubermenu-target,.ubermenu-main .ubermenu-submenu.ubermenu-submenu-padded { padding:10px 30px; }
         .ubermenu-main .ubermenu-grid-row { padding-right:10px 30px; }
         .ubermenu-main .ubermenu-grid-row .ubermenu-target { padding-right:0; }
         .ubermenu-main.ubermenu-sub-indicators .ubermenu-submenu :not(.ubermenu-tabs-layout-right) .ubermenu-has-submenu-drop > .ubermenu-target { padding-right:25px; }
         .ubermenu-main .ubermenu-submenu .ubermenu-item-header > .ubermenu-target, .ubermenu-main .ubermenu-tab > .ubermenu-target { font-size:14px; }
         .ubermenu-main .ubermenu-submenu .ubermenu-item-header > .ubermenu-target { color:#2c2c2c; }
         .ubermenu-main .ubermenu-submenu .ubermenu-item-header > .ubermenu-target:hover { color:#424242; }
         .ubermenu-main .ubermenu-submenu .ubermenu-item-header.ubermenu-current-menu-item > .ubermenu-target { color:#f36d21; }
         .ubermenu-main .ubermenu-nav .ubermenu-submenu .ubermenu-item-header > .ubermenu-target { font-weight:700; }
         .ubermenu-main .ubermenu-submenu .ubermenu-item-header.ubermenu-has-submenu-stack > .ubermenu-target { border:none; }
         .ubermenu-main .ubermenu-submenu-type-stack { padding-top:0; }
         .ubermenu-main .ubermenu-item-normal > .ubermenu-target { color:#424242; font-size:12px; font-weight:600; }
         .ubermenu.ubermenu-main .ubermenu-item-normal > .ubermenu-target:hover, .ubermenu.ubermenu-main .ubermenu-item-normal.ubermenu-active > .ubermenu-target { color:#f36d21; background-color:#f7f7f7; }
         .ubermenu-main .ubermenu-item-normal.ubermenu-current-menu-item > .ubermenu-target { color:#f36d21; }
         .ubermenu-main .ubermenu-target > .ubermenu-target-description { font-size:12px; }
         .ubermenu-main .ubermenu-target > .ubermenu-target-description, .ubermenu-main .ubermenu-submenu .ubermenu-target > .ubermenu-target-description { color:#a1a8a8; }
         .ubermenu-main .ubermenu-submenu .ubermenu-divider > hr { border-top-color:#dd3333; }
         /** UberMenu Custom Menu Item Styles (Menu Item Settings) **/
         /* 6955 */   .ubermenu .ubermenu-item.ubermenu-item-6955 > .ubermenu-target { background:#ffffff; color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6955.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6955:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6955.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6955:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6955.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6955.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6955 > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6955 > .ubermenu-content-block,.ubermenu .ubermenu-item.ubermenu-item-6955.ubermenu-custom-content-padded { padding:30px; }
         /* 6957 */   .ubermenu .ubermenu-item.ubermenu-item-6957.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6957:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6957.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6957:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6957.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6957.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6969 */   .ubermenu .ubermenu-item.ubermenu-item-6969.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6969:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6969.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6969:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6969.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6969.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6963 */   .ubermenu .ubermenu-item.ubermenu-item-6963.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6963:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6963.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6963:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6963.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6963.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6966 */   .ubermenu .ubermenu-item.ubermenu-item-6966.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6966:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6966.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6966:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6966.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6966.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6960 */   .ubermenu .ubermenu-item.ubermenu-item-6960.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6960:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6960.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6960:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6960.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6960.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6962 */   .ubermenu .ubermenu-item.ubermenu-item-6962.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6962:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6962.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6962:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6962.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6962.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6961 */   .ubermenu .ubermenu-item.ubermenu-item-6961.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6961:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6961.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6961:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6961.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6961.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6970 */   .ubermenu .ubermenu-item.ubermenu-item-6970.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6970:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6970.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6970:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6970.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6970.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 7024 */   .ubermenu .ubermenu-item.ubermenu-item-7024.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7024:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7024.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7024:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-7024.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7024.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6964 */   .ubermenu .ubermenu-item.ubermenu-item-6964.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6964:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6964.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6964:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6964.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6964.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 6967 */   .ubermenu .ubermenu-item.ubermenu-item-6967.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6967:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6967.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6967:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-6967.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6967.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 7279 */   .ubermenu .ubermenu-item.ubermenu-item-7279.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7279:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7279.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7279:hover > .ubermenu-target { color:#fdb61e; }
         .ubermenu .ubermenu-item.ubermenu-item-7279.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7279.ubermenu-current-menu-ancestor > .ubermenu-target { color:#fdb61e; }
         /* 7009 */   .ubermenu .ubermenu-item.ubermenu-item-7009.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7009:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7009.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7009:hover > .ubermenu-target { color:#2a87d3; }
         .ubermenu .ubermenu-item.ubermenu-item-7009.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7009.ubermenu-current-menu-ancestor > .ubermenu-target { color:#2a87d3; }
         /* 7011 */   .ubermenu .ubermenu-item.ubermenu-item-7011.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7011:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7011.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7011:hover > .ubermenu-target { color:#2a87d3; }
         .ubermenu .ubermenu-item.ubermenu-item-7011.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7011.ubermenu-current-menu-ancestor > .ubermenu-target { color:#2a87d3; }
         /* 7012 */   .ubermenu .ubermenu-item.ubermenu-item-7012.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7012:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7012.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7012:hover > .ubermenu-target { color:#2a87d3; }
         .ubermenu .ubermenu-item.ubermenu-item-7012.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7012.ubermenu-current-menu-ancestor > .ubermenu-target { color:#2a87d3; }
         /* 7006 */   .ubermenu .ubermenu-item.ubermenu-item-7006 > .ubermenu-target { background:#ffffff; color:#2a87d3; }
         .ubermenu .ubermenu-item.ubermenu-item-7006.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7006:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7006.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7006:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-7006.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7006.ubermenu-current-menu-ancestor > .ubermenu-target { color:#2a87d3; }
         .ubermenu .ubermenu-item.ubermenu-item-7006 > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7006 > .ubermenu-content-block,.ubermenu .ubermenu-item.ubermenu-item-7006.ubermenu-custom-content-padded { padding:30px; }
         /* 6985 */   .ubermenu .ubermenu-item.ubermenu-item-6985 > .ubermenu-target { background:#ffffff; color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-6985.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6985:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6985.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6985:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6985.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6985.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-6985 > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6985 > .ubermenu-content-block,.ubermenu .ubermenu-item.ubermenu-item-6985.ubermenu-custom-content-padded { padding:30px; }
         /* 6990 */   .ubermenu .ubermenu-item.ubermenu-item-6990.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6990:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6990.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6990:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-6990.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6990.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 6993 */   .ubermenu .ubermenu-item.ubermenu-item-6993.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6993:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6993.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6993:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-6993.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6993.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 7002 */   .ubermenu .ubermenu-item.ubermenu-item-7002.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7002:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7002.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7002:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-7002.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7002.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 7004 */   .ubermenu .ubermenu-item.ubermenu-item-7004.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7004:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7004.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7004:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-7004.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7004.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 6991 */   .ubermenu .ubermenu-item.ubermenu-item-6991.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6991:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6991.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6991:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-6991.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6991.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 6992 */   .ubermenu .ubermenu-item.ubermenu-item-6992.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6992:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6992.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6992:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-6992.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6992.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 7003 */   .ubermenu .ubermenu-item.ubermenu-item-7003.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7003:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7003.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7003:hover > .ubermenu-target { color:#db9e07; }
         .ubermenu .ubermenu-item.ubermenu-item-7003.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7003.ubermenu-current-menu-ancestor > .ubermenu-target { color:#db9e07; }
         /* 6956 */   .ubermenu .ubermenu-item.ubermenu-item-6956 { background:#f7f7f7; }
         /* 6958 */   .ubermenu .ubermenu-item.ubermenu-item-6958 { background:#f7f7f7; }
         /* 6965 */   .ubermenu .ubermenu-item.ubermenu-item-6965 { background:#f7f7f7; }
         /* 6984 */   .ubermenu .ubermenu-item.ubermenu-item-6984 { background:#f7f7f7; }
         /* 6989 */   .ubermenu .ubermenu-item.ubermenu-item-6989 { background:#f7f7f7; }
         /* 7000 */   .ubermenu .ubermenu-item.ubermenu-item-7000 { background:#f7f7f7; }
         /* 7001 */   .ubermenu .ubermenu-item.ubermenu-item-7001 { background:#f7f7f7; }
         /* 7008 */   .ubermenu .ubermenu-item.ubermenu-item-7008 { background:#f7f7f7; }
         /* 6980 */   .ubermenu .ubermenu-item.ubermenu-item-6980 > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6980.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6980:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6980.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6980:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6980.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6980.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 6971 */   .ubermenu .ubermenu-item.ubermenu-item-6971 > .ubermenu-target { background:#ffffff; color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6971.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6971:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6971.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6971:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6971.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6971.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6971 > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6971 > .ubermenu-content-block,.ubermenu .ubermenu-item.ubermenu-item-6971.ubermenu-custom-content-padded { padding:30px; }
         /* 6974 */   .ubermenu .ubermenu-item.ubermenu-item-6974 { background:#f7f7f7; }
         /* 7281 */   .ubermenu .ubermenu-item.ubermenu-item-7281 > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7281 > .ubermenu-content-block,.ubermenu .ubermenu-item.ubermenu-item-7281.ubermenu-custom-content-padded { padding:20px 0px 20px 30px; }
         /* 6978 */   .ubermenu .ubermenu-item.ubermenu-item-6978 > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6978.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6978:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6978.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6978:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6978.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6978.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 6977 */   .ubermenu .ubermenu-item.ubermenu-item-6977 > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6977.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6977:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6977.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6977:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6977.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6977.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 6975 */   .ubermenu .ubermenu-item.ubermenu-item-6975 > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6975.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6975:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6975.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6975:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6975.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6975.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 6976 */   .ubermenu .ubermenu-item.ubermenu-item-6976 > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6976.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6976:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6976.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6976:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6976.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6976.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 6979 */   .ubermenu .ubermenu-item.ubermenu-item-6979 > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-6979.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-6979:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6979.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-6979:hover > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-6979.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-6979.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 7013 */   .ubermenu .ubermenu-item.ubermenu-item-7013 > .ubermenu-target { color:#484848; }
         .ubermenu .ubermenu-item.ubermenu-item-7013.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-item.ubermenu-item-7013:hover > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7013.ubermenu-active > .ubermenu-target, .ubermenu .ubermenu-submenu .ubermenu-item.ubermenu-item-7013:hover > .ubermenu-target { color:#bf2526; }
         .ubermenu .ubermenu-item.ubermenu-item-7013.ubermenu-current-menu-item > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7013.ubermenu-current-menu-ancestor > .ubermenu-target { color:#bf2526; }
         /* 6983 */   .ubermenu .ubermenu-item.ubermenu-item-6983 > .ubermenu-target { color:#ff6f00; }
         /* 7542 */   .ubermenu .ubermenu-item.ubermenu-item-7542 > .ubermenu-target { color:#ff6f00; }
         .ubermenu .ubermenu-item.ubermenu-item-7542 > .ubermenu-target,.ubermenu .ubermenu-item.ubermenu-item-7542 > .ubermenu-content-block,.ubermenu .ubermenu-item.ubermenu-item-7542.ubermenu-custom-content-padded { padding:30px; }
         /* Status: Loaded from Transient */
      </style>
      <script data-cfasync="false" data-pagespeed-no-defer="">//
         var dataLayer_content = {"pagePostType":"page","pagePostType2":"single-page","pagePostAuthor":"Rosemary Brisco"};
         dataLayer.push( dataLayer_content );//
      </script> <script data-cfasync="false">//
         (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
         new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
         j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
         '//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
         })(window,document,'script','dataLayer','GTM-KZ7KXP');//
      </script> 
      <link rel="preload" href="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/plugins/rate-my-post/public/css/fonts/ratemypost.woff?9e18pt" as="style">
      <noscript>
         <style>.lazyload[data-src]{display:none !important;}</style>
      </noscript>
      <style>.lazyload{background-image:none !important;}</style>
      <script type="application/ld+json">{
         "@context": "http://schema.org",
         "@type": "BreadcrumbList",
         "itemListElement": [
             {
                 "@type": "ListItem",
                 "position": 1,
                 "item": {
                     "@id": "https://totheweb.com",
                     "name": "Home"
                 }
             },
             {
                 "@type": "ListItem",
                 "position": 2,
                 "item": {
                     "@id": "https://totheweb.com/learning_center/",
                     "name": "B2B Search Marketing Tools &#038; Articles"
                 }
             },
             {
                 "@type": "ListItem",
                 "position": 3,
                 "item": {
                     "@id": "https://totheweb.com/learning_center/tools-search-engine-simulator/",
                     "name": "Free Tool: Search Engine Simulator",
                     "image": "https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2018/09/Search-Engine-Simulator-80_20fbd47708ae8fa220591a57cb64df2c.jpg"
                 }
             }
         ]
         }
      </script> 
      <style id="x-generated-css">a,h1 a:hover,h2 a:hover,h3 a:hover,h4 a:hover,h5 a:hover,h6 a:hover,.x-breadcrumb-wrap a:hover,.widget ul li a:hover,.widget ol li a:hover,.widget.widget_text ul li a,.widget.widget_text ol li a,.widget_nav_menu .current-menu-item > a,.x-accordion-heading .x-accordion-toggle:hover,.x-comment-author a:hover,.x-comment-time:hover,.x-recent-posts a:hover .h-recent-posts{color:rgb(243,109,33);}a:hover,.widget.widget_text ul li a:hover,.widget.widget_text ol li a:hover,.x-twitter-widget ul li a:hover{color:rgb(36,36,36);}.rev_slider_wrapper,a.x-img-thumbnail:hover,.x-slider-container.below,.page-template-template-blank-3-php .x-slider-container.above,.page-template-template-blank-6-php .x-slider-container.above{border-color:rgb(243,109,33);}.entry-thumb:before,.x-pagination span.current,.flex-direction-nav a,.flex-control-nav a:hover,.flex-control-nav a.flex-active,.mejs-time-current,.x-dropcap,.x-skill-bar .bar,.x-pricing-column.featured h2,.h-comments-title small,.x-entry-share .x-share:hover,.x-highlight,.x-recent-posts .x-recent-posts-img:after{background-color:rgb(243,109,33);}.x-nav-tabs > .active > a,.x-nav-tabs > .active > a:hover{box-shadow:inset 0 3px 0 0 rgb(243,109,33);}.x-main{width:calc(72% - 2.463055%);}.x-sidebar{width:calc(100% - 2.463055% - 72%);}.x-comment-author,.x-comment-time,.comment-form-author label,.comment-form-email label,.comment-form-url label,.comment-form-rating label,.comment-form-comment label,.widget_calendar #wp-calendar caption,.widget.widget_rss li .rsswidget{font-family:"dunbar-tall",sans-serif;font-weight:600;}.p-landmark-sub,.p-meta,input,button,select,textarea{font-family:"dunbar-text",sans-serif;}.widget ul li a,.widget ol li a,.x-comment-time{color:rgb(21,21,21);}.widget_text ol li a,.widget_text ul li a{color:rgb(243,109,33);}.widget_text ol li a:hover,.widget_text ul li a:hover{color:rgb(36,36,36);}.comment-form-author label,.comment-form-email label,.comment-form-url label,.comment-form-rating label,.comment-form-comment label,.widget_calendar #wp-calendar th,.p-landmark-sub strong,.widget_tag_cloud .tagcloud a:hover,.widget_tag_cloud .tagcloud a:active,.entry-footer a:hover,.entry-footer a:active,.x-breadcrumbs .current,.x-comment-author,.x-comment-author a{color:rgb(36,36,36);}.widget_calendar #wp-calendar th{border-color:rgb(36,36,36);}.h-feature-headline span i{background-color:rgb(36,36,36);}@media (max-width:978.98px){}html{font-size:14px;}@media (min-width:500px){html{font-size:calc(14px + (16 - 14) * ((100vw - 500px) / (1000 - 500)));}}@media (min-width:1000px){html{font-size:16px;}}body{font-style:normal;font-weight:500;color:rgb(21,21,21);background-color:rgb(255,255,255);}.w-b{font-weight:500 !important;}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6{font-family:"dunbar-tall",sans-serif;font-style:normal;font-weight:600;}h1,.h1{letter-spacing:0em;}h2,.h2{letter-spacing:0em;}h3,.h3{letter-spacing:0em;}h4,.h4{letter-spacing:0em;}h5,.h5{letter-spacing:0em;}h6,.h6{letter-spacing:0em;}.w-h{font-weight:600 !important;}.x-container.width{width:88%;}.x-container.max{max-width:1200px;}.x-main.full{float:none;display:block;width:auto;}@media (max-width:978.98px){.x-main.full,.x-main.left,.x-main.right,.x-sidebar.left,.x-sidebar.right{float:none;display:block;width:auto !important;}}.entry-header,.entry-content{font-size:1rem;}body,input,button,select,textarea{font-family:"dunbar-text",sans-serif;}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6,h1 a,h2 a,h3 a,h4 a,h5 a,h6 a,.h1 a,.h2 a,.h3 a,.h4 a,.h5 a,.h6 a,blockquote{color:rgb(36,36,36);}.cfc-h-tx{color:rgb(36,36,36) !important;}.cfc-h-bd{border-color:rgb(36,36,36) !important;}.cfc-h-bg{background-color:rgb(36,36,36) !important;}.cfc-b-tx{color:rgb(21,21,21) !important;}.cfc-b-bd{border-color:rgb(21,21,21) !important;}.cfc-b-bg{background-color:rgb(21,21,21) !important;}.x-btn,.button,[type="submit"]{color:#ffffff;border-color:transparent;background-color:transparent;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.5);}.x-btn:hover,.button:hover,[type="submit"]:hover{color:transparent;border-color:transparent;background-color:transparent;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.5);}.x-btn.x-btn-real,.x-btn.x-btn-real:hover{margin-bottom:0.25em;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.65);}.x-btn.x-btn-real{box-shadow:0 0.25em 0 0 #a71000,0 4px 9px rgba(0,0,0,0.75);}.x-btn.x-btn-real:hover{box-shadow:0 0.25em 0 0 #a71000,0 4px 9px rgba(0,0,0,0.75);}.x-btn.x-btn-flat,.x-btn.x-btn-flat:hover{margin-bottom:0;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.65);box-shadow:none;}.x-btn.x-btn-transparent,.x-btn.x-btn-transparent:hover{margin-bottom:0;border-width:3px;text-shadow:none;text-transform:uppercase;background-color:transparent;box-shadow:none;}.wf-loading a, .wf-loading p, .wf-loading ul, .wf-loading ol, .wf-loading dl, .wf-loading h1, .wf-loading h2, .wf-loading h3, .wf-loading h4, .wf-loading h5, .wf-loading h6, .wf-loading em, .wf-loading pre, .wf-loading cite, .wf-loading span, .wf-loading table, .wf-loading strong, .wf-loading blockquote { visibility: hidden !important; }.e7308-1.x-bar {height:6em;font-size:16px;background-color:#ffffff;box-shadow:0em 0.15em 0.5em 0px rgba(0,0,0,0.05);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-6.x-bar {height:6em;font-size:16px;background-color:#ffffff;box-shadow:0em 0.15em 0.5em 0px rgba(0,0,0,0.05);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-11.x-bar {height:4em;font-size:16px;background-color:#ffffff;z-index:9998;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-14.x-bar {height:6em;font-size:16px;background-color:#ffffff;box-shadow:0em 0.15em 0.5em 0px rgba(0,0,0,0.05);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-19.x-bar {height:3em;font-size:16px;background-color:#ffffff;z-index:9998;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-22.x-bar {height:5em;font-size:16px;background-color:#ffffff;box-shadow:0em 0.15em 0.5em 0px rgba(0,0,0,0.05);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-26.x-bar {height:4em;font-size:16px;background-color:#ffffff;z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-29.x-bar {height:3em;font-size:16px;background-color:#ffffff;z-index:9998;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-1.x-bar-content {flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:6em;}.e7308-6.x-bar-content {flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:6em;}.e7308-11.x-bar-content {flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:4em;}.e7308-14.x-bar-content {flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 100%;height:6em;}.e7308-19.x-bar-content {flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:3em;}.e7308-22.x-bar-content {flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 100%;height:5em;}.e7308-26.x-bar-content {flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 100%;height:4em;}.e7308-29.x-bar-content {flex-direction:row;justify-content:flex-start;align-items:center;flex:0 1 100%;height:3em;}.e7308-1.x-bar-outer-spacers:before,.e7308-1.x-bar-outer-spacers:after {flex-basis:4em;width:4em !important;height:4em;}.e7308-6.x-bar-outer-spacers:before,.e7308-6.x-bar-outer-spacers:after {flex-basis:4em;width:4em !important;height:4em;}.e7308-11.x-bar-outer-spacers:before,.e7308-11.x-bar-outer-spacers:after {flex-basis:4em;width:4em !important;height:4em;}.e7308-14.x-bar-outer-spacers:before,.e7308-14.x-bar-outer-spacers:after {flex-basis:2em;width:2em !important;height:2em;}.e7308-19.x-bar-outer-spacers:before,.e7308-19.x-bar-outer-spacers:after {flex-basis:2em;width:2em !important;height:2em;}.e7308-22.x-bar-outer-spacers:before,.e7308-22.x-bar-outer-spacers:after {flex-basis:2em;width:2em !important;height:2em;}.e7308-26.x-bar-outer-spacers:before,.e7308-26.x-bar-outer-spacers:after {flex-basis:2em;width:2em !important;height:2em;}.e7308-29.x-bar-outer-spacers:before,.e7308-29.x-bar-outer-spacers:after {flex-basis:2em;width:2em !important;height:2em;}.e7308-1.x-bar-space {font-size:16px;height:6em;}.e7308-6.x-bar-space {font-size:16px;height:6em;}.e7308-11.x-bar-space {font-size:16px;height:4em;}.e7308-14.x-bar-space {font-size:16px;height:6em;}.e7308-19.x-bar-space {font-size:16px;height:3em;}.e7308-22.x-bar-space {font-size:16px;height:5em;}.e7308-26.x-bar-space {font-size:16px;height:4em;}.e7308-29.x-bar-space {font-size:16px;height:3em;}.e7308-1.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-6.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-11.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-14.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-19.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-22.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-26.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-29.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-13.x-crumbs {font-family:"dunbar-text",sans-serif;font-size:0.7em;font-weight:500;line-height:1.4;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-21.x-crumbs {font-family:"dunbar-text",sans-serif;font-size:0.7em;font-weight:500;line-height:1.4;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-31.x-crumbs {font-family:"dunbar-text",sans-serif;font-size:0.7em;font-weight:500;line-height:1.4;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-13.x-crumbs .x-crumbs-link {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-21.x-crumbs .x-crumbs-link {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-31.x-crumbs .x-crumbs-link {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-13 .x-crumbs-list {justify-content:flex-start;margin-left:-8px !important;}.e7308-21 .x-crumbs-list {justify-content:flex-start;margin-left:-8px !important;}.e7308-31 .x-crumbs-list {justify-content:flex-start;margin-left:-8px !important;}.e7308-13 .x-crumbs-list-item {margin-left:8px;}.e7308-21 .x-crumbs-list-item {margin-left:8px;}.e7308-31 .x-crumbs-list-item {margin-left:8px;}.e7308-13 .x-crumbs-link {font-style:normal;line-height:1.3;color:rgb(112,112,112);}.e7308-21 .x-crumbs-link {font-style:normal;line-height:1.3;text-transform:uppercase;color:rgb(112,112,112);}.e7308-31 .x-crumbs-link {font-style:normal;line-height:1.3;text-transform:uppercase;color:rgb(112,112,112);}.e7308-13 .x-crumbs-link:hover {color:rgb(191,37,38);}.e7308-21 .x-crumbs-link:hover {color:rgb(191,37,38);}.e7308-31 .x-crumbs-link:hover {color:rgb(191,37,38);}.e7308-13 .x-crumbs-delimiter {margin-left:8px;color:rgba(0,0,0,0.5);}.e7308-21 .x-crumbs-delimiter {margin-left:8px;color:rgba(0,0,0,0.5);}.e7308-31 .x-crumbs-delimiter {margin-left:8px;color:rgba(0,0,0,0.5);}.e7308-2.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-7.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-12.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-15.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-20.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-23.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-27.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 auto;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-30.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:1 0 0%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-3.x-image {width:180px;padding:0px 30px 0px 0px;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-8.x-image {width:180px;padding:0px 30px 0px 0px;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-16.x-image {width:160px;padding:0px 30px 0px 0px;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-24.x-image {width:160px;padding:0px 30px 0px 0px;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-3.x-image img {width:100%;}.e7308-8.x-image img {width:100%;}.e7308-16.x-image img {width:100%;}.e7308-24.x-image img {width:100%;}.e7308-18.x-anchor-toggle {width:3em;height:3em;font-size:1em;background-color:rgba(255,255,255,1);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-anchor-toggle {width:3em;height:3em;font-size:1em;background-color:rgba(255,255,255,1);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-anchor-toggle .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;}.e7308-25.x-anchor-toggle .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;}.e7308-18.x-anchor-toggle .x-graphic {margin:5px;}.e7308-25.x-anchor-toggle .x-graphic {margin:5px;}.e7308-18.x-anchor-toggle .x-toggle {color:rgba(0,0,0,1);}.e7308-25.x-anchor-toggle .x-toggle {color:rgba(0,0,0,1);}.e7308-18.x-anchor-toggle:hover .x-toggle,.e7308-18.x-anchor-toggle[class*="active"] .x-toggle,[data-x-effect-provider*="colors"]:hover .e7308-18.x-anchor-toggle .x-toggle {color:rgb(243,109,33);}.e7308-25.x-anchor-toggle:hover .x-toggle,.e7308-25.x-anchor-toggle[class*="active"] .x-toggle,[data-x-effect-provider*="colors"]:hover .e7308-25.x-anchor-toggle .x-toggle {color:rgb(243,109,33);}.e7308-18.x-anchor-toggle .x-toggle-burger {width:12em;margin:3.25em 0;font-size:0.2em;}.e7308-25.x-anchor-toggle .x-toggle-burger {width:12em;margin:3.25em 0;font-size:0.15em;}.e7308-18.x-anchor-toggle .x-toggle-burger-bun-t {transform:translate3d(0,-3.25em,0);}.e7308-25.x-anchor-toggle .x-toggle-burger-bun-t {transform:translate3d(0,-3.25em,0);}.e7308-18.x-anchor-toggle .x-toggle-burger-bun-b {transform:translate3d(0,3.25em,0);}.e7308-25.x-anchor-toggle .x-toggle-burger-bun-b {transform:translate3d(0,3.25em,0);}.e7308-18.x-anchor-toggle .x-anchor-text-primary {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-anchor-toggle .x-anchor-text-primary {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-anchor-toggle .x-anchor-text-secondary {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-anchor-toggle .x-anchor-text-secondary {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-anchor-toggle .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-anchor-toggle .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-off-canvas {font-size:16px;transition-duration:500ms;}.e7308-25.x-off-canvas {font-size:16px;transition-duration:500ms;}.e7308-18.x-off-canvas .x-off-canvas-bg {background-color:rgba(0,0,0,0.75);transition-duration:500ms;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-off-canvas .x-off-canvas-bg {background-color:rgba(0,0,0,0.75);transition-duration:500ms;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-off-canvas .x-off-canvas-close {width:calc(1em * 2);height:calc(1em * 2);font-size:2em;color:rgba(0,0,0,0.5);transition-duration:0.3s,500ms,500ms;transition-timing-function:ease-in-out,cubic-bezier(0.400,0.000,0.200,1.000),cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-off-canvas .x-off-canvas-close {width:calc(1em * 2);height:calc(1em * 2);font-size:1.5em;color:rgba(0,0,0,0.5);transition-duration:0.3s,500ms,500ms;transition-timing-function:ease-in-out,cubic-bezier(0.400,0.000,0.200,1.000),cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-off-canvas .x-off-canvas-close:hover,.e7308-18.x-off-canvas .x-off-canvas-close:focus {color:rgb(243,109,33);}.e7308-25.x-off-canvas .x-off-canvas-close:hover,.e7308-25.x-off-canvas .x-off-canvas-close:focus {color:rgba(0,0,0,1);}.e7308-18.x-off-canvas .x-off-canvas-content {max-width:24em;padding:calc(2em * 2);background-color:#ffffff;box-shadow:0em 0em 2em 0em rgba(0,0,0,0.25);transition-duration:500ms;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-off-canvas .x-off-canvas-content {max-width:24em;padding:calc(1.5em * 2);background-color:#ffffff;box-shadow:0em 0em 2em 0em rgba(0,0,0,0.25);transition-duration:500ms;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-menu {font-size:0.9em;}.e7308-25.x-menu {font-size:1em;}.e7308-18.x-menu-layered,.e7308-18.x-menu-layered .x-anchor {transition-duration:300ms;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-menu-layered,.e7308-25.x-menu-layered .x-anchor {transition-duration:300ms;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-18.x-menu .x-anchor {font-size:1em;}.e7308-25.x-menu .x-anchor {font-size:1em;}.e7308-18.x-menu .x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;padding:0.5em 0.5em 0.5em 0.5em;}.e7308-25.x-menu .x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;padding:0.5em 0.5em 0.5em 0.5em;}.e7308-18.x-menu .x-anchor .x-anchor-text {margin:5px auto 5px 5px;}.e7308-25.x-menu .x-anchor .x-anchor-text {margin:5px auto 5px 5px;}.e7308-18.x-menu .x-anchor .x-anchor-text-primary {font-family:"dunbar-text",sans-serif;font-size:1em;font-style:normal;font-weight:500;line-height:1.4;color:rgba(0,0,0,1);}.e7308-25.x-menu .x-anchor .x-anchor-text-primary {font-family:"dunbar-text",sans-serif;font-size:0.9em;font-style:normal;font-weight:500;line-height:1;color:rgba(0,0,0,1);}.e7308-18.x-menu .x-anchor:hover .x-anchor-text-primary,.e7308-18.x-menu .x-anchor[class*="active"] .x-anchor-text-primary,[data-x-effect-provider*="colors"]:hover .e7308-18.x-menu .x-anchor .x-anchor-text-primary {color:rgb(243,109,33);}.e7308-25.x-menu .x-anchor:hover .x-anchor-text-primary,.e7308-25.x-menu .x-anchor[class*="active"] .x-anchor-text-primary,[data-x-effect-provider*="colors"]:hover .e7308-25.x-menu .x-anchor .x-anchor-text-primary {color:rgb(243,109,33);}.e7308-18.x-menu .x-anchor .x-anchor-text-secondary {margin-top:0.35em;font-family:inherit;font-size:0.75em;font-style:normal;font-weight:400;line-height:1;color:rgba(0,0,0,1);}.e7308-25.x-menu .x-anchor .x-anchor-text-secondary {margin-top:0.35em;font-family:inherit;font-size:0.75em;font-style:normal;font-weight:400;line-height:1;color:rgba(0,0,0,1);}.e7308-18.x-menu .x-anchor:hover .x-anchor-text-secondary,.e7308-18.x-menu .x-anchor[class*="active"] .x-anchor-text-secondary,[data-x-effect-provider*="colors"]:hover .e7308-18.x-menu .x-anchor .x-anchor-text-secondary {color:rgba(0,0,0,0.5);}.e7308-25.x-menu .x-anchor:hover .x-anchor-text-secondary,.e7308-25.x-menu .x-anchor[class*="active"] .x-anchor-text-secondary,[data-x-effect-provider*="colors"]:hover .e7308-25.x-menu .x-anchor .x-anchor-text-secondary {color:rgba(0,0,0,0.5);}.e7308-18.x-menu .x-anchor .x-anchor-sub-indicator {margin:5px;font-size:1em;color:rgba(0,0,0,1);}.e7308-25.x-menu .x-anchor .x-anchor-sub-indicator {margin:5px;font-size:1em;color:rgba(0,0,0,1);}.e7308-18.x-menu .x-anchor:hover .x-anchor-sub-indicator,.e7308-18.x-menu .x-anchor[class*="active"] .x-anchor-sub-indicator,[data-x-effect-provider*="colors"]:hover .e7308-18.x-menu .x-anchor .x-anchor-sub-indicator {color:rgba(0,0,0,0.5);}.e7308-25.x-menu .x-anchor:hover .x-anchor-sub-indicator,.e7308-25.x-menu .x-anchor[class*="active"] .x-anchor-sub-indicator,[data-x-effect-provider*="colors"]:hover .e7308-25.x-menu .x-anchor .x-anchor-sub-indicator {color:rgb(243,109,33);}.e7308-18.x-menu .x-anchor,.e7308-18.x-menu .x-anchor :not([data-x-particle]) {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-25.x-menu .x-anchor,.e7308-25.x-menu .x-anchor :not([data-x-particle]) {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-4.x-search {width:55%;max-width:none;height:auto;border-width:0.5px;border-style:solid;border-color:transparent;border-radius:50em 50em 50em 50em;font-size:1em;background-color:rgba(56,73,103,0.08);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-9.x-search {width:40%;max-width:none;height:auto;border-width:0.5px;border-style:solid;border-color:transparent;border-radius:50em 50em 50em 50em;font-size:1em;background-color:rgba(56,73,103,0.08);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-17.x-search {width:65%;max-width:none;height:auto;border-width:0.5px;border-style:solid;border-color:transparent;border-radius:50em 50em 50em 50em;font-size:1em;background-color:rgba(56,73,103,0.08);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-28.x-search {width:100%;max-width:none;height:auto;border-width:0.5px;border-style:solid;border-color:transparent;border-radius:100em;font-size:1em;background-color:rgb(244,244,244);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-4.x-search.x-search-focused {border-color:rgb(61,61,61);background-color:#ffffff;}.e7308-9.x-search.x-search-focused {border-color:rgb(61,61,61);background-color:#ffffff;}.e7308-17.x-search.x-search-focused {border-color:rgb(61,61,61);background-color:#ffffff;}.e7308-28.x-search.x-search-focused {border-color:rgb(72,72,72);background-color:rgb(255,255,255);}.e7308-4.x-search .x-search-input {order:2;margin:0px;font-family:inherit;font-size:0.9em;font-style:normal;font-weight:400;line-height:1.3;color:rgba(0,0,0,0.5);}.e7308-9.x-search .x-search-input {order:2;margin:0px;font-family:inherit;font-size:0.9em;font-style:normal;font-weight:400;line-height:1.3;color:rgba(0,0,0,0.5);}.e7308-17.x-search .x-search-input {order:2;margin:0px;font-family:inherit;font-size:0.9em;font-style:normal;font-weight:400;line-height:1.3;color:rgba(0,0,0,0.5);}.e7308-28.x-search .x-search-input {order:2;margin:0px;font-family:inherit;font-size:1em;font-style:normal;font-weight:400;line-height:1.3;color:rgba(0,0,0,0.5);}.e7308-4.x-search.x-search-has-content .x-search-input {color:rgba(0,0,0,1);}.e7308-9.x-search.x-search-has-content .x-search-input {color:rgba(0,0,0,1);}.e7308-17.x-search.x-search-has-content .x-search-input {color:rgba(0,0,0,1);}.e7308-28.x-search.x-search-has-content .x-search-input {color:rgba(0,0,0,1);}.e7308-4.x-search .x-search-btn-submit {order:1;width:1em;height:1em;margin:0.5em 0.5em 0.5em 0.9em;font-size:1em;color:rgba(0,0,0,1);}.e7308-9.x-search .x-search-btn-submit {order:1;width:1em;height:1em;margin:0.5em 0.5em 0.5em 0.9em;font-size:1em;color:rgba(0,0,0,1);}.e7308-17.x-search .x-search-btn-submit {order:1;width:1em;height:1em;margin:0.5em 0.5em 0.5em 0.9em;font-size:1em;color:rgba(0,0,0,1);}.e7308-28.x-search .x-search-btn-submit {order:1;width:1em;height:1em;margin:0.5em 0.5em 0.5em 0.9em;font-size:1em;color:rgba(0,0,0,1);}.e7308-4.x-search .x-search-btn-clear {order:3;width:2em;height:2em;margin:0.5em;border-radius:100em;font-size:0.9em;color:rgba(255,255,255,1);background-color:rgba(0,0,0,0.25);}.e7308-9.x-search .x-search-btn-clear {order:3;width:2em;height:2em;margin:0.5em;border-radius:100em;font-size:0.9em;color:rgba(255,255,255,1);background-color:rgba(0,0,0,0.25);}.e7308-17.x-search .x-search-btn-clear {order:3;width:2em;height:2em;margin:0.5em;border-radius:100em;font-size:0.9em;color:rgba(255,255,255,1);background-color:rgba(0,0,0,0.25);}.e7308-28.x-search .x-search-btn-clear {order:3;width:2em;height:2em;margin:0.5em;border-radius:100em;font-size:0.9em;color:rgba(255,255,255,1);background-color:rgba(0,0,0,0.25);}.e7308-4.x-search .x-search-btn-clear:hover,.e7308-4.x-search .x-search-btn-clear:focus {background-color:rgba(0,0,0,0.3);}.e7308-9.x-search .x-search-btn-clear:hover,.e7308-9.x-search .x-search-btn-clear:focus {background-color:rgba(0,0,0,0.3);}.e7308-17.x-search .x-search-btn-clear:hover,.e7308-17.x-search .x-search-btn-clear:focus {background-color:rgba(0,0,0,0.3);}.e7308-28.x-search .x-search-btn-clear:hover,.e7308-28.x-search .x-search-btn-clear:focus {background-color:rgba(0,0,0,0.3);}.e7308-5.x-widget-area {font-size:16px;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-10.x-widget-area {font-size:16px;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7308-5.x-widget-area .widget:not(:first-child) {margin:2.5rem 0 0;}.e7308-10.x-widget-area .widget:not(:first-child) {margin:2.5rem 0 0;}.e7308-5.x-widget-area .widget .h-widget {margin:0 0 0.5em;}.e7308-10.x-widget-area .widget .h-widget {margin:0 0 0.5em;}.e7497-1.x-bar {height:auto;padding:4.5em 0em 4.5em 0em;font-size:16px;background-color:rgb(110,5,6);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-5.x-bar {height:auto;padding:6em 0em 0em 0em;font-size:16px;background-color:rgb(242,242,242);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-8.x-bar {height:auto;padding:4em 0em 4em 0em;font-size:16px;background-color:rgb(242,242,242);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-15.x-bar {height:auto;font-size:16px;background-color:rgb(242,242,242);z-index:9999;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-1.x-bar-content {flex-direction:column;justify-content:center;align-items:center;flex:0 1 100%;height:auto;}.e7497-5.x-bar-content {flex-direction:row;justify-content:flex-start;align-items:flex-start;flex-wrap:wrap;align-content:flex-start;flex:0 1 100%;height:auto;max-width:1200px;}.e7497-8.x-bar-content {flex-direction:column;justify-content:flex-start;align-items:flex-start;flex:0 1 100%;height:auto;max-width:1200px;}.e7497-15.x-bar-content {flex-direction:column;justify-content:center;align-items:flex-start;flex:0 1 100%;height:auto;max-width:1200px;}.e7497-1.x-bar-outer-spacers:before,.e7497-1.x-bar-outer-spacers:after {flex-basis:2em;width:2em !important;height:2em;}.e7497-5.x-bar-outer-spacers:before,.e7497-5.x-bar-outer-spacers:after {flex-basis:4em;width:4em !important;height:4em;}.e7497-8.x-bar-outer-spacers:before,.e7497-8.x-bar-outer-spacers:after {flex-basis:4em;width:4em !important;height:4em;}.e7497-15.x-bar-outer-spacers:before,.e7497-15.x-bar-outer-spacers:after {flex-basis:4em;width:4em !important;height:4em;}.e7497-1.x-bar-space {font-size:16px;}.e7497-5.x-bar-space {font-size:16px;}.e7497-8.x-bar-space {font-size:16px;}.e7497-15.x-bar-space {font-size:16px;}.e7497-1.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-5.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-8.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-15.x-bar .x-bar-scroll-button {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-4.x-anchor {border-width:1px;border-style:solid;border-color:rgb(255,255,255);border-radius:0.15em 0.15em 0.15em 0.15em;font-size:1em;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-4.x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;padding:0.575em 1.25em 0.575em 1.25em;}.e7497-4.x-anchor:hover,.e7497-4.x-anchor[class*="active"],[data-x-effect-provider*="colors"]:hover .e7497-4.x-anchor {border-color:rgb(253,182,30);}.e7497-4.x-anchor .x-anchor-text {margin:5px;}.e7497-4.x-anchor .x-anchor-text-primary {font-family:"dunbar-text",sans-serif;font-size:0.9em;font-style:normal;font-weight:500;line-height:1;text-transform:uppercase;color:rgb(255,255,255);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-4.x-anchor:hover .x-anchor-text-primary,.e7497-4.x-anchor[class*="active"] .x-anchor-text-primary,[data-x-effect-provider*="colors"]:hover .e7497-4.x-anchor .x-anchor-text-primary {color:rgb(253,182,30);}.e7497-4.x-anchor .x-anchor-text-secondary {margin-top:0.35em;font-family:inherit;font-size:0.75em;font-style:normal;font-weight:400;line-height:1;color:rgba(0,0,0,1);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-4.x-anchor:hover .x-anchor-text-secondary,.e7497-4.x-anchor[class*="active"] .x-anchor-text-secondary,[data-x-effect-provider*="colors"]:hover .e7497-4.x-anchor .x-anchor-text-secondary {color:rgba(0,0,0,0.5);}.e7497-4.x-anchor .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-2.x-bar-container {flex-direction:column;justify-content:center;align-items:center;flex-wrap:wrap;align-content:center;flex:1 0 auto;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-6.x-bar-container {flex-direction:column;justify-content:center;align-items:flex-start;flex-wrap:wrap;align-content:flex-start;flex:0 1 auto;max-width:70%;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-9.x-bar-container {flex-direction:column;justify-content:center;align-items:flex-start;flex-wrap:wrap;align-content:flex-start;flex:0 1 auto;padding:0px 0px 40px 0px;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-11.x-bar-container {flex-direction:row;justify-content:space-between;align-items:center;flex:0 1 auto;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-16.x-bar-container {flex-direction:column;justify-content:center;align-items:center;flex:1 0 auto;max-height:50px;z-index:auto;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-3.x-text {padding:0em 0em 1.5em 0em;font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-7.x-text {font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-10.x-text {font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-3.x-text .x-text-content-text-primary {font-family:"dunbar-tall",sans-serif;font-size:1.4em;font-style:normal;font-weight:600;line-height:1.2;letter-spacing:0em;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:rgb(255,255,255);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-7.x-text .x-text-content-text-primary {font-family:"dunbar-tall",sans-serif;font-size:1.4em;font-style:normal;font-weight:600;line-height:1.8;letter-spacing:0em;margin-right:calc(0em * -1);text-transform:none;color:rgb(116,116,116);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-10.x-text .x-text-content-text-primary {font-family:"dunbar-text",sans-serif;font-size:1.2em;font-style:normal;font-weight:500;line-height:1.4;letter-spacing:0em;margin-right:calc(0em * -1);text-transform:none;color:rgb(157,157,157);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-3.x-text .x-text-content-text-subheadline {margin-top:0.15em;font-family:"dunbar-text",sans-serif;font-size:1.2em;font-style:normal;font-weight:500;line-height:1.2;letter-spacing:0em;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:rgb(255,255,255);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-10.x-text .x-text-content-text-subheadline {margin-top:0.8em;font-family:"dunbar-text",sans-serif;font-size:1.4em;font-style:normal;font-weight:500;line-height:1;letter-spacing:0em;margin-right:calc(0em * -1);text-transform:none;color:rgb(150,149,149);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-7.x-text .x-text-content-text-subheadline {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-3.x-text .x-text-typing {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-7.x-text .x-text-typing {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-10.x-text .x-text-typing {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-3.x-text .x-typed-cursor {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-7.x-text .x-typed-cursor {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-10.x-text .x-typed-cursor {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-3.x-text .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-7.x-text .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-10.x-text .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-12.x-anchor {width:2em;height:2em;margin:0em 1em 0em 0em;border-radius:100em;font-size:0.9em;background-color:rgb(253,182,30);}.e7497-13.x-anchor {width:2em;height:2em;margin:0em 1em 0em 0em;border-radius:100em;font-size:0.9em;background-color:rgb(253,182,30);}.e7497-14.x-anchor {width:2em;height:2em;margin:0em 1em 0em 0em;border-radius:100em;font-size:0.9em;background-color:rgb(253,182,30);}.e7497-12.x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;}.e7497-13.x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;}.e7497-14.x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;}.e7497-12.x-anchor:hover,.e7497-12.x-anchor[class*="active"],[data-x-effect-provider*="colors"]:hover .e7497-12.x-anchor {background-color:rgb(243,109,33);}.e7497-13.x-anchor:hover,.e7497-13.x-anchor[class*="active"],[data-x-effect-provider*="colors"]:hover .e7497-13.x-anchor {background-color:rgb(243,109,33);}.e7497-14.x-anchor:hover,.e7497-14.x-anchor[class*="active"],[data-x-effect-provider*="colors"]:hover .e7497-14.x-anchor {background-color:rgb(243,109,33);}.e7497-12.x-anchor .x-graphic {margin:5px 5px 5px 5px;}.e7497-13.x-anchor .x-graphic {margin:5px 5px 5px 5px;}.e7497-14.x-anchor .x-graphic {margin:5px 5px 5px 5px;}.e7497-12.x-anchor .x-graphic-image {max-width:1.25em;}.e7497-13.x-anchor .x-graphic-image {max-width:1.25em;}.e7497-14.x-anchor .x-graphic-image {max-width:1.25em;}.e7497-17.x-text {padding:1em 0em 1em 0em;font-family:"dunbar-text",sans-serif;font-size:0.7em;font-style:normal;font-weight:500;line-height:1.4;letter-spacing:0em;text-transform:none;color:rgb(77,77,77);background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e7497-17.x-text > :first-child {margin-top:0;}.e7497-17.x-text > :last-child {margin-bottom:0;}.e1096-7.x-anchor {font-size:1em;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-7.x-anchor .x-anchor-content {flex-direction:row;justify-content:center;align-items:center;}.e1096-7.x-anchor .x-anchor-text {margin:5px;}.e1096-7.x-anchor .x-anchor-text-primary {font-family:"dunbar-text",sans-serif;font-size:1em;font-style:normal;font-weight:500;line-height:1;color:rgb(243,109,33);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-7.x-anchor:hover .x-anchor-text-primary,.e1096-7.x-anchor[class*="active"] .x-anchor-text-primary,[data-x-effect-provider*="colors"]:hover .e1096-7.x-anchor .x-anchor-text-primary {color:rgb(36,36,36);}.e1096-7.x-anchor .x-anchor-text-secondary {margin-top:0.35em;font-family:inherit;font-size:0.75em;font-style:normal;font-weight:400;line-height:1;color:rgba(0,0,0,1);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-7.x-anchor:hover .x-anchor-text-secondary,.e1096-7.x-anchor[class*="active"] .x-anchor-text-secondary,[data-x-effect-provider*="colors"]:hover .e1096-7.x-anchor .x-anchor-text-secondary {color:rgba(0,0,0,0.5);}.e1096-7 .x-dropdown {width:400px;font-size:14px;background-color:#ffffff;box-shadow:0em 0.15em 2em 0em rgba(0,0,0,0.15);transition-duration:500ms,500ms,0s;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-7 .x-dropdown:not(.x-active) {transition-delay:0s,0s,500ms;}.e1096-7.x-anchor .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-4.x-text {font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-4.x-text .x-text-content-text-primary {font-family:"dunbar-tall",sans-serif;font-size:1.6em;font-style:normal;font-weight:600;line-height:1.4;letter-spacing:0em;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:rgba(0,0,0,1);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-4.x-text .x-text-content-text-subheadline {margin-top:0.35em;font-family:"dunbar-text",sans-serif;font-size:1em;font-style:normal;font-weight:500;line-height:1.4;letter-spacing:0em;margin-right:calc(0em * -1);text-align:center;text-transform:none;color:rgba(0,0,0,1);transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-4.x-text .x-text-typing {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-4.x-text .x-typed-cursor {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-4.x-text .x-graphic-child {transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-6.x-col {display:flex;flex-direction:column;justify-content:flex-start;align-items:center;flex-wrap:wrap;align-content:center;z-index:1;font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-3.x-col {z-index:1;max-width:80%;font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-2.x-row {z-index:1;margin:0px auto 0px auto;padding:1px;font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-5.x-row {z-index:1;margin:0px auto 0px auto;padding:20px 0px 0px 0px;font-size:1em;background-color:transparent;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}.e1096-2 > .x-row-inner {flex-direction:row;justify-content:center;align-items:center;align-content:center;margin:calc(((1rem / 2) + 1px) * -1) calc(((1rem / 2) + 1px) * -1);}.e1096-5 > .x-row-inner {flex-direction:row;justify-content:flex-start;align-items:stretch;align-content:stretch;margin:calc((1rem / 2) * -1) calc((1rem / 2) * -1);}.e1096-2 > .x-row-inner > * {flex-grow:1;margin:calc(1rem / 2) calc(1rem / 2);}.e1096-5 > .x-row-inner > * {flex-grow:1;margin:calc(1rem / 2) calc(1rem / 2);}.e1096-1.x-section {margin:0px;padding:45px 0px 25px 0px;background-color:transparent;z-index:1;transition-timing-function:cubic-bezier(0.400,0.000,0.200,1.000);}@media (max-width:479.98px) {.e1096-2 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}.e1096-5 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}}@media (min-width:480px) and (max-width:766.98px) {.e1096-2 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}.e1096-5 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}}@media (min-width:767px) and (max-width:978.98px) {.e1096-2 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}.e1096-5 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}}@media (min-width:979px) and (max-width:1199.98px) {.e1096-2 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}.e1096-5 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}}@media (min-width:1200px) {.e1096-2 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}.e1096-5 > .x-row-inner > *:nth-child(1n - 0) {flex-basis:calc(100% - 1rem);}}.e1096-7 .x-dropdown{left:50%;margin-left:-200px !important;top:40px !important;}.entry-title{font-size:140%;line-height:1.4em;text-transform:none;letter-spacing:0;padding-top:40px;padding-bottom:40px;color:#f36d21;}.widget_nav_menu ul,.widget_nav_menu ul li,.widget_nav_menu ul li a,.widget ul li a,.widget_meta ul li,.widget_pages ul li,.widget ul,.widget ol,.widget ul li,.widget ol li{background:transparent;border:none;box-shadow:none;}.entry-wrap{box-shadow:none;border:none !important;}.single-post .entry-wrap{padding:0;}.x-sidebar{font-size:0.8em;}ul li{padding:5px 0px;}.x-iso-container-posts.cols-2 .entry-title{font-size:120%;padding-bottom:0px;}.x-iso-container-posts.cols-2 .entry-wrap{padding:0;}.x-iso-container-posts.cols-2 .more-link{font-size:90%;font-weight:500;}.x-iso-container-posts.cols-3 .entry-wrap{padding:1% 1%;}.x-iso-container-posts.cols-3 .entry-title{font-size:95%;}.entry-title{padding-top:20px;padding-bottom:10px;}.entry-content{font-size:0.9rem;}.x-iso-container-posts.cols-3 .more-link{font-size:80%;font-weight:400;}.x-pagination span.current{text-shadow:none !important;color:#fff;background-color:#ff2a13;box-shadow:none !important;}.x-pagination a,.x-pagination span{text-shadow:none !important;color:#bababa;background-color:#fff;border-radius:4px;box-shadow:none !important;}@media (min-width:768px){.single-post .entry-wrap{padding:0;max-width:600px;margin-left:125px;margin-right:125px;}}.blog header.x-header-landmark{max-width:100%;width:100%;}body{overflow-x:visible;}.entry-featured .entry-thumb:hover img{opacity:1;}.entry-featured .entry-thumb:before{display:none;}h1,.h1{margin-top:1em;font-size:170%;padding-bottom:20px;line-height:1.4;color:#000000;}h2,.h2{font-size:150%;line-height:1.4;padding-bottom:20px;color:#141414;}h3,.h3{font-size:140%;line-height:1.4;padding-bottom:20px;color:#565656;}h4,.h4{font-size:130%;line-height:1.2;padding-bottom:20px;color:#565656;}h5,.h5{font-size:120%;padding-bottom:10px;color:#565656;}h6,.h6{font-size:105%;padding-bottom:10px;color:#565656;text-transform:none;}blockquote{margin:2em 0;border:1px solid #000;border-right-color:rgb(242,242,242);border-right-style:solid;border-right-width:1px;border-left-color:rgb(242,242,242);border-left-style:solid;border-left-width:1px;border-left:0;border-right:0;padding:0.5em 0;font-size:125%;font-weight:400;line-height:1.4;}.blog .entry-content.excerpt p{display:none;}.search-results .entry-title a{font-size:18px;}@media (min-width:768px){.search-results .x-pagination{width:calc(70% - 5px);float:right;}}.search-results .entry-title a{font-size:18px;}@media (min-width:768px){.search-results .x-pagination{width:calc(70% - 5px);float:right;}}.search-results .x-main{width:100%;}.search-results .x-sidebar{display:none;}.search-results .entry-featured{display:none;}.search-results .hentry .entry-wrap{padding-top:0;padding-bottom:0;}.ubermenu-main-1882-primary-4{min-width:400px;}.wpcf7 [type="submit"]{color:#ffffff;border-color:#f36d21;background-color:#f36d21;text-shadow:none !important;}#nf-field-14{width:70%;}.mailchimp-popup-heading{color:#fff;font-size:32px;font-weight:600;}.mailchimp-popup-body{color:#fff;}#nf-label-field-15{color:#fff;font-weight:400;}.x-crumbs-link{text-transform:none !important;}.x-btn,.x-btn:hover,.button,.button:hover,[type="submit"],[type="submit"]:hover{text-shadow:none !important;}.my-accordion .x-accordion-inner h2,.my-accordion .x-accordion-heading .x-accordion-toggle{font-family:dunbar-tall,sans-serif !important;font-size:50px;}</style>
      <script id="cs-typekit-loader">(function(doc){
         var config = { kitId:'wzf7aig', async:true }
         
         var timer = setTimeout(function(){
           doc.documentElement.className = doc.documentElement.className.replace(/\bwf-loading\b/g,"") + " wf-inactive";
         }, 3000)
         
         var tk = doc.createElement("script")
         var loaded = false
         var firstScript = doc.getElementsByTagName("script")[0]
         
         doc.documentElement.className += " wf-loading"
         
         tk.src = 'https://use.typekit.net/' + config.kitId + '.js'
         tk.async = true
         tk.onload = tk.onreadystatechange = function(){
           if (loaded || this.readyState && this.readyState != "complete" && this.readyState != "loaded") return
           loaded = true
           clearTimeout(timer)
           try { Typekit.load(config) } catch(e){}
         }
         
         firstScript.parentNode.insertBefore(tk, firstScript)
         })(window.document)
      </script>
      <style type="text/css">.tk-dunbar-tall{font-family:"dunbar-tall",sans-serif;}.tk-dunbar-text{font-family:"dunbar-text",sans-serif;}</style>
      <style type="text/css">@font-face{font-family:tk-dunbar-tall-n6;src:url(https://use.typekit.net/af/fce1d7/00000000000000003b9aed3f/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff2"),url(https://use.typekit.net/af/fce1d7/00000000000000003b9aed3f/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff"),url(https://use.typekit.net/af/fce1d7/00000000000000003b9aed3f/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("opentype");font-weight:600;font-style:normal;font-display:auto;}@font-face{font-family:tk-dunbar-tall-n7;src:url(https://use.typekit.net/af/7dc4d8/00000000000000003b9aed40/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff2"),url(https://use.typekit.net/af/7dc4d8/00000000000000003b9aed40/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff"),url(https://use.typekit.net/af/7dc4d8/00000000000000003b9aed40/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("opentype");font-weight:700;font-style:normal;font-display:auto;}@font-face{font-family:tk-dunbar-tall-n8;src:url(https://use.typekit.net/af/d04a81/00000000000000003b9aed41/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n8&v=3) format("woff2"),url(https://use.typekit.net/af/d04a81/00000000000000003b9aed41/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n8&v=3) format("woff"),url(https://use.typekit.net/af/d04a81/00000000000000003b9aed41/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n8&v=3) format("opentype");font-weight:800;font-style:normal;font-display:auto;}@font-face{font-family:tk-dunbar-text-n5;src:url(https://use.typekit.net/af/c3df24/00000000000000003b9aed43/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n5&v=3) format("woff2"),url(https://use.typekit.net/af/c3df24/00000000000000003b9aed43/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n5&v=3) format("woff"),url(https://use.typekit.net/af/c3df24/00000000000000003b9aed43/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n5&v=3) format("opentype");font-weight:500;font-style:normal;font-display:auto;}@font-face{font-family:tk-dunbar-text-n6;src:url(https://use.typekit.net/af/ce1d8e/00000000000000003b9aed44/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff2"),url(https://use.typekit.net/af/ce1d8e/00000000000000003b9aed44/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff"),url(https://use.typekit.net/af/ce1d8e/00000000000000003b9aed44/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("opentype");font-weight:600;font-style:normal;font-display:auto;}@font-face{font-family:tk-dunbar-text-n7;src:url(https://use.typekit.net/af/48aab1/00000000000000003b9aed45/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff2"),url(https://use.typekit.net/af/48aab1/00000000000000003b9aed45/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff"),url(https://use.typekit.net/af/48aab1/00000000000000003b9aed45/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("opentype");font-weight:700;font-style:normal;font-display:auto;}@font-face{font-family:tk-dunbar-text-i5;src:url(https://use.typekit.net/af/4367f9/00000000000000003b9b4289/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=i5&v=3) format("woff2"),url(https://use.typekit.net/af/4367f9/00000000000000003b9b4289/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=i5&v=3) format("woff"),url(https://use.typekit.net/af/4367f9/00000000000000003b9b4289/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=i5&v=3) format("opentype");font-weight:500;font-style:italic;font-display:auto;}</style>
      <style type="text/css">@font-face{font-family:dunbar-tall;src:url(https://use.typekit.net/af/fce1d7/00000000000000003b9aed3f/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff2"),url(https://use.typekit.net/af/fce1d7/00000000000000003b9aed3f/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff"),url(https://use.typekit.net/af/fce1d7/00000000000000003b9aed3f/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("opentype");font-weight:600;font-style:normal;font-display:auto;}@font-face{font-family:dunbar-tall;src:url(https://use.typekit.net/af/7dc4d8/00000000000000003b9aed40/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff2"),url(https://use.typekit.net/af/7dc4d8/00000000000000003b9aed40/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff"),url(https://use.typekit.net/af/7dc4d8/00000000000000003b9aed40/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("opentype");font-weight:700;font-style:normal;font-display:auto;}@font-face{font-family:dunbar-tall;src:url(https://use.typekit.net/af/d04a81/00000000000000003b9aed41/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n8&v=3) format("woff2"),url(https://use.typekit.net/af/d04a81/00000000000000003b9aed41/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n8&v=3) format("woff"),url(https://use.typekit.net/af/d04a81/00000000000000003b9aed41/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n8&v=3) format("opentype");font-weight:800;font-style:normal;font-display:auto;}@font-face{font-family:dunbar-text;src:url(https://use.typekit.net/af/c3df24/00000000000000003b9aed43/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n5&v=3) format("woff2"),url(https://use.typekit.net/af/c3df24/00000000000000003b9aed43/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n5&v=3) format("woff"),url(https://use.typekit.net/af/c3df24/00000000000000003b9aed43/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n5&v=3) format("opentype");font-weight:500;font-style:normal;font-display:auto;}@font-face{font-family:dunbar-text;src:url(https://use.typekit.net/af/ce1d8e/00000000000000003b9aed44/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff2"),url(https://use.typekit.net/af/ce1d8e/00000000000000003b9aed44/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("woff"),url(https://use.typekit.net/af/ce1d8e/00000000000000003b9aed44/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n6&v=3) format("opentype");font-weight:600;font-style:normal;font-display:auto;}@font-face{font-family:dunbar-text;src:url(https://use.typekit.net/af/48aab1/00000000000000003b9aed45/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff2"),url(https://use.typekit.net/af/48aab1/00000000000000003b9aed45/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("woff"),url(https://use.typekit.net/af/48aab1/00000000000000003b9aed45/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3) format("opentype");font-weight:700;font-style:normal;font-display:auto;}@font-face{font-family:dunbar-text;src:url(https://use.typekit.net/af/4367f9/00000000000000003b9b4289/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=i5&v=3) format("woff2"),url(https://use.typekit.net/af/4367f9/00000000000000003b9b4289/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=i5&v=3) format("woff"),url(https://use.typekit.net/af/4367f9/00000000000000003b9b4289/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=i5&v=3) format("opentype");font-weight:500;font-style:italic;font-display:auto;}</style>
   </head>
   <body class="page-template page-template-page-search-engine-simulator page-template-page-search-engine-simulator-php page page-id-1096 page-child parent-pageid-858 x-integrity x-integrity-light x-child-theme-active x-full-width-layout-active x-content-sidebar-active x-post-meta-disabled pro-v4_2_3">
      <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KZ7KXP"
         height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
      <div id="x-root" class="x-root lazyloaded">
         <div id="x-site" class="x-site site lazyloaded">
            <header class="x-masthead" role="banner">
               <div class="e7308-1 x-bar-space x-bar-space-top  x-hide-lg x-hide-md x-hide-sm x-hide-xs x-bar-space-h" style="display: none;"></div>
               <div class="e7308-1 x-bar x-bar-top x-bar-h x-bar-relative x-bar-is-sticky x-hide-lg x-hide-md x-hide-sm x-hide-xs x-bar-outer-spacers lazyloaded" data-x-bar="{&quot;id&quot;:&quot;e7308-1&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;6em&quot;,&quot;triggerOffset&quot;:&quot;0&quot;,&quot;shrink&quot;:&quot;1&quot;}" style="">
                  <div class="e7308-1 x-bar-content lazyloaded" style="">
                     <div class="e7308-2 x-bar-container lazyloaded">
                        <a class="e7308-3 x-image" href="https://totheweb.com/home">
                           <img src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/ToTheWeb-Site-Logo.png" width="225" height="85" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" loading="lazy" class=" lazyloaded">
                           <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" width="225" height="85" alt="Image"  data-eio="l"></noscript>
                        </a>
                        <form class="e7308-4 x-search" data-x-search="{&quot;search&quot;:true}" action="https://totheweb.com/" method="get">
                           <label class="visually-hidden" for="s-e7308-4">Search</label> <input id="s-e7308-4" class="x-search-input" type="search" name="s" value="" tabindex="0" placeholder="Go ahead, search our site"> 
                           <button class="x-search-btn x-search-btn-submit" type="button" data-x-search-submit="" tabindex="0">
                              <span class="visually-hidden">Submit</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <circle fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" cx="10" cy="10" r="9" stroke-linejoin="miter"></circle>
                                 <line fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" x1="22" y1="22" x2="16.4" y2="16.4" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                           <button class="x-search-btn x-search-btn-clear" type="button" data-x-search-clear="" tabindex="0">
                              <span class="visually-hidden">Clear</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="5" x2="5" y2="19" stroke-linejoin="miter"></line>
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="19" x2="5" y2="5" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                        </form>
                        <div class="e7308-5 x-widget-area lazyloaded">
                           <div id="ubermenu_navigation_widget-2" class="widget ubermenu_navigation_widget-class lazyloaded">
                              <button class="ubermenu-responsive-toggle ubermenu-responsive-toggle-main ubermenu-skin-vanilla ubermenu-loc-primary ubermenu-responsive-toggle-content-align-left ubermenu-responsive-toggle-align-full " tabindex="0" data-ubermenu-target="ubermenu-main-1882-primary-2">
                                 <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-bars">
                                    <svg class="ubermenu-icon-svg-bars">
                                       <use xlink:href="#ubermenu-icon-bars"></use>
                                    </svg>
                                 </span>
                                 Menu
                              </button>
                              <nav id="ubermenu-main-1882-primary-2" class="ubermenu ubermenu-main ubermenu-menu-1882 ubermenu-loc-primary ubermenu-responsive ubermenu-responsive-default ubermenu-mobile-modal ubermenu-responsive-collapse ubermenu-horizontal ubermenu-transition-slide ubermenu-trigger-hover_intent ubermenu-skin-vanilla ubermenu-bar-align-full ubermenu-items-align-auto ubermenu-sub-indicators ubermenu-retractors-responsive ubermenu-submenu-indicator-closes ubermenu-notouch ubermenu-desktop-view ubermenu-interaction-hover">
                                 <ul id="ubermenu-nav-main-1882-primary" class="ubermenu-nav" data-title="New Primary Menu">
                                    <li id="menu-item-6954" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-has-children ubermenu-item-6954 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto ubermenu-has-submenu-drop ubermenu-has-submenu-mega">
                                       <a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/" tabindex="0">
                                          <span class="ubermenu-target-title ubermenu-target-text">Services</span>
                                          <span class="ubermenu-sub-indicator">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-angle">
                                                <svg class="ubermenu-icon-svg-angle">
                                                   <use xlink:href="#ubermenu-icon-angle"></use>
                                                </svg>
                                             </span>
                                          </span>
                                          <span class="ubermenu-sub-indicator-close">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                                <svg class="ubermenu-icon-svg-times">
                                                   <use xlink:href="#ubermenu-icon-times"></use>
                                                </svg>
                                             </span>
                                          </span>
                                       </a>
                                       <ul class="ubermenu-submenu ubermenu-submenu-id-6954 ubermenu-submenu-type-auto ubermenu-submenu-type-mega ubermenu-submenu-drop ubermenu-submenu-align-full_width">
                                          <li id="menu-item-6955" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6955 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-image_above" href="https://totheweb.com/services/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="Services-Menu-BG" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="Services-Menu-BG" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">OVERVIEW</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Search engine marketing might be complex, but the reason for doing it—and doing it well—is simple.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6956 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6956">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6956 ubermenu-submenu-type-stack">
                                                <li id="menu-item-6957" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6957 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/increase-website-lead-generation/"><span class="ubermenu-target-title ubermenu-target-text">B2B Website Lead Generation</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Improve landing pages, monitor activity and escalate conversions.</span></a></li>
                                                <li id="menu-item-6963" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6963 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/keyword-research-reference-guide/"><span class="ubermenu-target-title ubermenu-target-text">B2B Keyword Research</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Drive SEO and SEM efforts across all content and social media networks.</span></a></li>
                                                <li id="menu-item-6960" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6960 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/search-engine-optimization/"><span class="ubermenu-target-title ubermenu-target-text">B2B Search Engine Optimization</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Ranking high in Google requires both onsite and off optimization.</span></a></li>
                                                <li id="menu-item-6962" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6962 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/website-review-and-competitive-analysis-html/"><span class="ubermenu-target-title ubermenu-target-text">B2B SEO Technical Audit</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">An in-depth technical analysis is part of a successful SEO strategy.</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6958 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6958">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6958 ubermenu-submenu-type-stack">
                                                <li id="menu-item-6961" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6961 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/search-engine-advertising/"><span class="ubermenu-target-title ubermenu-target-text">B2B Paid Media</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Online advertising in search, display and remarketing generates a steady flow of pipeline leads.</span></a></li>
                                                <li id="menu-item-6964" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6964 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/b2b-account-based-marketing/"><span class="ubermenu-target-title ubermenu-target-text">Account Based Marketing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">A better way for B2B enterprises with long sales cycles to laser-focus their resources.</span></a></li>
                                                <li id="menu-item-7024" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7024 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/b2b-content-audit-services/"><span class="ubermenu-target-title ubermenu-target-text">B2B Content Audit</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">When you need to know what is and isn’t working.</span></a></li>
                                                <li id="menu-item-6966" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6966 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/web-content-marketing-strategy/"><span class="ubermenu-target-title ubermenu-target-text">B2B Content Marketing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Adding value: content is what your prospects are actually searching for.</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6965 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6965">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6965 ubermenu-submenu-type-stack">
                                                <li id="menu-item-6969" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6969 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/website-usability-testing/"><span class="ubermenu-target-title ubermenu-target-text">B2B Usability &amp; User Testing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Learn how site visitors interact with your site.</span></a></li>
                                                <li id="menu-item-6970" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6970 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/b2b-marketing-get-social/"><span class="ubermenu-target-title ubermenu-target-text">B2B Social Media Marketing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Multiply your ROI in social media marketing with our tactics.</span></a></li>
                                                <li id="menu-item-6967" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6967 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/building-search-engine-link-popularity/"><span class="ubermenu-target-title ubermenu-target-text">B2B Building Link Popularity</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Measures of what really matters to search engines – authority links.</span></a></li>
                                                <li id="menu-item-7279" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-7279 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/#pricing"><span class="ubermenu-target-title ubermenu-target-text">Pricing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Outsourcing brings the best talent!</span></a></li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </li>
                                    <li id="menu-item-6972" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-current-menu-ancestor ubermenu-item-has-children ubermenu-item-6972 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto ubermenu-has-submenu-drop ubermenu-has-submenu-mega">
                                       <a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" tabindex="0">
                                          <span class="ubermenu-target-title ubermenu-target-text">Tools and Blog</span>
                                          <span class="ubermenu-sub-indicator">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-angle">
                                                <svg class="ubermenu-icon-svg-angle">
                                                   <use xlink:href="#ubermenu-icon-angle"></use>
                                                </svg>
                                             </span>
                                          </span>
                                          <span class="ubermenu-sub-indicator-close">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                                <svg class="ubermenu-icon-svg-times">
                                                   <use xlink:href="#ubermenu-icon-times"></use>
                                                </svg>
                                             </span>
                                          </span>
                                       </a>
                                       <ul class="ubermenu-submenu ubermenu-submenu-id-6972 ubermenu-submenu-type-auto ubermenu-submenu-type-mega ubermenu-submenu-drop ubermenu-submenu-align-full_width">
                                          <li id="menu-item-6971" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-current-page-ancestor ubermenu-current-page-parent ubermenu-item-6971 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-image_above" href="https://totheweb.com/learning_center/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="ToolsMenu-Header" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="ToolsMenu-Header" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">TOOLS</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">From tracking conversions to seeing what Google sees, expand your knowledge and grow your results.</span>
                                             </a>
                                          </li>
                                          <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-current-menu-ancestor ubermenu-current-menu-parent ubermenu-item-has-children ubermenu-item-6974 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6974">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6974 ubermenu-submenu-type-stack">
                                                <li id="menu-item-7281" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-7281 ubermenu-item-header ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><span class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only"><span class="ubermenu-target-title ubermenu-target-text">TRY OUR MARKETING TOOLS</span></span></li>
                                                <li id="menu-item-6978" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6978 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tool-test-google-title-meta-description-lengths/"><span class="ubermenu-target-title ubermenu-target-text">Google Meta Description Tester</span></a></li>
                                                <li id="menu-item-6977" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6977 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tool-keyword-topic-page-theme-finder/"><span class="ubermenu-target-title ubermenu-target-text">Find Keywords on Any Page</span></a></li>
                                                <li id="menu-item-6980" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-current-menu-item ubermenu-page_item ubermenu-page-item-1096 ubermenu-current_page_item ubermenu-item-6980 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto ubermenu-hide-mobile"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-search-engine-simulator/"><span class="ubermenu-target-title ubermenu-target-text">Search Engine Simulator</span></a></li>
                                                <li id="menu-item-6975" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6975 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/campaign-tracking-url-builder/"><span class="ubermenu-target-title ubermenu-target-text">Create Campaign Tracking URLs</span></a></li>
                                                <li id="menu-item-6976" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6976 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tool-calculate-ad-campaign-lead-cost-return-ad-spend-roas-cost-per-sale/"><span class="ubermenu-target-title ubermenu-target-text">Calculate Return on Ad Spend</span></a></li>
                                                <li id="menu-item-6979" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6979 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-convert-html-text-to-plain-text-for-content-review/"><span class="ubermenu-target-title ubermenu-target-text">Convert to Plain Text</span></a></li>
                                                <li id="menu-item-7013" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-current-page-ancestor ubermenu-current-page-parent ubermenu-item-7013 ubermenu-item-header ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/"><span class="ubermenu-target-title ubermenu-target-text">LEARN FROM PRESENTATIONS</span></a></li>
                                             </ul>
                                          </li>
                                          <li id="menu-item-7542" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-post ubermenu-item-7542 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-default ubermenu-item-layout-image_above" title="IMPROVE YOUR TRAFFIC" href="https://totheweb.com/blog/b2b-content-marketing/quick-wins-what-makes-a-great-b2b-blog-post/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="BlogMenu-Header" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="BlogMenu-Header" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">IMPROVE YOUR TRAFFIC</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Not all blogs are created equal. Some posts keep generating traffic month after month.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6984 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6984">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6984 ubermenu-submenu-type-stack">
                                                <li id="menu-item-6983" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-6983 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/blog/"><span class="ubermenu-target-title ubermenu-target-text">Explore our Blog</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Read our recent posts from Content Marketing to Lead Generation and Website Usability. You’ll learn how to improve landing pages, monitor activity and escalate conversion.</span></a></li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </li>
                                    <li id="menu-item-6986" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-has-children ubermenu-item-6986 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto ubermenu-has-submenu-drop ubermenu-has-submenu-mega">
                                       <a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" tabindex="0">
                                          <span class="ubermenu-target-title ubermenu-target-text">Why Choose Us</span>
                                          <span class="ubermenu-sub-indicator">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-angle">
                                                <svg class="ubermenu-icon-svg-angle">
                                                   <use xlink:href="#ubermenu-icon-angle"></use>
                                                </svg>
                                             </span>
                                          </span>
                                          <span class="ubermenu-sub-indicator-close">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                                <svg class="ubermenu-icon-svg-times">
                                                   <use xlink:href="#ubermenu-icon-times"></use>
                                                </svg>
                                             </span>
                                          </span>
                                       </a>
                                       <ul class="ubermenu-submenu ubermenu-submenu-id-6986 ubermenu-submenu-type-auto ubermenu-submenu-type-mega ubermenu-submenu-drop ubermenu-submenu-align-full_width">
                                          <li id="menu-item-6985" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6985 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-image_above" href="https://totheweb.com/about-us/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="About-Us-Menu-BG" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="About-Us-Menu-BG" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">WHY CHOOSE US</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">50% of B2B websites don’t generate sufficient new leads from their website — we solve that problem.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6989 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-8 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6989">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6989 ubermenu-submenu-type-stack">
                                                <li id="menu-item-6990" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6990 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/rosemary-brisco/"><span class="ubermenu-target-title ubermenu-target-text">Rosemary Brisco</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">President and Founder</span></a></li>
                                                <li id="menu-item-7002" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7002 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/michele-grey/"><span class="ubermenu-target-title ubermenu-target-text">Michele Grey</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Graphic and Web Designer</span></a></li>
                                                <li id="menu-item-7004" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7004 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/brandon-loya/"><span class="ubermenu-target-title ubermenu-target-text">Brandon Loya</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Wordpress Designer</span></a></li>
                                                <li id="menu-item-6993" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6993 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/dirk-frandsen/"><span class="ubermenu-target-title ubermenu-target-text">Dirk Frandsen</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Senior Designer</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-7000 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-8 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-7000">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-7000 ubermenu-submenu-type-stack">
                                                <li id="menu-item-6991" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6991 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/john-koh/"><span class="ubermenu-target-title ubermenu-target-text">John Koh</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Director of Paid Media</span></a></li>
                                                <li id="menu-item-6992" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6992 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/john-mcaulay/"><span class="ubermenu-target-title ubermenu-target-text">John McAulay</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">PHP Web Application Developer</span></a></li>
                                                <li id="menu-item-7003" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7003 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/michael-menduno/"><span class="ubermenu-target-title ubermenu-target-text">Michael Menduno</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Writer, journalist and editor</span></a></li>
                                             </ul>
                                          </li>
                                          <li id="menu-item-7006" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7006 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-default ubermenu-item-layout-image_above" href="https://totheweb.com/our_clients/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="Clients-Menu-BG" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="Clients-Menu-BG" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">OUR CLIENTS</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Creating highly measurable results for our clients increases their lead opportunities and grows profits.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-7008 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-7008">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-7008 ubermenu-submenu-type-stack">
                                                <li id="menu-item-7009" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7009 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/our_clients/all-clients/"><span class="ubermenu-target-title ubermenu-target-text">Clients by Industry</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">ToTheWeb serves global B2B software companies and drives more pipeline leads to sales.</span></a></li>
                                                <li id="menu-item-7011" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7011 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/our_clients/case-studies/"><span class="ubermenu-target-title ubermenu-target-text">Client Success Stories</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">B2B Companies Benefit From ToTheWeb’s Intensive PPC &amp; SEO Strategies</span></a></li>
                                                <li id="menu-item-7012" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7012 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/contact-us-2/"><span class="ubermenu-target-title ubermenu-target-text">Get in Touch</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">We listen.</span></a></li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </li>
                                 </ul>
                                 <div class="ubermenu-mobile-footer lazyload" aria-hidden="true">
                                    <button class="ubermenu-mobile-close-button ">
                                       <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                          <svg class="ubermenu-icon-svg-times">
                                             <use xlink:href="#ubermenu-icon-times"></use>
                                          </svg>
                                       </span>
                                       Close
                                    </button>
                                 </div>
                              </nav>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="e7308-6 x-bar-space x-bar-space-top  x-hide-md x-hide-sm x-hide-xl x-hide-xs x-bar-space-h" style="display: none;"></div>
               <div class="e7308-6 x-bar x-bar-top x-bar-h x-bar-relative x-bar-is-sticky  x-hide-md x-hide-sm x-hide-xl x-hide-xs x-bar-outer-spacers lazyload" data-x-bar="{&quot;id&quot;:&quot;e7308-6&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;6em&quot;,&quot;triggerOffset&quot;:&quot;0&quot;,&quot;shrink&quot;:&quot;1&quot;}">
                  <div class="e7308-6 x-bar-content lazyload">
                     <div class="e7308-7 x-bar-container lazyload">
                        <a class="e7308-8 x-image" href="https://totheweb.com/home">
                           <img src="data:image/svg+xml,%3Csvg xmlns=&#39;http://www.w3.org/2000/svg&#39; viewBox=&#39;0 0 225 85&#39;%3E%3C/svg%3E" width="225" height="85" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" loading="lazy" class="lazyload">
                           <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" width="225" height="85" alt="Image"  data-eio="l"></noscript>
                        </a>
                        <form class="e7308-9 x-search" data-x-search="{&quot;search&quot;:true}" action="https://totheweb.com/" method="get">
                           <label class="visually-hidden" for="s-e7308-9">Search</label> <input id="s-e7308-9" class="x-search-input" type="search" name="s" value="" tabindex="0" placeholder="Go ahead, search our site"> 
                           <button class="x-search-btn x-search-btn-submit" type="button" data-x-search-submit="" tabindex="0">
                              <span class="visually-hidden">Submit</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <circle fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" cx="10" cy="10" r="9" stroke-linejoin="miter"></circle>
                                 <line fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" x1="22" y1="22" x2="16.4" y2="16.4" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                           <button class="x-search-btn x-search-btn-clear" type="button" data-x-search-clear="" tabindex="0">
                              <span class="visually-hidden">Clear</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="5" x2="5" y2="19" stroke-linejoin="miter"></line>
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="19" x2="5" y2="5" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                        </form>
                        <div class="e7308-10 x-widget-area lazyload">
                           <div id="ubermenu_navigation_widget-2" class="widget ubermenu_navigation_widget-class lazyload">
                              <button class="ubermenu-responsive-toggle ubermenu-responsive-toggle-main ubermenu-skin-vanilla ubermenu-loc-primary ubermenu-responsive-toggle-content-align-left ubermenu-responsive-toggle-align-full " tabindex="0" data-ubermenu-target="ubermenu-main-1882-primary-4">
                                 <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-bars">
                                    <svg class="ubermenu-icon-svg-bars">
                                       <use xlink:href="#ubermenu-icon-bars"></use>
                                    </svg>
                                 </span>
                                 Menu
                              </button>
                              <nav id="ubermenu-main-1882-primary-4" class="ubermenu ubermenu-main ubermenu-menu-1882 ubermenu-loc-primary ubermenu-responsive ubermenu-responsive-default ubermenu-mobile-modal ubermenu-responsive-collapse ubermenu-horizontal ubermenu-transition-slide ubermenu-trigger-hover_intent ubermenu-skin-vanilla ubermenu-bar-align-full ubermenu-items-align-auto ubermenu-sub-indicators ubermenu-retractors-responsive ubermenu-submenu-indicator-closes ubermenu-notouch ubermenu-desktop-view">
                                 <ul id="ubermenu-nav-main-1882-primary" class="ubermenu-nav" data-title="New Primary Menu">
                                    <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-has-children ubermenu-item-6954 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto ubermenu-has-submenu-drop ubermenu-has-submenu-mega">
                                       <a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/" tabindex="0">
                                          <span class="ubermenu-target-title ubermenu-target-text">Services</span>
                                          <span class="ubermenu-sub-indicator">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-angle">
                                                <svg class="ubermenu-icon-svg-angle">
                                                   <use xlink:href="#ubermenu-icon-angle"></use>
                                                </svg>
                                             </span>
                                          </span>
                                          <span class="ubermenu-sub-indicator-close">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                                <svg class="ubermenu-icon-svg-times">
                                                   <use xlink:href="#ubermenu-icon-times"></use>
                                                </svg>
                                             </span>
                                          </span>
                                       </a>
                                       <ul class="ubermenu-submenu ubermenu-submenu-id-6954 ubermenu-submenu-type-auto ubermenu-submenu-type-mega ubermenu-submenu-drop ubermenu-submenu-align-full_width">
                                          <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6955 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-image_above" href="https://totheweb.com/services/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="Services-Menu-BG" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/Services-Menu-BG-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="Services-Menu-BG" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">OVERVIEW</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Search engine marketing might be complex, but the reason for doing it—and doing it well—is simple.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6956 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6956">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6956 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6957 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/increase-website-lead-generation/"><span class="ubermenu-target-title ubermenu-target-text">B2B Website Lead Generation</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Improve landing pages, monitor activity and escalate conversions.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6963 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/keyword-research-reference-guide/"><span class="ubermenu-target-title ubermenu-target-text">B2B Keyword Research</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Drive SEO and SEM efforts across all content and social media networks.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6960 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/search-engine-optimization/"><span class="ubermenu-target-title ubermenu-target-text">B2B Search Engine Optimization</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Ranking high in Google requires both onsite and off optimization.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6962 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/website-review-and-competitive-analysis-html/"><span class="ubermenu-target-title ubermenu-target-text">B2B SEO Technical Audit</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">An in-depth technical analysis is part of a successful SEO strategy.</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6958 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6958">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6958 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6961 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/search-engine-advertising/"><span class="ubermenu-target-title ubermenu-target-text">B2B Paid Media</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Online advertising in search, display and remarketing generates a steady flow of pipeline leads.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6964 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/b2b-account-based-marketing/"><span class="ubermenu-target-title ubermenu-target-text">Account Based Marketing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">A better way for B2B enterprises with long sales cycles to laser-focus their resources.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7024 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/b2b-content-audit-services/"><span class="ubermenu-target-title ubermenu-target-text">B2B Content Audit</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">When you need to know what is and isn’t working.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6966 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/web-content-marketing-strategy/"><span class="ubermenu-target-title ubermenu-target-text">B2B Content Marketing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Adding value: content is what your prospects are actually searching for.</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6965 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6965">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6965 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6969 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/website-usability-testing/"><span class="ubermenu-target-title ubermenu-target-text">B2B Usability &amp; User Testing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Learn how site visitors interact with your site.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6970 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/b2b-marketing-get-social/"><span class="ubermenu-target-title ubermenu-target-text">B2B Social Media Marketing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Multiply your ROI in social media marketing with our tactics.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6967 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/building-search-engine-link-popularity/"><span class="ubermenu-target-title ubermenu-target-text">B2B Building Link Popularity</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Measures of what really matters to search engines – authority links.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-7279 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/services/#pricing"><span class="ubermenu-target-title ubermenu-target-text">Pricing</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Outsourcing brings the best talent!</span></a></li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </li>
                                    <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-current-menu-ancestor ubermenu-item-has-children ubermenu-item-6972 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto ubermenu-has-submenu-drop ubermenu-has-submenu-mega">
                                       <a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" tabindex="0">
                                          <span class="ubermenu-target-title ubermenu-target-text">Tools and Blog</span>
                                          <span class="ubermenu-sub-indicator">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-angle">
                                                <svg class="ubermenu-icon-svg-angle">
                                                   <use xlink:href="#ubermenu-icon-angle"></use>
                                                </svg>
                                             </span>
                                          </span>
                                          <span class="ubermenu-sub-indicator-close">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                                <svg class="ubermenu-icon-svg-times">
                                                   <use xlink:href="#ubermenu-icon-times"></use>
                                                </svg>
                                             </span>
                                          </span>
                                       </a>
                                       <ul class="ubermenu-submenu ubermenu-submenu-id-6972 ubermenu-submenu-type-auto ubermenu-submenu-type-mega ubermenu-submenu-drop ubermenu-submenu-align-full_width">
                                          <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-current-page-ancestor ubermenu-current-page-parent ubermenu-item-6971 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-image_above" href="https://totheweb.com/learning_center/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="ToolsMenu-Header" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/ToolsMenu-Header-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="ToolsMenu-Header" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">TOOLS</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">From tracking conversions to seeing what Google sees, expand your knowledge and grow your results.</span>
                                             </a>
                                          </li>
                                          <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-current-menu-ancestor ubermenu-current-menu-parent ubermenu-item-has-children ubermenu-item-6974 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6974">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6974 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-7281 ubermenu-item-header ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><span class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only"><span class="ubermenu-target-title ubermenu-target-text">TRY OUR MARKETING TOOLS</span></span></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6978 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tool-test-google-title-meta-description-lengths/"><span class="ubermenu-target-title ubermenu-target-text">Google Meta Description Tester</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6977 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tool-keyword-topic-page-theme-finder/"><span class="ubermenu-target-title ubermenu-target-text">Find Keywords on Any Page</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-current-menu-item ubermenu-page_item ubermenu-page-item-1096 ubermenu-current_page_item ubermenu-item-6980 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto ubermenu-hide-mobile"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-search-engine-simulator/"><span class="ubermenu-target-title ubermenu-target-text">Search Engine Simulator</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6975 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/campaign-tracking-url-builder/"><span class="ubermenu-target-title ubermenu-target-text">Create Campaign Tracking URLs</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6976 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tool-calculate-ad-campaign-lead-cost-return-ad-spend-roas-cost-per-sale/"><span class="ubermenu-target-title ubermenu-target-text">Calculate Return on Ad Spend</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6979 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-convert-html-text-to-plain-text-for-content-review/"><span class="ubermenu-target-title ubermenu-target-text">Convert to Plain Text</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-current-page-ancestor ubermenu-current-page-parent ubermenu-item-7013 ubermenu-item-header ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/"><span class="ubermenu-target-title ubermenu-target-text">LEARN FROM PRESENTATIONS</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-post ubermenu-item-7542 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-default ubermenu-item-layout-image_above" title="IMPROVE YOUR TRAFFIC" href="https://totheweb.com/blog/b2b-content-marketing/quick-wins-what-makes-a-great-b2b-blog-post/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="BlogMenu-Header" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/BlogMenu-Header-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="BlogMenu-Header" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">IMPROVE YOUR TRAFFIC</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Not all blogs are created equal. Some posts keep generating traffic month after month.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6984 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6984">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6984 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-6983 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/blog/"><span class="ubermenu-target-title ubermenu-target-text">Explore our Blog</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Read our recent posts from Content Marketing to Lead Generation and Website Usability. You’ll learn how to improve landing pages, monitor activity and escalate conversion.</span></a></li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </li>
                                    <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-has-children ubermenu-item-6986 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto ubermenu-has-submenu-drop ubermenu-has-submenu-mega">
                                       <a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" tabindex="0">
                                          <span class="ubermenu-target-title ubermenu-target-text">Why Choose Us</span>
                                          <span class="ubermenu-sub-indicator">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-angle">
                                                <svg class="ubermenu-icon-svg-angle">
                                                   <use xlink:href="#ubermenu-icon-angle"></use>
                                                </svg>
                                             </span>
                                          </span>
                                          <span class="ubermenu-sub-indicator-close">
                                             <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                                <svg class="ubermenu-icon-svg-times">
                                                   <use xlink:href="#ubermenu-icon-times"></use>
                                                </svg>
                                             </span>
                                          </span>
                                       </a>
                                       <ul class="ubermenu-submenu ubermenu-submenu-id-6986 ubermenu-submenu-type-auto ubermenu-submenu-type-mega ubermenu-submenu-drop ubermenu-submenu-align-full_width">
                                          <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6985 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-image_above" href="https://totheweb.com/about-us/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="About-Us-Menu-BG" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/About-Us-Menu-BG-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="About-Us-Menu-BG" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">WHY CHOOSE US</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">50% of B2B websites don’t generate sufficient new leads from their website — we solve that problem.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-6989 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-8 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-6989">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-6989 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6990 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/rosemary-brisco/"><span class="ubermenu-target-title ubermenu-target-text">Rosemary Brisco</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">President and Founder</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7002 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/michele-grey/"><span class="ubermenu-target-title ubermenu-target-text">Michele Grey</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Graphic and Web Designer</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7004 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/brandon-loya/"><span class="ubermenu-target-title ubermenu-target-text">Brandon Loya</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Wordpress Designer</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6993 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/dirk-frandsen/"><span class="ubermenu-target-title ubermenu-target-text">Dirk Frandsen</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Senior Designer</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-7000 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-8 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-7000">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-7000 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6991 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/john-koh/"><span class="ubermenu-target-title ubermenu-target-text">John Koh</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Director of Paid Media</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6992 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/john-mcaulay/"><span class="ubermenu-target-title ubermenu-target-text">John McAulay</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">PHP Web Application Developer</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7003 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/michael-menduno/"><span class="ubermenu-target-title ubermenu-target-text">Michael Menduno</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Writer, journalist and editor</span></a></li>
                                             </ul>
                                          </li>
                                          <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7006 ubermenu-item-header ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4">
                                             <a class="ubermenu-target ubermenu-target-with-image ubermenu-item-layout-default ubermenu-item-layout-image_above" href="https://totheweb.com/our_clients/">
                                                <img class="ubermenu-image ubermenu-image-size-full lazyload" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/placeholder-500x400.png" width="500" height="400" alt="Clients-Menu-BG" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg" loading="lazy" data-srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-100x80.jpg 100w" data-sizes="auto">
                                                <noscript><img class="ubermenu-image ubermenu-image-size-full" src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg" srcset="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG.jpg 500w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-300x240.jpg 300w, https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2020/08/Clients-Menu-BG-100x80.jpg 100w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="400" alt="Clients-Menu-BG" data-eio="l" /></noscript>
                                                <span class="ubermenu-target-title ubermenu-target-text">OUR CLIENTS</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">Creating highly measurable results for our clients increases their lead opportunities and grows profits.</span>
                                             </a>
                                          </li>
                                          <li class="  ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-has-children ubermenu-item-7008 ubermenu-item-level-1 ubermenu-column ubermenu-column-1-4 ubermenu-has-submenu-stack ubermenu-item-type-column ubermenu-column-id-7008">
                                             <ul class="ubermenu-submenu ubermenu-submenu-id-7008 ubermenu-submenu-type-stack">
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7009 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/our_clients/all-clients/"><span class="ubermenu-target-title ubermenu-target-text">Clients by Industry</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">ToTheWeb serves global B2B software companies and drives more pipeline leads to sales.</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7011 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/our_clients/case-studies/"><span class="ubermenu-target-title ubermenu-target-text">Client Success Stories</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">B2B Companies Benefit From ToTheWeb’s Intensive PPC &amp; SEO Strategies</span></a></li>
                                                <li class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-7012 ubermenu-item-auto ubermenu-item-normal ubermenu-item-level-2 ubermenu-column ubermenu-column-auto"><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="https://totheweb.com/about-us/contact-us-2/"><span class="ubermenu-target-title ubermenu-target-text">Get in Touch</span><span class="ubermenu-target-divider"> – </span><span class="ubermenu-target-description ubermenu-target-text">We listen.</span></a></li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </li>
                                 </ul>
                                 <div class="ubermenu-mobile-footer lazyload" aria-hidden="true">
                                    <button class="ubermenu-mobile-close-button ">
                                       <span class="ubermenu-icon ubermenu-icon-essential ubermenu-icon-essential-times">
                                          <svg class="ubermenu-icon-svg-times">
                                             <use xlink:href="#ubermenu-icon-times"></use>
                                          </svg>
                                       </span>
                                       Close
                                    </button>
                                 </div>
                              </nav>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="e7308-11 x-bar x-bar-top x-bar-h x-bar-relative  x-hide-md x-hide-sm x-hide-xs x-bar-outer-spacers lazyloaded" data-x-bar="{&quot;id&quot;:&quot;e7308-11&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;4em&quot;}">
                  <div class="e7308-11 x-bar-content lazyloaded">
                     <div class="e7308-12 x-bar-container lazyloaded">
                        <nav class="e7308-13 x-crumbs" role="navigation">
                           <ol class="x-crumbs-list" itemscope="" itemtype="http://schema.org/BreadcrumbList" aria-label="Breadcrumb Navigation">
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/"><span itemprop="name"> <i class="e7308-13 x-icon" aria-hidden="true" data-x-icon-s=""></i> <span class="visually-hidden">Home</span></span></a><span class="x-crumbs-delimiter">→</span>
                                 <meta itemprop="position" content="1">
                              </li>
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/learning_center/"><span itemprop="name">B2B Search Marketing Tools &amp; Articles</span></a><span class="x-crumbs-delimiter">→</span>
                                 <meta itemprop="position" content="2">
                              </li>
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link x-crumbs-current" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/learning_center/tools-search-engine-simulator/" title="You Are Here"><span itemprop="name">Free Tool: Search Engine Simulator</span></a>
                                 <meta itemprop="position" content="3">
                              </li>
                           </ol>
                        </nav>
                     </div>
                  </div>
               </div>
               <div class="e7308-14 x-bar-space x-bar-space-top  x-hide-lg x-hide-xl x-hide-xs x-bar-space-h" style="display: none;"></div>
               <div class="e7308-14 x-bar x-bar-top x-bar-h x-bar-relative x-bar-is-sticky  x-hide-lg x-hide-xl x-hide-xs x-bar-outer-spacers lazyload" data-x-bar="{&quot;id&quot;:&quot;e7308-14&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;6em&quot;,&quot;triggerOffset&quot;:&quot;0&quot;,&quot;shrink&quot;:&quot;1&quot;}">
                  <div class="e7308-14 x-bar-content lazyload">
                     <div class="e7308-15 x-bar-container lazyload">
                        <a class="e7308-16 x-image" href="https://totheweb.com/home">
                           <img src="data:image/svg+xml,%3Csvg xmlns=&#39;http://www.w3.org/2000/svg&#39; viewBox=&#39;0 0 225 85&#39;%3E%3C/svg%3E" width="225" height="85" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" loading="lazy" class="lazyload">
                           <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" width="225" height="85" alt="Image"  data-eio="l"></noscript>
                        </a>
                        <form class="e7308-17 x-search" data-x-search="{&quot;search&quot;:true}" action="https://totheweb.com/" method="get">
                           <label class="visually-hidden" for="s-e7308-17">Search</label> <input id="s-e7308-17" class="x-search-input" type="search" name="s" value="" tabindex="0" placeholder="Go ahead, search our site"> 
                           <button class="x-search-btn x-search-btn-submit" type="button" data-x-search-submit="" tabindex="0">
                              <span class="visually-hidden">Submit</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <circle fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" cx="10" cy="10" r="9" stroke-linejoin="miter"></circle>
                                 <line fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" x1="22" y1="22" x2="16.4" y2="16.4" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                           <button class="x-search-btn x-search-btn-clear" type="button" data-x-search-clear="" tabindex="0">
                              <span class="visually-hidden">Clear</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="5" x2="5" y2="19" stroke-linejoin="miter"></line>
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="19" x2="5" y2="5" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                        </form>
                        <a class="e7308-18 x-anchor x-anchor-toggle has-graphic" tabindex="0" data-x-toggle="1" data-x-toggleable="e7308-18" data-x-toggle-overlay="1" aria-controls="e7308-18-off-canvas" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Off Canvas Content">
                           <div class="x-anchor-content lazyload"> <span class="x-graphic" aria-hidden="true"> <span class="x-toggle x-toggle-burger x-graphic-child x-graphic-toggle" aria-hidden="true"> <span class="x-toggle-burger-bun-t" data-x-toggle-anim="x-bun-t-1"></span> <span class="x-toggle-burger-patty" data-x-toggle-anim="x-patty-1"></span> <span class="x-toggle-burger-bun-b" data-x-toggle-anim="x-bun-b-1"></span> </span> </span></div>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="e7308-19 x-bar x-bar-top x-bar-h x-bar-relative  x-hide-lg x-hide-xl x-hide-xs x-bar-outer-spacers lazyload" data-x-bar="{&quot;id&quot;:&quot;e7308-19&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;3em&quot;}">
                  <div class="e7308-19 x-bar-content lazyload">
                     <div class="e7308-20 x-bar-container lazyload">
                        <nav class="e7308-21 x-crumbs" role="navigation">
                           <ol class="x-crumbs-list" itemscope="" itemtype="http://schema.org/BreadcrumbList" aria-label="Breadcrumb Navigation">
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/"><span itemprop="name"> <i class="e7308-21 x-icon" aria-hidden="true" data-x-icon-s=""></i> <span class="visually-hidden">Home</span></span></a><span class="x-crumbs-delimiter">→</span>
                                 <meta itemprop="position" content="1">
                              </li>
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/learning_center/"><span itemprop="name">B2B Search Marketing Tools &amp; Articles</span></a><span class="x-crumbs-delimiter">→</span>
                                 <meta itemprop="position" content="2">
                              </li>
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link x-crumbs-current" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/learning_center/tools-search-engine-simulator/" title="You Are Here"><span itemprop="name">Free Tool: Search Engine Simulator</span></a>
                                 <meta itemprop="position" content="3">
                              </li>
                           </ol>
                        </nav>
                     </div>
                  </div>
               </div>
               <div class="e7308-22 x-bar-space x-bar-space-top  x-hide-lg x-hide-md x-hide-sm x-hide-xl x-bar-space-h" style="display: none;"></div>
               <div class="e7308-22 x-bar x-bar-top x-bar-h x-bar-relative x-bar-is-sticky  x-hide-lg x-hide-md x-hide-sm x-hide-xl x-bar-outer-spacers lazyload" data-x-bar="{&quot;id&quot;:&quot;e7308-22&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;5em&quot;,&quot;triggerOffset&quot;:&quot;0&quot;,&quot;shrink&quot;:&quot;1&quot;}">
                  <div class="e7308-22 x-bar-content lazyload">
                     <div class="e7308-23 x-bar-container lazyload">
                        <a class="e7308-24 x-image" href="https://totheweb.com/home">
                           <img src="data:image/svg+xml,%3Csvg xmlns=&#39;http://www.w3.org/2000/svg&#39; viewBox=&#39;0 0 225 85&#39;%3E%3C/svg%3E" width="225" height="85" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" loading="lazy" class="lazyload">
                           <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2019/05/ToTheWeb-Site-Logo.png" width="225" height="85" alt="Image"  data-eio="l"></noscript>
                        </a>
                        <a class="e7308-25 x-anchor x-anchor-toggle has-graphic" tabindex="0" data-x-toggle="1" data-x-toggleable="e7308-25" data-x-toggle-overlay="1" aria-controls="e7308-25-off-canvas" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Off Canvas Content">
                           <div class="x-anchor-content lazyload"> <span class="x-graphic" aria-hidden="true"> <span class="x-toggle x-toggle-burger x-graphic-child x-graphic-toggle" aria-hidden="true"> <span class="x-toggle-burger-bun-t" data-x-toggle-anim="x-bun-t-1"></span> <span class="x-toggle-burger-patty" data-x-toggle-anim="x-patty-1"></span> <span class="x-toggle-burger-bun-b" data-x-toggle-anim="x-bun-b-1"></span> </span> </span></div>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="e7308-26 x-bar-space x-bar-space-top  x-hide-lg x-hide-md x-hide-sm x-hide-xl x-bar-space-h" style="display: none;"></div>
               <div class="e7308-26 x-bar x-bar-top x-bar-h x-bar-relative x-bar-is-sticky  x-hide-lg x-hide-md x-hide-sm x-hide-xl x-bar-outer-spacers lazyload" data-x-bar="{&quot;id&quot;:&quot;e7308-26&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;4em&quot;,&quot;triggerOffset&quot;:&quot;0&quot;,&quot;shrink&quot;:&quot;1&quot;}">
                  <div class="e7308-26 x-bar-content lazyload">
                     <div class="e7308-27 x-bar-container lazyload">
                        <form class="e7308-28 x-search" data-x-search="{&quot;search&quot;:true}" action="https://totheweb.com/" method="get">
                           <label class="visually-hidden" for="s-e7308-28">Search</label> <input id="s-e7308-28" class="x-search-input" type="search" name="s" value="" tabindex="0" placeholder="Search"> 
                           <button class="x-search-btn x-search-btn-submit" type="button" data-x-search-submit="" tabindex="0">
                              <span class="visually-hidden">Submit</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <circle fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" cx="10" cy="10" r="9" stroke-linejoin="miter"></circle>
                                 <line fill="none" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" x1="22" y1="22" x2="16.4" y2="16.4" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                           <button class="x-search-btn x-search-btn-clear" type="button" data-x-search-clear="" tabindex="0">
                              <span class="visually-hidden">Clear</span>
                              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="-1 -1 25 25">
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="5" x2="5" y2="19" stroke-linejoin="miter"></line>
                                 <line fill="none" stroke-width="3" stroke-linecap="square" stroke-miterlimit="10" x1="19" y1="19" x2="5" y2="5" stroke-linejoin="miter"></line>
                              </svg>
                           </button>
                        </form>
                     </div>
                  </div>
               </div>
               <div class="e7308-29 x-bar x-bar-top x-bar-h x-bar-relative  x-hide-lg x-hide-md x-hide-sm x-hide-xl x-bar-outer-spacers lazyload" data-x-bar="{&quot;id&quot;:&quot;e7308-29&quot;,&quot;region&quot;:&quot;top&quot;,&quot;height&quot;:&quot;3em&quot;}">
                  <div class="e7308-29 x-bar-content lazyload">
                     <div class="e7308-30 x-bar-container lazyload">
                        <nav class="e7308-31 x-crumbs" role="navigation">
                           <ol class="x-crumbs-list" itemscope="" itemtype="http://schema.org/BreadcrumbList" aria-label="Breadcrumb Navigation">
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/"><span itemprop="name"> <i class="e7308-31 x-icon" aria-hidden="true" data-x-icon-s=""></i> <span class="visually-hidden">Home</span></span></a><span class="x-crumbs-delimiter">→</span>
                                 <meta itemprop="position" content="1">
                              </li>
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/learning_center/"><span itemprop="name">B2B Search Marketing Tools &amp; Articles</span></a><span class="x-crumbs-delimiter">→</span>
                                 <meta itemprop="position" content="2">
                              </li>
                              <li class="x-crumbs-list-item" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                 <a class="x-crumbs-link x-crumbs-current" itemtype="http://schema.org/Thing" itemprop="item" href="https://totheweb.com/learning_center/tools-search-engine-simulator/" title="You Are Here"><span itemprop="name">Free Tool: Search Engine Simulator</span></a>
                                 <meta itemprop="position" content="3">
                              </li>
                           </ol>
                        </nav>
                     </div>
                  </div>
               </div>
            </header>
            <div id="cs-content" class="cs-content lazyloaded">
               <div class="e1096-1 x-section lazyloaded">
                  <div class="e1096-2 x-row x-container max width lazyloaded">
                     <div class="x-row-inner lazyloaded">
                        <div class="e1096-3 x-col lazyloaded">
                           <div class="e1096-4 x-text x-text-headline lazyloaded">
                              <div class="x-text-content lazyloaded">
                                 <div class="x-text-content-text lazyloaded">
                                    <h1 class="x-text-content-text-primary">Search Engine Spider Simulator</h1>
                                    <span class="x-text-content-text-subheadline">The Search Engine Simulator tool shows you how the engines “see” a web page.&nbsp;It simulates how Google “reads” a webpage by displaying the content exactly how it would see it.</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="e1096-5 x-row x-container max width lazyloaded">
                     <div class="x-row-inner lazyloaded">
                        <div class="e1096-6 x-col lazyloaded">
                           <div class="e1096-7 x-mod-container lazyloaded">
                              <a class="e1096-7 x-anchor x-anchor-toggle" tabindex="0" data-x-toggle="1" data-x-toggleable="e1096-7" aria-controls="e1096-7-dropdown" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Dropdown Content">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Why Use This Tool? +</span></div>
                                 </div>
                              </a>
                              <div id="e1096-7-dropdown" class="e1096-7 x-dropdown lazyloaded" data-x-stem="dr" data-x-stem-top="" data-x-toggleable="e1096-7" aria-hidden="true">
                                 <div style="padding: 20px; line-height: 1.4; text-align: left;">
                                    <ul>
                                       <li style="line-height: 1.4; text-align: left;">Your web page may look beautiful on the screen but if the search engines can’t index your content, then your content won’t be found by prospects.</li>
                                       <li style="line-height: 1.4; text-align: left;">
                                          Our free tool allows you an overall view into important SEO elements such as word count, the title and description tag, keyword phrase frequencies, 
                                          <h> tag headings, outbound link text and more.</h>
                                       </li>
                                    </ul>
                                    Read: <a href="https://totheweb.com/blog/b2b-organic-search-marketing-technical-seo/get-high-on-google-the-foundation-of-search-engine-optimization-seo-and-keyword-use/">Getting Started with SEO</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <form id="header-input-container" novalidate="novalidate" method="POST"> 
               <input id="url" placeholder="Enter page url: https://" class="header-input valid" type="text" name="url" aria-invalid="false" style="outline: none;">
                <button id="submit" type="submit" class="" style="outline: none;"><span id="large-button-text">
                RUN SIMULATION</span><span id="small-button-text">GO</span>
             </button>
            </form>
            <div style="display: flex; justify-content: center;">
               <div class="g-recaptcha lazyloaded" data-sitekey="6LdCh84bAAAAAJWQAROEewUFAWHnszDuxTe3wc2K" data-callback="captchaSuccess">
                  <div style="width: 304px; height: 78px;">
                     <div><iframe title="reCAPTCHA" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/anchor.html" width="304" height="78" role="presentation" name="a-7qe01pgg2j80" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div>
                     <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                  </div>
                  <iframe style="display: none;" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/saved_resource(1).html"></iframe>
               </div>
            </div>
            <div id="error-message" class="error-text lazyloaded" style="display: none;"></div>
            <div id="scroll-to" class=" lazyloaded"></div>
            <div class="tool-form" id="results-window" style="">
               <?php
                  if($url!=''){
               ?>
               <div id="simulator-result" class=" lazyloaded">
                  <hr>
                  <h2>Your SEO Simulator Results</h2>
                  <div class="resultHeading lazyloaded">URL</div>
                  <div class="resultData lazyloaded" id="resultUrl"><?php echo $url; ?></div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">TITLE</div>
                  <div class="resultData lazyloaded" id="title"><?php if($html !=''){ echo $tool->getTitle($html); } ?></div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">DESCRIPTION</div>
                  <div class="resultData lazyloaded" id="description"><span class="error-item"><?php  echo $tool->getMetaTages($url); ?></span></div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">ALL WORDS</div>
                  <div class="resultData lazyloaded" id="numberOfWords"><?php echo $tool->allWord($html); ?></div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">UNIQUE WORDS</div>
                  <div class="resultData lazyloaded" id="numberOfUniqueWords"><?php echo $tool->allWord($html,true); ?></div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">KEYWORDS PHRASE FREQUENCIES</div>
                  <div id="phrases-container" class=" lazyloaded">
                     <div id="two-word-phrases-container" class=" lazyloaded">
                        <div class="resultHeading twoWordPhrases lazyloaded">TWO WORD PHRASES <span>COUNT</span></div>
                        <div style="clear: both"></div>
                        <div class="resultData twoWordPhrases lazyloaded" id="twoWordPhrases">
                           <?php 
                              $TwoWord = $tool->countTotalTwoWord($html);
                              foreach($TwoWord as $key => $value) {
                                 echo '<div class="phrase-item">'.$key.'<span>'.$value.'</span></div>';
                              }
                           ?>
                        </div>
                     </div>
                     <div id="three-word-phrases-container" class=" lazyloaded">
                        <div class="resultHeading threeWordPhrases lazyloaded">THREE WORD PHRASES <span>COUNT</span></div>
                        <div style="clear: both"></div>
                        <div class="resultData threeWordPhrases lazyloaded" id="threeWordPhrases">
                           <?php 
                              $ThreeWord = $tool->countTotalThreeWord($html);
                              foreach($ThreeWord as $key => $value) {
                                 echo '<div class="phrase-item">'.$key.'<span>'.$value.'</span></div>';
                              }
                           ?>
                        </div>
                     </div>
                  </div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">H1 HEADINGS</div>
                  <div class="resultData lazyloaded" id="h1Headings">
                     <?php
                        $h1 = $tool->fnextractHeadins('h1',$html);
                        echo  $h1 ? $h1 : '<span class="error-item">No H1 Tags Found</span>';
                     ?>
                  </div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">H2 HEADINGS</div>
                  <div class="resultData lazyloaded" id="h2Headings">
                     <?php
                        $h2 = $tool->fnextractHeadins('h2',$html);
                        echo  $h2 ? $h2 : '<span class="error-item">No H2 Tags Found</span>';
                     ?>
                  </div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">H3 HEADINGS</div>
                  <div class="resultData lazyloaded" id="h3Headings">
                     <?php
                        $h3 = $tool->fnextractHeadins('h3',$html);
                        echo  $h3 ? $h3 : '<span class="error-item">No H3 Tags Found</span>';
                     ?>
                  </div>
                  <!-- <div style="clear: both"></div> -->
                  <!-- <div class="resultHeading lazyloaded">BOLD TEXT</div>
                  <div class="resultData lazyloaded" id="boldText"> -->
                     <?php 
                        // $b = $tool->getContent($html,'<strong>');
                        // echo $b ? $b : '<span class="error-item">No bold text Found</span>';
                     ?>
                  <!-- </div> -->
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">ALT LINK TEXT</div>
                  <div class="resultData lazyloaded" id="altText">
                     <?php
                        $Alts = $tool->getImgAlts($url);
                        if(count($Alts) >0){
                           foreach($Alts as $alt){
                              echo $alt.'<br>';
                           }
                        }else{
                           echo'<span class="error-item">No Image Alt Text Found</span>';
                        }
                     ?>
                     
                  </div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">ON PAGE LINKS</div>
                  <div class="resultData lazyloaded" id="links">
                     <?php
                        $links = $tool->linkExtractor($html);
                        if(count($links) >0){
                           foreach($links as $text => $link){
                              echo '<a href="'.$link.'" target="_blank">'.$text.'</a><br>';
                           }
                        }else{
                           echo'<span class="error-item">No Image Alt Text Found</span>';
                        }
                     ?>
                  </div>
                  <div style="clear: both"></div>
                  <div class="resultHeading lazyloaded">PAGE TEXT</div>
                  <div class="resultData lazyloaded" id="pageText">
                     <?php
                        echo $tool->getContent($html,$tags='<div>');
                     ?>
                  </div>
                  <div style="clear: both"></div>
               </div>
            <?php } ?>
            </div>
            <div class="rmp-widgets-container rmp-wp-plugin rmp-main-container js-rmp-widgets-container js-rmp-widgets-container--1096 lazyloaded" data-post-id="1096">
               <div class="rmp-rating-widget js-rmp-rating-widget lazyloaded">
                  <p class="rmp-heading rmp-heading--title"> How useful was our tool?</p>
                  <p class="rmp-heading rmp-heading--subtitle"> Click on a star below to rate our tool out of 5 stars</p>
                  <div class="rmp-rating-widget__icons lazyloaded">
                     <ul class="rmp-rating-widget__icons-list js-rmp-rating-icons-list">
                        <li class="rmp-rating-widget__icons-list__icon js-rmp-rating-item" data-descriptive-rating="Not at all useful" data-value="1" style="cursor: pointer;"> <i class="js-rmp-rating-icon rmp-icon rmp-icon--ratings rmp-icon--star rmp-icon--full-highlight"></i></li>
                        <li class="rmp-rating-widget__icons-list__icon js-rmp-rating-item" data-descriptive-rating="Somewhat useful" data-value="2" style="cursor: pointer;"> <i class="js-rmp-rating-icon rmp-icon rmp-icon--ratings rmp-icon--star rmp-icon--full-highlight"></i></li>
                        <li class="rmp-rating-widget__icons-list__icon js-rmp-rating-item" data-descriptive-rating="Useful" data-value="3" style="cursor: pointer;"> <i class="js-rmp-rating-icon rmp-icon rmp-icon--ratings rmp-icon--star rmp-icon--full-highlight"></i></li>
                        <li class="rmp-rating-widget__icons-list__icon js-rmp-rating-item" data-descriptive-rating="Fairly useful" data-value="4" style="cursor: pointer;"> <i class="js-rmp-rating-icon rmp-icon rmp-icon--ratings rmp-icon--star rmp-icon--full-highlight"></i></li>
                        <li class="rmp-rating-widget__icons-list__icon js-rmp-rating-item" data-descriptive-rating="Very useful" data-value="5" style="cursor: pointer;"> <i class="js-rmp-rating-icon rmp-icon rmp-icon--ratings rmp-icon--star rmp-icon--half-highlight js-rmp-replace-half-star"></i></li>
                     </ul>
                  </div>
                  <p class="rmp-rating-widget__hover-text js-rmp-hover-text"></p>
                  <button class="rmp-rating-widget__submit-btn rmp-btn js-submit-rating-btn"> Submit Rating </button>
                  <p class="rmp-rating-widget__results js-rmp-results "> Average rating <span class="rmp-rating-widget__results__rating js-rmp-avg-rating">4.6</span> / 5. Vote count: <span class="rmp-rating-widget__results__votes js-rmp-vote-count">455</span></p>
                  <p class="rmp-rating-widget__not-rated js-rmp-not-rated rmp-rating-widget__not-rated--hidden"> No votes so far! Be the first to rate this.</p>
                  <p class="rmp-rating-widget__msg js-rmp-msg"></p>
               </div>
               <script type="application/ld+json">{  "@context": "http://schema.org",  "@type": "Product",  "aggregateRating": {    "@type": "AggregateRating",    "bestRating": "5",    "ratingCount": "455",    "ratingValue": "4.6"  },  "image": "https://mk0tothewebprod1couj.kinstacdn.com/wp-content/uploads/2018/09/Search-Engine-Simulator-80_20fbd47708ae8fa220591a57cb64df2c.jpg",  "name": "Free Tool: Search Engine Simulator",  "description": "Free Tool: Search Engine Simulator"}</script> 
            </div>
            <footer class="x-colophon" role="contentinfo">
               <div class="e7497-1 x-bar x-bar-footer x-bar-h x-bar-relative x-bar-outer-spacers lazyloaded" data-x-bar="{&quot;id&quot;:&quot;e7497-1&quot;,&quot;region&quot;:&quot;footer&quot;,&quot;height&quot;:&quot;auto&quot;}">
                  <div class="x-bg lazyloaded" aria-hidden="true">
                     <div class="x-bg-layer-upper-color" style=" background-color: rgba(243, 33, 33, 0.65);"></div>
                  </div>
                  <div class="e7497-1 x-bar-content lazyloaded">
                     <div class="e7497-2 x-bar-container lazyloaded">
                        <div class="e7497-3 x-text x-text-headline lazyloaded">
                           <div class="x-text-content lazyloaded">
                              <div class="x-text-content-text lazyloaded">
                                 <h1 class="x-text-content-text-primary">We've recently relaunched our search and content marketing tools</h1>
                                 <span class="x-text-content-text-subheadline">See a problem? Let us know. <br></span>
                              </div>
                           </div>
                        </div>
                        <a class="e7497-4 x-anchor x-anchor-button" tabindex="0" href="https://totheweb.com/about-us/contact-us/">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Contact Us</span></div>
                           </div>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="e7497-5 x-bar x-bar-footer x-bar-h x-bar-relative x-bar-outer-spacers lazyloaded" data-x-bar="{&quot;id&quot;:&quot;e7497-5&quot;,&quot;region&quot;:&quot;footer&quot;,&quot;height&quot;:&quot;auto&quot;}">
                  <div class="e7497-5 x-bar-content lazyloaded">
                     <div class="e7497-6 x-bar-container lazyloaded">
                        <div class="e7497-7 x-text x-text-headline lazyloaded">
                           <div class="x-text-content lazyloaded">
                              <div class="x-text-content-text lazyloaded">
                                 <h1 class="x-text-content-text-primary">We are a B2B demand generation agency working with determined brands and people to achieve high visibility in search engines and generate leads.</h1>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="e7497-8 x-bar x-bar-footer x-bar-h x-bar-relative x-bar-outer-spacers lazyloaded" data-x-bar="{&quot;id&quot;:&quot;e7497-8&quot;,&quot;region&quot;:&quot;footer&quot;,&quot;height&quot;:&quot;auto&quot;}">
                  <div class="e7497-8 x-bar-content lazyloaded">
                     <div class="e7497-9 x-bar-container lazyloaded">
                        <div class="e7497-10 x-text x-text-headline lazyloaded">
                           <div class="x-text-content lazyloaded">
                              <div class="x-text-content-text lazyloaded">
                                 <h1 class="x-text-content-text-primary">Don't be shy - let's talk</h1>
                                 <span class="x-text-content-text-subheadline">
                                    <p><a href="mailto:contactus@totheweb.com">hello@totheweb.com</a></p>
                                    <p>+1 650 627 8800</p>
                                 </span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="e7497-11 x-bar-container lazyloaded">
                        <a class="e7497-12 x-anchor x-anchor-button has-graphic" tabindex="0" href="https://twitter.com/totheweb" target="_blank">
                           <div class="x-anchor-content lazyloaded">
                              <span class="x-graphic" aria-hidden="true">
                                 <span class="e7497-12 x-image x-graphic-child x-graphic-image x-graphic-primary">
                                    <img src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/twitter.svg" width="75" height="75" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/twitter.svg" loading="lazy" class=" ls-is-cached lazyloaded">
                                    <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/twitter.svg" width="75" height="75" alt="Image"  data-eio="l"></noscript>
                                 </span>
                              </span>
                           </div>
                        </a>
                        <a class="e7497-13 x-anchor x-anchor-button has-graphic" tabindex="0" href="https://www.linkedin.com/company/totheweb-llc" target="_blank">
                           <div class="x-anchor-content lazyloaded">
                              <span class="x-graphic" aria-hidden="true">
                                 <span class="e7497-13 x-image x-graphic-child x-graphic-image x-graphic-primary">
                                    <img src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/linkedin-in.svg" width="65.5" height="75" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/linkedin-in.svg" loading="lazy" class=" ls-is-cached lazyloaded">
                                    <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/linkedin-in.svg" width="65.5" height="75" alt="Image"  data-eio="l"></noscript>
                                 </span>
                              </span>
                           </div>
                        </a>
                        <a class="e7497-14 x-anchor x-anchor-button has-graphic" tabindex="0" target="_blank">
                           <div class="x-anchor-content lazyloaded">
                              <span class="x-graphic" aria-hidden="true">
                                 <span class="e7497-14 x-image x-graphic-child x-graphic-image x-graphic-primary">
                                    <img src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/rss.svg" width="65.5" height="75" alt="Image" data-src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/rss.svg" loading="lazy" class=" lazyloaded">
                                    <noscript><img src="https://mk0tothewebprod1couj.kinstacdn.com/wp-content/themes/pro-child/svgs/rss.svg" width="65.5" height="75" alt="Image"  data-eio="l"></noscript>
                                 </span>
                              </span>
                           </div>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="e7497-15 x-bar x-bar-footer x-bar-h x-bar-relative x-bar-outer-spacers lazyloaded" data-x-bar="{&quot;id&quot;:&quot;e7497-15&quot;,&quot;region&quot;:&quot;footer&quot;,&quot;height&quot;:&quot;auto&quot;}">
                  <div class="e7497-15 x-bar-content lazyloaded">
                     <div class="e7497-16 x-bar-container lazyloaded">
                        <div class="e7497-17 x-text lazyloaded">
                           <p>© ToTheWeb LLC 1995-2020 &nbsp;| &nbsp; All Rights Reserved &nbsp;| &nbsp;San Francisco Bay Area, California &nbsp; | &nbsp; <a href="https://totheweb.com/privacy/">Privacy Policy</a></p>
                        </div>
                     </div>
                  </div>
               </div>
            </footer>
            <div id="e7308-18-off-canvas" class="e7308-18 x-off-canvas x-off-canvas-right lazyloaded" role="dialog" tabindex="-1" data-x-toggleable="e7308-18" aria-hidden="true" aria-label="Off Canvas">
               <span class="x-off-canvas-bg"></span> <button class="x-off-canvas-close x-off-canvas-close-right" data-x-toggle-close="1" aria-label="Close Off Canvas Content"> <span>×</span> </button>
               <div class="x-off-canvas-content x-off-canvas-content-right ps lazyloaded" data-x-scrollbar="{&quot;suppressScrollX&quot;:true}" role="document" aria-label="Off Canvas Content">
                  <ul class="e7308-18 x-menu x-menu-layered x-current-layer" data-x-toggle-layered-root="1" style="height: 218px;">
                     <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-7318" id="menu-item-7318">
                        <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/" id="x-menu-layered-anchor-e7308-18-0" data-x-toggle="layered" data-x-toggleable="e7308-18-0" aria-controls="x-menu-layered-list-e7308-18-0" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">SERVICES</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                        <ul class="sub-menu" id="x-menu-layered-list-e7308-18-0" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-18-0" data-x-toggleable="e7308-18-0" data-x-toggle-layered="1">
                           <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-18-0"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7319" id="menu-item-7319">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/increase-website-lead-generation/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Website Lead Generation</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7321" id="menu-item-7321">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/keyword-research-reference-guide/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Keyword Research</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7323" id="menu-item-7323">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/search-engine-optimization/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Search Engine Optimization</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7324" id="menu-item-7324">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/website-review-and-competitive-analysis-html/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B SEO Technical Audit</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7325" id="menu-item-7325">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/search-engine-advertising/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Paid Media</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7327" id="menu-item-7327">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/b2b-account-based-marketing/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Account Based Marketing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7328" id="menu-item-7328">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/b2b-content-audit-services/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Content Audit</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7322" id="menu-item-7322">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/web-content-marketing-strategy/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Content Marketing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7320" id="menu-item-7320">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/website-usability-testing/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Website User Testing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7326" id="menu-item-7326">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/b2b-marketing-get-social/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Social Media Marketing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7329" id="menu-item-7329">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/building-search-engine-link-popularity/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Building Link Popularity</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7330" id="menu-item-7330">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/#pricing">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Pricing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </li>
                     <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-7341" id="menu-item-7341">
                        <a class="e7308-18 x-anchor x-anchor-menu-item x-always-active" tabindex="0" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" id="x-menu-layered-anchor-e7308-18-1" data-x-toggle="layered" data-x-toggleable="e7308-18-1" aria-controls="x-menu-layered-list-e7308-18-1" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">TOOLS AND BLOG</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                        <ul class="sub-menu" id="x-menu-layered-list-e7308-18-1" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-18-1" data-x-toggleable="e7308-18-1" data-x-toggle-layered="1">
                           <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-18-1"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7334" id="menu-item-7334">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tool-test-google-title-meta-description-lengths/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Google Meta Description Tester</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7335" id="menu-item-7335">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tool-keyword-topic-page-theme-finder/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Find Keywords on Any Page</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-1096 current_page_item menu-item-7333" id="menu-item-7333">
                              <a class="e7308-18 x-anchor x-anchor-menu-item x-always-active" tabindex="0" href="https://totheweb.com/learning_center/tools-search-engine-simulator/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Free Tool: Search Engine Simulator</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7336" id="menu-item-7336">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/campaign-tracking-url-builder/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Create Campaign Tracking URLs</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7337" id="menu-item-7337">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tool-calculate-ad-campaign-lead-cost-return-ad-spend-roas-cost-per-sale/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Calculate Return on Ad Spend</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7332" id="menu-item-7332">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tools-convert-html-text-to-plain-text-for-content-review/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Convert to Plain Text</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7342" id="menu-item-7342">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/blog/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Explore Our Blog</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </li>
                     <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7351" id="menu-item-7351">
                        <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" id="x-menu-layered-anchor-e7308-18-2" data-x-toggle="layered" data-x-toggleable="e7308-18-2" aria-controls="x-menu-layered-list-e7308-18-2" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">WHY CHOOSE US</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                        <ul class="sub-menu" id="x-menu-layered-list-e7308-18-2" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-18-2" data-x-toggleable="e7308-18-2" data-x-toggle-layered="1">
                           <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-18-2"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-7343" id="menu-item-7343">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/" id="x-menu-layered-anchor-e7308-18-3" data-x-toggle="layered" data-x-toggleable="e7308-18-3" aria-controls="x-menu-layered-list-e7308-18-3" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">About Us</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                              <ul class="sub-menu" id="x-menu-layered-list-e7308-18-3" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-18-3" data-x-toggleable="e7308-18-3" data-x-toggle-layered="1">
                                 <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-18-3"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7347" id="menu-item-7347">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/rosemary-brisco/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Rosemary Brisco</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7350" id="menu-item-7350">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/john-koh/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">John Koh</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7346" id="menu-item-7346">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/michele-grey/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Michele Grey</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7345" id="menu-item-7345">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/john-mcaulay/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">John Mcaulay</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7348" id="menu-item-7348">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/brandon-loya/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Brandon Loya</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7349" id="menu-item-7349">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/dirk-frandsen/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Dirk Frandsen</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7503" id="menu-item-7503">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/michael-menduno/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Michael Menduno</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-7352" id="menu-item-7352">
                              <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/our_clients/" id="x-menu-layered-anchor-e7308-18-4" data-x-toggle="layered" data-x-toggleable="e7308-18-4" aria-controls="x-menu-layered-list-e7308-18-4" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Our Clients</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                              <ul class="sub-menu" id="x-menu-layered-list-e7308-18-4" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-18-4" data-x-toggleable="e7308-18-4" data-x-toggle-layered="1">
                                 <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-18-4"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7353" id="menu-item-7353">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/our_clients/all-clients/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Clients by Industry</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7354" id="menu-item-7354">
                                    <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/our_clients/case-studies/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Customer Success Stories</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                        </ul>
                     </li>
                     <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7355" id="menu-item-7355">
                        <a class="e7308-18 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/contact-us-2/">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">CONTACT US</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                     </li>
                  </ul>
                  <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                     <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                  </div>
                  <div class="ps__rail-y" style="top: 0px; right: 0px;">
                     <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div>
                  </div>
               </div>
            </div>
            <div id="e7308-25-off-canvas" class="e7308-25 x-off-canvas x-off-canvas-right lazyloaded" role="dialog" tabindex="-1" data-x-toggleable="e7308-25" aria-hidden="true" aria-label="Off Canvas">
               <span class="x-off-canvas-bg"></span> <button class="x-off-canvas-close x-off-canvas-close-right" data-x-toggle-close="1" aria-label="Close Off Canvas Content"> <span>×</span> </button>
               <div class="x-off-canvas-content x-off-canvas-content-right ps lazyloaded" data-x-scrollbar="{&quot;suppressScrollX&quot;:true}" role="document" aria-label="Off Canvas Content">
                  <ul class="e7308-25 x-menu x-menu-layered x-current-layer" data-x-toggle-layered-root="1" style="height: 200px;">
                     <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-7318">
                        <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/" id="x-menu-layered-anchor-e7308-25-0" data-x-toggle="layered" data-x-toggleable="e7308-25-0" aria-controls="x-menu-layered-list-e7308-25-0" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">SERVICES</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                        <ul class="sub-menu" id="x-menu-layered-list-e7308-25-0" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-25-0" data-x-toggleable="e7308-25-0" data-x-toggle-layered="1">
                           <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-25-0"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7319">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/increase-website-lead-generation/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Website Lead Generation</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7321">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/keyword-research-reference-guide/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Keyword Research</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7323">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/search-engine-optimization/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Search Engine Optimization</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7324">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/website-review-and-competitive-analysis-html/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B SEO Technical Audit</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7325">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/search-engine-advertising/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Paid Media</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7327">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/b2b-account-based-marketing/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Account Based Marketing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7328">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/b2b-content-audit-services/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Content Audit</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7322">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/web-content-marketing-strategy/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Content Marketing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7320">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/website-usability-testing/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Website User Testing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7326">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/b2b-marketing-get-social/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Social Media Marketing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7329">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/building-search-engine-link-popularity/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">B2B Building Link Popularity</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7330">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/services/#pricing">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Pricing</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </li>
                     <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-7341">
                        <a class="e7308-25 x-anchor x-anchor-menu-item x-always-active" tabindex="0" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" id="x-menu-layered-anchor-e7308-25-1" data-x-toggle="layered" data-x-toggleable="e7308-25-1" aria-controls="x-menu-layered-list-e7308-25-1" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">TOOLS AND BLOG</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                        <ul class="sub-menu" id="x-menu-layered-list-e7308-25-1" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-25-1" data-x-toggleable="e7308-25-1" data-x-toggle-layered="1">
                           <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-25-1"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7334">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tool-test-google-title-meta-description-lengths/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Google Meta Description Tester</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7335">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tool-keyword-topic-page-theme-finder/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Find Keywords on Any Page</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-1096 current_page_item menu-item-7333">
                              <a class="e7308-25 x-anchor x-anchor-menu-item x-always-active" tabindex="0" href="https://totheweb.com/learning_center/tools-search-engine-simulator/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Free Tool: Search Engine Simulator</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7336">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/campaign-tracking-url-builder/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Create Campaign Tracking URLs</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7337">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tool-calculate-ad-campaign-lead-cost-return-ad-spend-roas-cost-per-sale/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Calculate Return on Ad Spend</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7332">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tools-convert-html-text-to-plain-text-for-content-review/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Convert to Plain Text</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                           <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7342">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/blog/">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Explore Our Blog</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </li>
                     <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7351">
                        <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/learning_center/tools-search-engine-simulator/#" id="x-menu-layered-anchor-e7308-25-2" data-x-toggle="layered" data-x-toggleable="e7308-25-2" aria-controls="x-menu-layered-list-e7308-25-2" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">WHY CHOOSE US</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                        <ul class="sub-menu" id="x-menu-layered-list-e7308-25-2" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-25-2" data-x-toggleable="e7308-25-2" data-x-toggle-layered="1">
                           <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-25-2"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-7343">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/" id="x-menu-layered-anchor-e7308-25-3" data-x-toggle="layered" data-x-toggleable="e7308-25-3" aria-controls="x-menu-layered-list-e7308-25-3" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">About Us</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                              <ul class="sub-menu" id="x-menu-layered-list-e7308-25-3" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-25-3" data-x-toggleable="e7308-25-3" data-x-toggle-layered="1">
                                 <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-25-3"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7347">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/rosemary-brisco/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Rosemary Brisco</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7350">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/john-koh/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">John Koh</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7346">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/michele-grey/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Michele Grey</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7345">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/john-mcaulay/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">John Mcaulay</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7348">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/brandon-loya/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Brandon Loya</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7349">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/dirk-frandsen/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Dirk Frandsen</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7503">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/michael-menduno/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Michael Menduno</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-7352">
                              <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/our_clients/" id="x-menu-layered-anchor-e7308-25-4" data-x-toggle="layered" data-x-toggleable="e7308-25-4" aria-controls="x-menu-layered-list-e7308-25-4" aria-expanded="false" aria-haspopup="true" aria-label="Toggle Layered Sub Menu">
                                 <div class="x-anchor-content lazyloaded">
                                    <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Our Clients</span></div>
                                    <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                 </div>
                              </a>
                              <ul class="sub-menu" id="x-menu-layered-list-e7308-25-4" aria-hidden="true" aria-labelledby="x-menu-layered-anchor-e7308-25-4" data-x-toggleable="e7308-25-4" data-x-toggle-layered="1">
                                 <li><a class="x-anchor x-anchor-layered-back" aria-label="Go Back One Level" data-x-toggle="layered" data-x-toggleable="e7308-25-4"><span class="x-anchor-appearance"><span class="x-anchor-content"><span class="x-anchor-text"><span class="x-anchor-text-primary">← Back to Main Menu</span></span></span></span></a></li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7353">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/our_clients/all-clients/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Clients by Industry</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7354">
                                    <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/our_clients/case-studies/">
                                       <div class="x-anchor-content lazyloaded">
                                          <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">Customer Success Stories</span></div>
                                          <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                        </ul>
                     </li>
                     <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7355">
                        <a class="e7308-25 x-anchor x-anchor-menu-item" tabindex="0" href="https://totheweb.com/about-us/contact-us-2/">
                           <div class="x-anchor-content lazyloaded">
                              <div class="x-anchor-text lazyloaded"><span class="x-anchor-text-primary">CONTACT US</span></div>
                              <i class="x-anchor-sub-indicator" data-x-skip-scroll="true" aria-hidden="true" data-x-icon-l=""></i>
                           </div>
                        </a>
                     </li>
                  </ul>
                  <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                     <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                  </div>
                  <div class="ps__rail-y" style="top: 0px; right: 0px;">
                     <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div>
                  </div>
               </div>
            </div>
         </div>
         <a class="x-scroll-top right fade" title="Back to Top"> <i class="x-icon-angle-up" data-x-icon-l=""></i> </a> <script>jQuery(document).ready(function($) {
            var $window            = $(window);
            var body                 = $('body');
            var bodyOffsetBottom     = $window.scrollBottom();             // 1
            var bodyHeightAdjustment = body.height() - bodyOffsetBottom;     // 2
            var bodyHeightAdjusted   = body.height() - bodyHeightAdjustment; // 3
            var $scrollTopAnchor      = $('.x-scroll-top');
            
            function sizingUpdate(){
              var bodyOffsetTop = $window.scrollTop();
              if ( bodyOffsetTop > ( bodyHeightAdjusted * 0.75 ) ) {
                $scrollTopAnchor.addClass('in');
              } else {
                $scrollTopAnchor.removeClass('in');
              }
            }
            
            $window.on('scroll', sizingUpdate).resize(sizingUpdate);
            sizingUpdate();
            
            $scrollTopAnchor.on( 'click', function(){
              $('html, body').animate({ scrollTop: 0 }, 850, 'xEaseInOutExpo');
              return false;
            });
            
            });
         </script> 
      </div>
      <!--?xml version="1.0" encoding="UTF-8"?--> 
      <svg class="ubermenu-essential-icons" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
         <defs></defs>
         <symbol id="ubermenu-icon-angle" viewBox="0 0 16 16">
            <title>icon-angle</title>
            <g id="angle">
               <g id="path">
                  <path d="M13.48,4.64a.24.24,0,0,1,.35,0l.36.35a.27.27,0,0,1,0,.36l-6,6a.25.25,0,0,1-.36,0l-6-6a.27.27,0,0,1,0-.36l.36-.35a.24.24,0,0,1,.35,0L8,10.12H8Z"></path>
               </g>
            </g>
         </symbol>
         <symbol id="ubermenu-icon-bars" viewBox="0 0 16 16">
            <title>icon-bars</title>
            <g id="bars">
               <rect id="top" x="2" y="4" width="12" height="1" rx="0.25"></rect>
               <rect id="middle" x="2" y="8" width="12" height="1" rx="0.25"></rect>
               <rect id="bottom" x="2" y="12" width="12" height="1" rx="0.25"></rect>
            </g>
         </symbol>
         <symbol id="ubermenu-icon-times" viewBox="0 0 16 16">
            <title>icon-times</title>
            <g id="times">
               <rect id="up" x="3" y="7.5" width="10" height="1" rx="0.25" transform="translate(-3.31 8) rotate(-45)"></rect>
               <rect id="down" x="7.5" y="3" width="1" height="10" rx="0.25" transform="translate(-3.31 8) rotate(-45)"></rect>
            </g>
         </symbol>
      </svg>
      <div id="popup-background" style="display:none">
         <div id="popup-window-container" class="lazyload">
            <div id="popup-close" class="lazyload"><a href="https://totheweb.com/learning_center/tools-search-engine-simulator/" id="close" title="Close">×</a></div>
            <div id="popup-window-inner" class="lazyload">
               <h1>Drive More Leads to<br> Your Website!</h1>
               <p>Receive infrequent updates from the pros.</p>
               <p><input type="email" id="email" placeholder="Your Email Address" class="error-email"></p>
               <p><input type="checkbox" id="checkbox" name="checkbox"><label id="permission-label" for="checkbox" class="permission error-permission"> Yes, keep me updated. *</label></p>
               <p><input type="button" id="submit" value="Get Started Today!"><span class="loading"></span></p>
            </div>
         </div>
      </div>
      <script type="text/javascript" id="">function setCookie(c,d,b){var a=new Date;a.setTime(a.getTime()+864E5*b);b="expires\x3d"+a.toUTCString();document.cookie=c+"\x3d"+d+"; "+b+"; path\x3d/"}function getCookie(c){c+="\x3d";for(var d=document.cookie.split(";"),b=0;b<d.length;b++){for(var a=d[b];" "==a.charAt(0);)a=a.substring(1);if(-1!=a.indexOf(c))return a.substring(c.length,a.length)}return""}
         try{""==getCookie("return_visitor_check")&&(setCookie("return_visitor_check",1,1),""==getCookie("return_visitor")?setCookie("return_visitor",0,365):0==getCookie("return_visitor")?setCookie("return_visitor",1,365):1==getCookie("return_visitor")&&(setCookie("return_visitor",1,365),dataLayer.push({event:"GAevent",eventCategory:"tracking",eventAction:"return-visit"})))}catch(c){};
      </script><script type="text/javascript" id="">(function(a,e,f,g,b,c,d){a.GoogleAnalyticsObject=b;a[b]=a[b]||function(){(a[b].q=a[b].q||[]).push(arguments)};a[b].l=1*new Date;c=e.createElement(f);d=e.getElementsByTagName(f)[0];c.async=1;c.src=g;d.parentNode.insertBefore(c,d)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create","UA-1008053-1");ga("require","displayfeatures");ga(function(a){window.dataLayer.push({event:"trackerReady",cid:a.get("clientId")})});</script><script type="text/javascript" id="">setTimeout(function(){var a=document.createElement("script"),b=document.getElementsByTagName("script")[0];a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0018/1036.js?"+Math.floor((new Date).getTime()/36E5);a.async=!0;a.type="text/javascript";b.parentNode.insertBefore(a,b)},1);</script><script type="text/javascript" id="">var contact_us_timeout=setInterval(function(){-1<jQuery("div.wpcf7-mail-sent-ok").text().indexOf("Your message was sent")&&(google_tag_manager["GTM-KZ7KXP"].macro(6).indexOf("about-us/contact-us"),dataLayer.push({event:"GAevent",eventCategory:"form",eventAction:"submit",eventLabel:"contact-us-main",cdIndex:"",cdValue:""}),window.clearInterval(contact_us_timeout))},500);</script><script>function getCookie(cookieName) {
         var name = cookieName + "=";
         var decodedCookie = decodeURIComponent(document.cookie);
         var ca = decodedCookie.split(';');
         for(var i = 0; i <ca.length; i++) {
             var c = ca[i];
             while (c.charAt(0) == ' ') {
                 c = c.substring(1);
             }
             if (c.indexOf(name) == 0) {
                 return c.substring(name.length, c.length);
             }
         }
         return false;
         }
         
         function setCookie(cookieName, cookieValue, expireDays) {
         var d = new Date();
         d.setTime(d.getTime() + (expireDays*24*60*60*1000));
         var expires = "expires="+ d.toUTCString();
         document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
         }
         
         function checkCookie() {
         var cookie = getCookie("newsletter-popup");
         if (cookie != "1") {
         
             showPopup();
             setCookie("newsletter-popup", "1",14);
             
         
         }
         }
         
         function validateEmail(email) {
         const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
         return re.test(String(email).toLowerCase());
         }
         
         function hidePopup() {
         jQuery('#popup-window-container').fadeOut(500,function(){
             jQuery('#popup-background').fadeOut(500)
         });
         
         }
         
         function showPopup() {
         jQuery('#popup-background').fadeIn(500,function(){
             jQuery('#popup-window-container').fadeIn(500)
         });
         
         }
         
         
         //desktop trigger
         setTimeout(() => {
         jQuery(document).on('mouseout', function(e){
             if(!e.toElement && !e.relatedTarget && e.clientY < 10){
                 checkCookie();
             }
         });
         }, 10000);
         
         //mobile trigger
         setTimeout(() => {
         document.addEventListener("scroll", scrollSpeed);
         }, 10000);
         
         scrollSpeed = () => {  
         lastPosition = window.scrollY;
         setTimeout(() => {
             newPosition = window.scrollY;
         }, 100);
         currentSpeed = newPosition - lastPosition;
         
         if (currentSpeed > 160) {
             checkCookie();
             document.removeEventListener("scroll", scrollSpeed);
         }
         };
         
         jQuery('#close').on('click', function(){
         event.preventDefault();
         hidePopup();
         
         });
         
         jQuery('#submit').on('click', function(){
         
         //if everything checks out on the form
         if(jQuery('#checkbox').is(':checked') && validateEmail(jQuery('#email').val())){
             
             //submit to mailchimp
             let email = jQuery('#email').val();
             
             let data = new FormData();
             data.append('email', email);
         
             fetch('/seo-tools/mailchimp-signup/signup.php',{method: 'post', cache: 'no-cache', body: data})
             .then(response => response.json())
             .then(data => {
                 if(data.result == 0 || data.result == 1){
                     dataLayer.push({
                         'event': 'newsletter_sign_up'
                     });         
                     hidePopup();
         
                 }
             });
         
         }else{
         
             if(!validateEmail(jQuery('#email').val())){
                 jQuery('#email').addClass('error-email');
                 jQuery('#email').on('change', function(event){
                     if(validateEmail(jQuery('#email').val())){
                         jQuery(this).removeClass('error-email');
         
                     }
                 });                             
             }
         
             if(!jQuery('#checkbox').is(':checked')){
                 jQuery('.permission').addClass('error-permission');
                 jQuery('#checkbox').on('change', function(event){
                     //if checked remove error class
                     if(jQuery('#checkbox').is(':checked')){
                         jQuery('#permission-label').removeClass('error-permission')
                     }
                 });
             }
         
         }
         });
      </script> <script type="text/javascript" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/jquery-ui.min.js.download" id="jquery-ui-js"></script> <script type="text/javascript" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/api.js.download" id="grecatpcha-js"></script> <script type="text/javascript" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/scripts.js.download" id="seo-simulator-tool-js"></script> <script type="text/javascript" id="contact-form-7-js-extra">var wpcf7 = {"api":{"root":"https:\/\/totheweb.com\/wp-json\/","namespace":"contact-form-7\/v1"}};</script> <script type="text/javascript" id="rate-my-post-js-extra">var rmp_frontend = {"admin_ajax":"https:\/\/totheweb.com\/wp-admin\/admin-ajax.php","postID":"1096","noVotes":"No votes so far! Be the first to rate this.","cookie":"You already voted! This vote will not be counted!","afterVote":"Thank you for your rating!","notShowRating":"1","social":"1","feedback":"1","cookieDisable":"1","emptyFeedback":"Please insert your feedback in the box above!","hoverTexts":"1","preventAccidental":"1","grecaptcha":"1","siteKey":"","votingPriv":"1","loggedIn":"","positiveThreshold":"2","ajaxLoad":"1","nonce":"2e76e16a4e"};</script> <script type="text/javascript" id="ubermenu-js-extra">var ubermenu_data = {"remove_conflicts":"on","reposition_on_load":"off","intent_delay":"300","intent_interval":"100","intent_threshold":"7","scrollto_offset":"50","scrollto_duration":"1000","responsive_breakpoint":"959","accessible":"on","retractor_display_strategy":"responsive","touch_off_close":"on","submenu_indicator_close_mobile":"on","collapse_after_scroll":"on","v":"3.7.4","configurations":["main"],"ajax_url":"https:\/\/totheweb.com\/wp-admin\/admin-ajax.php","plugin_url":"https:\/\/totheweb.com\/wp-content\/plugins\/ubermenu\/","disable_mobile":"off","prefix_boost":"","use_core_svgs":"on","aria_role_navigation":"off","aria_nav_label":"off","aria_expanded":"off","aria_hidden":"off","aria_controls":"","aria_responsive_toggle":"off","icon_tag":"i","esc_close_mobile":"on","theme_locations":{"primary":"Primary Menu","footer":"Footer Menu"}};</script> <script defer="" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/autoptimize_89f21349eca9285a21b7a1ce32837eb8.js.download"></script>
      <div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 0px; top: -10000px;">
         <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div>
         <div class="g-recaptcha-bubble-arrow" style="border: 11px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div>
         <div class="g-recaptcha-bubble-arrow" style="border: 10px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000;"></div>
         <div style="z-index: 2000000000; position: relative;"><iframe title="recaptcha challenge" src="./Search Engine Simulator Let&#39;s You See How Google Views your Page_files/bframe.html" name="c-7qe01pgg2j80" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 100%; height: 100%;"></iframe></div>
      </div>
   </body>
</html>